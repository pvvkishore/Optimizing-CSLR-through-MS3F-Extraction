# stage4_data_loader.py
import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pickle
from stage3_inference import Stage3Inference

class Stage4CTCDataset(Dataset):
    def __init__(self, root_train_folder, annotations_folder, stage3_model_path, 
                 label_encoder_path, max_seq_length=100, transform=None):
        """
        Dataset for Stage 4 CTC training - uses Stage 3 predictions as input
        
        Args:
            root_train_folder: Path to folder containing subfolders with video frames
            annotations_folder: Path to folder containing CSV annotation file
            stage3_model_path: Path to trained Stage 3 model
            label_encoder_path: Path to Stage 3 label encoder
            max_seq_length: Maximum sequence length for CTC
            transform: Optional transform for frames
        """
        self.root_train_folder = root_train_folder
        self.max_seq_length = max_seq_length
        self.transform = transform
        
        # Load Stage 3 model for feature extraction
        self.stage3_model = Stage3Inference(stage3_model_path, label_encoder_path)
        
        # Load Stage 3 label encoder
        with open(label_encoder_path, 'rb') as f:
            self.gloss_label_encoder = pickle.load(f)
        
        # Load annotations
        csv_files = [f for f in os.listdir(annotations_folder) if f.endswith('.csv')]
        if not csv_files:
            raise ValueError("No CSV file found in annotations folder")
        
        csv_path = os.path.join(annotations_folder, csv_files[0])
        self.annotations = pd.read_csv(csv_path)
        
        # Skip first row and use first two columns
        self.annotations = self.annotations.iloc[1:, :2]
        self.annotations.columns = ['folder_name', 'gloss_text']
        
        # Build samples and create CTC targets
        self.samples = []
        self.ctc_targets = []
        
        # Create character-level vocabulary for CTC
        all_text = ' '.join(self.annotations['gloss_text'].astype(str).str.lower())
        unique_chars = sorted(list(set(all_text)))
        
        # Add special tokens: blank (index 0), space, and common punctuation
        self.char_to_idx = {'<blank>': 0}  # CTC blank token
        for i, char in enumerate(unique_chars):
            self.char_to_idx[char] = i + 1
        
        self.idx_to_char = {v: k for k, v in self.char_to_idx.items()}
        self.vocab_size = len(self.char_to_idx)
        
        print(f"CTC Vocabulary size: {self.vocab_size}")
        print(f"Sample characters: {list(self.char_to_idx.keys())[:10]}")
        
        # Process samples
        for _, row in self.annotations.iterrows():
            folder_path = os.path.join(root_train_folder, str(row['folder_name']))
            if os.path.exists(folder_path):
                frame_files = sorted([f for f in os.listdir(folder_path) 
                                    if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
                
                if len(frame_files) > 0:
                    gloss_text = str(row['gloss_text']).strip().lower()
                    
                    # Convert text to character indices for CTC
                    char_indices = []
                    for char in gloss_text:
                        if char in self.char_to_idx:
                            char_indices.append(self.char_to_idx[char])
                    
                    if len(char_indices) > 0 and len(char_indices) <= max_seq_length:
                        self.samples.append({
                            'folder_name': str(row['folder_name']),
                            'gloss_text': gloss_text,
                            'folder_path': folder_path,
                            'frame_files': frame_files,
                            'num_frames': len(frame_files),
                            'char_indices': char_indices,
                            'target_length': len(char_indices)
                        })
        
        print(f"Stage 4 dataset loaded with {len(self.samples)} samples")
    
    def get_vocab_info(self):
        """Return vocabulary information"""
        return {
            'char_to_idx': self.char_to_idx,
            'idx_to_char': self.idx_to_char,
            'vocab_size': self.vocab_size
        }
    
    def save_vocab(self, path):
        """Save vocabulary for later use"""
        vocab_info = self.get_vocab_info()
        with open(path, 'wb') as f:
            pickle.dump(vocab_info, f)
    
    @staticmethod
    def load_vocab(path):
        """Load saved vocabulary"""
        with open(path, 'rb') as f:
            return pickle.load(f)
    
    def __len__(self):
        return len(self.samples)
    
    def load_frames_for_stage3(self, folder_path, frame_files):
        """Load frames in format expected by Stage 3 model"""
        import cv2
        from torchvision import transforms
        
        frames = []
        for frame_file in frame_files:
            frame_path = os.path.join(folder_path, frame_file)
            frame = cv2.imread(frame_path)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (112, 112))
            frames.append(frame)
        
        # Convert to tensor and apply normalization
        transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((112, 112)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        transformed_frames = []
        for frame in frames:
            frame_tensor = transform(frame)
            transformed_frames.append(frame_tensor)
        
        return torch.stack(transformed_frames)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # Load frames for Stage 3 processing
        frames = self.load_frames_for_stage3(sample['folder_path'], sample['frame_files'])
        frame_indexes = torch.arange(len(sample['frame_files']), dtype=torch.long)
        
        # Get Stage 3 features (temporal sequence from LSTM hidden states)
        # We'll extract these during training to avoid memory issues
        
        return {
            'frames': frames,  # (T, 3, 112, 112)
            'frame_indexes': frame_indexes,  # (T,)
            'num_frames': sample['num_frames'],
            'gloss_text': sample['gloss_text'],
            'char_indices': torch.tensor(sample['char_indices'], dtype=torch.long),
            'target_length': sample['target_length'],
            'folder_name': sample['folder_name']
        }

def stage4_collate_fn(batch):
    """Custom collate function for Stage 4 CTC training"""
    # Sort by sequence length (descending) for efficient packing
    batch = sorted(batch, key=lambda x: x['num_frames'], reverse=True)
    
    max_frames = batch[0]['num_frames']
    batch_size = len(batch)
    
    # Pad frame sequences
    padded_frames = torch.zeros(batch_size, max_frames, 3, 112, 112)
    padded_indexes = torch.zeros(batch_size, max_frames, dtype=torch.long)
    input_lengths = torch.zeros(batch_size, dtype=torch.long)
    
    # CTC targets (variable length, so we concatenate them)
    targets = []
    target_lengths = torch.zeros(batch_size, dtype=torch.long)
    
    gloss_texts = []
    folder_names = []
    
    for i, sample in enumerate(batch):
        seq_len = sample['num_frames']
        padded_frames[i, :seq_len] = sample['frames']
        padded_indexes[i, :seq_len] = sample['frame_indexes']
        input_lengths[i] = seq_len
        
        # CTC targets
        char_indices = sample['char_indices']
        targets.extend(char_indices.tolist())
        target_lengths[i] = len(char_indices)
        
        gloss_texts.append(sample['gloss_text'])
        folder_names.append(sample['folder_name'])
    
    # Convert targets to tensor
    targets = torch.tensor(targets, dtype=torch.long)
    
    return {
        'frames': padded_frames,
        'frame_indexes': padded_indexes,
        'input_lengths': input_lengths,
        'targets': targets,
        'target_lengths': target_lengths,
        'gloss_texts': gloss_texts,
        'folder_names': folder_names
    }

def get_stage4_data_loader(root_train_folder, annotations_folder, stage3_model_path,
                          label_encoder_path, batch_size=8, shuffle=True, num_workers=2):
    """Create data loader for Stage 4 CTC training"""
    dataset = Stage4CTCDataset(
        root_train_folder=root_train_folder,
        annotations_folder=annotations_folder,
        stage3_model_path=stage3_model_path,
        label_encoder_path=label_encoder_path
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=stage4_collate_fn
    )
    
    return dataloader, dataset

# stage4_model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from stage3_inference import Stage3Inference

class CTCAlignmentModule(nn.Module):
    def __init__(self, input_dim=1024, hidden_dim=512, vocab_size=50, num_layers=2, dropout=0.3):
        """
        CTC Alignment Module for temporal sequence alignment
        
        Args:
            input_dim: Input feature dimension from Stage 3
            hidden_dim: Hidden dimension for CTC LSTM
            vocab_size: Size of character vocabulary
            num_layers: Number of LSTM layers
            dropout: Dropout rate
        """
        super(CTCAlignmentModule, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.vocab_size = vocab_size
        self.num_layers = num_layers
        
        # Feature projection layer
        self.feature_projection = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # CTC LSTM layers
        self.ctc_lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=True
        )
        
        # Output projection to vocabulary
        self.output_projection = nn.Linear(hidden_dim * 2, vocab_size)  # *2 for bidirectional
        
        # Log softmax for CTC
        self.log_softmax = nn.LogSoftmax(dim=2)
    
    def forward(self, features, input_lengths):
        """
        Forward pass for CTC alignment
        
        Args:
            features: Input features (batch_size, max_seq_len, input_dim)
            input_lengths: Actual sequence lengths (batch_size,)
            
        Returns:
            log_probs: Log probabilities for CTC (batch_size, max_seq_len, vocab_size)
            output_lengths: Output sequence lengths (batch_size,)
        """
        batch_size, max_seq_len, _ = features.shape
        
        # Project features
        projected = self.feature_projection(features)  # (batch_size, max_seq_len, hidden_dim)
        
        # Pack padded sequences for efficient LSTM processing
        packed_input = nn.utils.rnn.pack_padded_sequence(
            projected, input_lengths.cpu(), batch_first=True, enforce_sorted=False
        )
        
        # LSTM processing
        packed_output, _ = self.ctc_lstm(packed_input)
        
        # Unpack sequences
        lstm_output, output_lengths = nn.utils.rnn.pad_packed_sequence(
            packed_output, batch_first=True
        )  # (batch_size, max_seq_len, hidden_dim*2)
        
        # Project to vocabulary
        logits = self.output_projection(lstm_output)  # (batch_size, max_seq_len, vocab_size)
        
        # Apply log softmax for CTC
        log_probs = self.log_softmax(logits)  # (batch_size, max_seq_len, vocab_size)
        
        return log_probs, output_lengths

class Stage4CTCModel(nn.Module):
    def __init__(self, stage3_model_path, label_encoder_path, vocab_size, 
                 hidden_dim=512, num_layers=2, dropout=0.3, device='cuda'):
        """
        Complete Stage 4 model combining Stage 3 features with CTC alignment
        
        Args:
            stage3_model_path: Path to trained Stage 3 model
            label_encoder_path: Path to Stage 3 label encoder
            vocab_size: CTC vocabulary size
            hidden_dim: CTC LSTM hidden dimension
            num_layers: Number of CTC LSTM layers
            dropout: Dropout rate
            device: Device for computation
        """
        super(Stage4CTCModel, self).__init__()
        self.device = device
        
        # Load Stage 3 model (frozen for feature extraction)
        self.stage3_model = Stage3Inference(stage3_model_path, label_encoder_path, device)
        
        # Freeze Stage 3 model
        for param in self.stage3_model.model.parameters():
            param.requires_grad = False
        
        # CTC alignment module (trainable)
        self.ctc_module = CTCAlignmentModule(
            input_dim=1024,  # Stage 3 feature dimension
            hidden_dim=hidden_dim,
            vocab_size=vocab_size,
            num_layers=num_layers,
            dropout=dropout
        )
    
    def extract_stage3_features(self, frames, frame_indexes, lengths):
        """
        Extract temporal features from Stage 3 model
        We need the LSTM hidden states, not just the final classification
        """
        # Get Stage 3 temporal features (before final classification)
        with torch.no_grad():
            # Extract MS3F and text features
            ms3f_features, text_features = self.stage3_model.model.feature_extractor.extract_combined_features(
                frames, frame_indexes, lengths, [''] * frames.shape[0]
            )
            
            # Process through Bi-LSTM to get temporal features
            batch_size, seq_len, feature_dim = ms3f_features.shape
            
            # Pass through Stage 3 LSTM
            lstm_output, _ = self.stage3_model.model.classifier.lstm(ms3f_features)
            
            # Return temporal features (batch_size, seq_len, hidden_dim*2)
            return lstm_output
    
    def forward(self, frames, frame_indexes, input_lengths):
        """
        Complete forward pass
        
        Args:
            frames: Video frames (batch_size, max_frames, 3, 112, 112)
            frame_indexes: Frame indexes (batch_size, max_frames)
            input_lengths: Actual sequence lengths (batch_size,)
            
        Returns:
            log_probs: CTC log probabilities (batch_size, max_seq_len, vocab_size)
            output_lengths: Output sequence lengths (batch_size,)
        """
        # Extract temporal features from Stage 3
        temporal_features = self.extract_stage3_features(frames, frame_indexes, input_lengths)
        
        # Apply CTC alignment
        log_probs, output_lengths = self.ctc_module(temporal_features, input_lengths)
        
        return log_probs, output_lengths

# stage4_training.py
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
import os
from tqdm import tqdm
import numpy as np

class Stage4CTCTrainer:
    def __init__(self, model, train_loader, val_loader=None, device='cuda'):
        """
        Trainer for Stage 4 CTC alignment model
        
        Args:
            model: Stage4CTCModel instance
            train_loader: Training data loader
            val_loader: Validation data loader
            device: Device for training
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Only train CTC module (Stage 3 is frozen)
        trainable_params = []
        for name, param in self.model.named_parameters():
            if 'ctc_module' in name:
                trainable_params.append(param)
        
        print(f"Training {len(trainable_params)} parameters in CTC module")
        
        # Optimizer
        self.optimizer = optim.AdamW(trainable_params, lr=1e-3, weight_decay=0.01)
        
        # Learning rate scheduler
        self.scheduler = ReduceLROnPlateau(
            self.optimizer, mode='min', factor=0.5, patience=5, verbose=True
        )
        
        # CTC Loss
        self.ctc_loss = nn.CTCLoss(blank=0, reduction='mean', zero_infinity=True)
        
        # Training metrics
        self.train_losses = []
        self.val_losses = []
    
    def train_epoch(self, epoch):
        """Train one epoch with CTC loss"""
        self.model.train()
        total_loss = 0
        num_batches = len(self.train_loader)
        
        progress_bar = tqdm(self.train_loader, desc=f'Epoch {epoch+1}')
        
        for batch_idx, batch in enumerate(progress_bar):
            frames = batch['frames'].to(self.device)
            frame_indexes = batch['frame_indexes'].to(self.device)
            input_lengths = batch['input_lengths'].to(self.device)
            targets = batch['targets'].to(self.device)
            target_lengths = batch['target_lengths'].to(self.device)
            
            self.optimizer.zero_grad()
            
            # Forward pass
            log_probs, output_lengths = self.model(frames, frame_indexes, input_lengths)
            
            # Prepare for CTC loss
            # CTC expects: (seq_len, batch_size, vocab_size)
            log_probs_ctc = log_probs.transpose(0, 1)  # (max_seq_len, batch_size, vocab_size)
            
            # CTC Loss
            loss = self.ctc_loss(
                log_probs_ctc,
                targets,
                output_lengths,
                target_lengths
            )
            
            # Handle potential infinity/NaN values
            if torch.isfinite(loss):
                # Backward pass
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer.step()
                
                total_loss += loss.item()
            else:
                print(f"Warning: Non-finite loss at batch {batch_idx}, skipping...")
            
            # Update progress bar
            avg_loss = total_loss / (batch_idx + 1) if batch_idx > 0 else 0
            progress_bar.set_postfix({
                'Loss': f'{loss.item():.4f}' if torch.isfinite(loss) else 'inf',
                'Avg Loss': f'{avg_loss:.4f}'
            })
        
        avg_loss = total_loss / num_batches
        self.train_losses.append(avg_loss)
        return avg_loss
    
    def validate(self, epoch):
        """Validate model with CTC loss"""
        if self.val_loader is None:
            return None
            
        self.model.eval()
        total_loss = 0
        valid_batches = 0
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc='Validation'):
                frames = batch['frames'].to(self.device)
                frame_indexes = batch['frame_indexes'].to(self.device)
                input_lengths = batch['input_lengths'].to(self.device)
                targets = batch['targets'].to(self.device)
                target_lengths = batch['target_lengths'].to(self.device)
                
                # Forward pass
                log_probs, output_lengths = self.model(frames, frame_indexes, input_lengths)
                
                # CTC Loss
                log_probs_ctc = log_probs.transpose(0, 1)
                loss = self.ctc_loss(
                    log_probs_ctc,
                    targets,
                    output_lengths,
                    target_lengths
                )
                
                if torch.isfinite(loss):
                    total_loss += loss.item()
                    valid_batches += 1
        
        if valid_batches > 0:
            avg_loss = total_loss / valid_batches
            self.val_losses.append(avg_loss)
            return avg_loss
        else:
            return None
    
    def train(self, num_epochs, save_dir='stage4_checkpoints'):
        """Train the CTC alignment model"""
        os.makedirs(save_dir, exist_ok=True)
        best_val_loss = float('inf')
        
        print(f"Starting Stage 4 CTC training for {num_epochs} epochs...")
        
        for epoch in range(num_epochs):
            # Training
            train_loss = self.train_epoch(epoch)
            
            # Validation
            val_loss = self.validate(epoch)
            
            # Learning rate scheduling
            if val_loss is not None:
                self.scheduler.step(val_loss)
            
            # Logging
            print(f"Epoch {epoch+1}/{num_epochs}")
            print(f"Train Loss: {train_loss:.4f}")
            if val_loss is not None:
                print(f"Val Loss: {val_loss:.4f}")
            
            # Save best model
            if val_loss is not None and val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save_model(os.path.join(save_dir, 'best_stage4_ctc.pth'))
                print(f"Saved best CTC model with validation loss: {best_val_loss:.4f}")
            
            # Save checkpoint every 10 epochs
            if (epoch + 1) % 10 == 0:
                self.save_model(os.path.join(save_dir, f'stage4_checkpoint_epoch_{epoch+1}.pth'))
        
        # Save final model
        self.save_model(os.path.join(save_dir, 'final_stage4_ctc.pth'))
        
        # Plot training curves
        self.plot_training_curves(save_dir)
        
        print("Stage 4 CTC training completed!")
        print(f"Best validation loss: {best_val_loss:.4f}")
    
    def save_model(self, path):
        """Save the trained CTC model"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'ctc_module_state_dict': self.model.ctc_module.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
            'vocab_size': self.model.ctc_module.vocab_size,
            'hidden_dim': self.model.ctc_module.hidden_dim,
            'num_layers': self.model.ctc_module.num_layers
        }, path)
    
    def plot_training_curves(self, save_dir):
        """Plot and save training curves"""
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(1, 1, figsize=(10, 6))
        
        epochs = range(1, len(self.train_losses) + 1)
        ax.plot(epochs, self.train_losses, 'b-', label='Train Loss', linewidth=2)
        
        if self.val_losses:
            ax.plot(epochs, self.val_losses, 'r-', label='Val Loss', linewidth=2)
        
        ax.set_title('Stage 4 CTC Training Curves', fontsize=14)
        ax.set_xlabel('Epochs', fontsize=12)
        ax.set_ylabel('CTC Loss', fontsize=12)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'ctc_training_curves.png'), dpi=300, bbox_inches='tight')
        plt.close()

# stage4_inference.py
import torch
import torch.nn.functional as F
import numpy as np

class Stage4CTCInference:
    def __init__(self, model_path, vocab_path, stage3_model_path, label_encoder_path, device='cuda'):
        """
        Inference class for Stage 4 CTC alignment model
        
        Args:
            model_path: Path to trained Stage 4 CTC model
            vocab_path: Path to CTC vocabulary
            stage3_model_path: Path to Stage 3 model
            label_encoder_path: Path to Stage 3 label encoder
            device: Device for computation
        """
        self.device = device
        
        # Load vocabulary
        with open(vocab_path, 'rb') as f:
            import pickle
            vocab_info = pickle.load(f)
            self.char_to_idx = vocab_info['char_to_idx']
            self.idx_to_char = vocab_info['idx_to_char']
            self.vocab_size = vocab_info['vocab_size']
        
        # Load model checkpoint
        checkpoint = torch.load(model_path, map_location=device)
        
        # Initialize model
        self.model = Stage4CTCModel(
            stage3_model_path=stage3_model_path,
            label_encoder_path=label_encoder_path,
            vocab_size=self.vocab_size,
            hidden_dim=checkpoint.get('hidden_dim', 512),
            num_layers=checkpoint.get('num_layers', 2),
            device=device
        )
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(device)
        self.model.eval()
        
        print(f"Stage 4 CTC model loaded with vocabulary size: {self.vocab_size}")
    
    def ctc_decode_greedy(self, log_probs, input_lengths):
        """
        Greedy CTC decoding
        
        Args:
            log_probs: Log probabilities (batch_size, max_seq_len, vocab_size)
            input_lengths: Input sequence lengths (batch_size,)
            
        Returns:
            decoded_texts: List of decoded text strings
        """
        batch_size = log_probs.shape[0]
        decoded_texts = []
        
        for b in range(batch_size):
            seq_len = input_lengths[b].item()
            
            # Get most probable characters at each time step
            char_probs = log_probs[b, :seq_len]  # (seq_len, vocab_size)
            char_indices = torch.argmax(char_probs, dim=1)  # (seq_len,)
            
            # CTC decoding: remove blanks and consecutive duplicates
            decoded_chars = []
            prev_char = None
            
            for char_idx in char_indices:
                char_idx = char_idx.item()
                
                # Skip blank tokens (index 0)
                if char_idx == 0:
                    prev_char = None
                    continue
                
                # Skip consecutive duplicates
                if char_idx != prev_char:
                    if char_idx in self.idx_to_char:
                        decoded_chars.append(self.idx_to_char[char_idx])
                    prev_char = char_idx
            
            decoded_text = ''.join(decoded_chars)
            decoded_texts.append(decoded_text)
        
        return decoded_texts
    
    def ctc_decode_beam_search(self, log_probs, input_lengths, beam_width=5):
        """
        Beam search CTC decoding (more accurate but slower)
        
        Args:
            log_probs: Log probabilities (batch_size, max_seq_len, vocab_size)
            input_lengths: Input sequence lengths (batch_size,)
            beam_width: Beam search width
            
        Returns:
            decoded_texts: List of decoded text strings
        """
        try:
            # Try to use torchaudio CTC beam search if available
            import torchaudio
            
            batch_size = log_probs.shape[0]
            decoded_texts = []
            
            for b in range(batch_size):
                seq_len = input_lengths[b].item()
                emissions = log_probs[b, :seq_len].unsqueeze(0)  # (1, seq_len, vocab_size)
                
                # Use torchaudio beam search decoder
                beam_results = torchaudio.functional.ctc_beam_search_decoder(
                    emissions,
                    beam_width=beam_width,
                    blank=0
                )
                
                if len(beam_results[0]) > 0:
                    # Get best hypothesis
                    best_hypothesis = beam_results[0][0]
                    char_indices = best_hypothesis.tokens
                    
                    # Convert to text
                    decoded_chars = []
                    for char_idx in char_indices:
                        if char_idx in self.idx_to_char:
                            decoded_chars.append(self.idx_to_char[char_idx])
                    
                    decoded_text = ''.join(decoded_chars)
                else:
                    decoded_text = ""
                
                decoded_texts.append(decoded_text)
            
            return decoded_texts
            
        except ImportError:
            # Fallback to greedy decoding if torchaudio not available
            print("Warning: torchaudio not available, using greedy decoding")
            return self.ctc_decode_greedy(log_probs, input_lengths)
    
    def predict(self, frames, frame_indexes, lengths, use_beam_search=True, beam_width=5):
        """
        Predict text sequences from video frames using CTC
        
        Args:
            frames: Video frames (batch_size, max_frames, 3, 112, 112)
            frame_indexes: Frame indexes (batch_size, max_frames)
            lengths: Sequence lengths (batch_size,)
            use_beam_search: Whether to use beam search decoding
            beam_width: Beam search width
            
        Returns:
            predictions: Dictionary with decoded texts and probabilities
        """
        with torch.no_grad():
            frames = frames.to(self.device)
            frame_indexes = frame_indexes.to(self.device)
            lengths = lengths.to(self.device)
            
            # Forward pass
            log_probs, output_lengths = self.model(frames, frame_indexes, lengths)
            
            # Decode sequences
            if use_beam_search:
                decoded_texts = self.ctc_decode_beam_search(log_probs, output_lengths, beam_width)
            else:
                decoded_texts = self.ctc_decode_greedy(log_probs, output_lengths)
            
            # Calculate average confidence scores
            probs = torch.exp(log_probs)
            confidence_scores = []
            
            for b in range(len(decoded_texts)):
                seq_len = output_lengths[b].item() if b < len(output_lengths) else log_probs.shape[1]
                max_probs = torch.max(probs[b, :seq_len], dim=1)[0]
                avg_confidence = torch.mean(max_probs).item()
                confidence_scores.append(avg_confidence)
            
            return {
                'decoded_texts': decoded_texts,
                'confidence_scores': confidence_scores,
                'log_probs': log_probs.cpu().numpy(),
                'output_lengths': output_lengths.cpu().numpy()
            }
    
    def predict_single(self, frames, frame_indexes=None, use_beam_search=True):
        """
        Predict text for a single video sequence
        
        Args:
            frames: Single video frames (num_frames, 3, 112, 112)
            frame_indexes: Frame indexes (optional)
            use_beam_search: Whether to use beam search
            
        Returns:
            prediction: Dictionary with decoded text and confidence
        """
        # Add batch dimension
        frames = frames.unsqueeze(0)
        
        if frame_indexes is None:
            frame_indexes = torch.arange(frames.shape[1]).unsqueeze(0)
        else:
            frame_indexes = frame_indexes.unsqueeze(0)
        
        lengths = torch.tensor([frames.shape[1]])
        
        # Get prediction
        results = self.predict(frames, frame_indexes, lengths, use_beam_search)
        
        return {
            'decoded_text': results['decoded_texts'][0],
            'confidence': results['confidence_scores'][0]
        }

# stage4_evaluation.py
import torch
import numpy as np
from tqdm import tqdm
import editdistance
from collections import defaultdict

class Stage4CTCEvaluator:
    def __init__(self, model, vocab_info, device='cuda'):
        """
        Evaluator for Stage 4 CTC model
        
        Args:
            model: Trained Stage4CTCModel
            vocab_info: Vocabulary information
            device: Device for evaluation
        """
        self.model = model
        self.vocab_info = vocab_info
        self.device = device
        self.model.eval()
    
    def calculate_edit_distance(self, predictions, targets):
        """Calculate edit distance between predictions and targets"""
        total_distance = 0
        total_length = 0
        
        for pred, target in zip(predictions, targets):
            distance = editdistance.eval(pred, target)
            total_distance += distance
            total_length += len(target)
        
        return total_distance / max(total_length, 1)
    
    def calculate_word_accuracy(self, predictions, targets):
        """Calculate word-level accuracy"""
        correct_words = 0
        total_words = 0
        
        for pred, target in zip(predictions, targets):
            pred_words = pred.split()
            target_words = target.split()
            
            # Count correct words (order matters)
            min_len = min(len(pred_words), len(target_words))
            for i in range(min_len):
                if pred_words[i] == target_words[i]:
                    correct_words += 1
            
            total_words += len(target_words)
        
        return correct_words / max(total_words, 1)
    
    def calculate_sequence_accuracy(self, predictions, targets):
        """Calculate exact sequence match accuracy"""
        correct_sequences = 0
        
        for pred, target in zip(predictions, targets):
            if pred.strip() == target.strip():
                correct_sequences += 1
        
        return correct_sequences / len(predictions)
    
    def evaluate(self, data_loader, use_beam_search=True, save_dir=None):
        """
        Comprehensive evaluation of CTC model
        
        Args:
            data_loader: Test data loader
            use_beam_search: Whether to use beam search decoding
            save_dir: Directory to save evaluation results
            
        Returns:
            evaluation_results: Dictionary with evaluation metrics
        """
        all_predictions = []
        all_targets = []
        all_confidence_scores = []
        
        self.model.eval()
        
        # Create CTC inference object
        inference = Stage4CTCInference(
            model_path='temp_model.pth',  # We'll use the loaded model directly
            vocab_path='temp_vocab.pkl',
            stage3_model_path='temp_stage3.pth',
            label_encoder_path='temp_encoder.pkl',
            device=self.device
        )
        
        # Override with current model and vocab
        inference.model = self.model
        inference.char_to_idx = self.vocab_info['char_to_idx']
        inference.idx_to_char = self.vocab_info['idx_to_char']
        inference.vocab_size = self.vocab_info['vocab_size']
        
        with torch.no_grad():
            for batch in tqdm(data_loader, desc='Evaluating CTC'):
                frames = batch['frames'].to(self.device)
                frame_indexes = batch['frame_indexes'].to(self.device)
                input_lengths = batch['input_lengths'].to(self.device)
                gloss_texts = batch['gloss_texts']
                
                # Get predictions
                results = inference.predict(
                    frames, frame_indexes, input_lengths, 
                    use_beam_search=use_beam_search
                )
                
                all_predictions.extend(results['decoded_texts'])
                all_targets.extend(gloss_texts)
                all_confidence_scores.extend(results['confidence_scores'])
        
        # Calculate metrics
        edit_distance = self.calculate_edit_distance(all_predictions, all_targets)
        word_accuracy = self.calculate_word_accuracy(all_predictions, all_targets)
        sequence_accuracy = self.calculate_sequence_accuracy(all_predictions, all_targets)
        avg_confidence = np.mean(all_confidence_scores)
        
        results = {
            'edit_distance': edit_distance,
            'word_accuracy': word_accuracy,
            'sequence_accuracy': sequence_accuracy,
            'average_confidence': avg_confidence,
            'predictions': all_predictions,
            'targets': all_targets,
            'confidence_scores': all_confidence_scores
        }
        
        # Save results if directory provided
        if save_dir:
            import os
            os.makedirs(save_dir, exist_ok=True)
            self.save_evaluation_results(results, save_dir)
        
        return results
    
    def save_evaluation_results(self, results, save_dir):
        """Save evaluation results and examples"""
        
        # Save detailed results
        with open(os.path.join(save_dir, 'ctc_evaluation_results.txt'), 'w') as f:
            f.write("Stage 4 CTC Evaluation Results\n")
            f.write("=" * 40 + "\n")
            f.write(f"Edit Distance (Character Error Rate): {results['edit_distance']:.4f}\n")
            f.write(f"Word Accuracy: {results['word_accuracy']:.4f}\n")
            f.write(f"Sequence Accuracy: {results['sequence_accuracy']:.4f}\n")
            f.write(f"Average Confidence: {results['average_confidence']:.4f}\n\n")
            
            f.write("Sample Predictions vs Targets:\n")
            f.write("-" * 40 + "\n")
            for i, (pred, target, conf) in enumerate(zip(
                results['predictions'][:20],  # First 20 samples
                results['targets'][:20],
                results['confidence_scores'][:20]
            )):
                f.write(f"Sample {i+1}:\n")
                f.write(f"  Target:     '{target}'\n")
                f.write(f"  Prediction: '{pred}'\n")
                f.write(f"  Confidence: {conf:.4f}\n")
                f.write(f"  Match: {'✓' if pred.strip() == target.strip() else '✗'}\n\n")
        
        # Plot confidence distribution
        self.plot_confidence_distribution(results['confidence_scores'], save_dir)
    
    def plot_confidence_distribution(self, confidence_scores, save_dir):
        """Plot confidence score distribution"""
        import matplotlib.pyplot as plt
        
        plt.figure(figsize=(10, 6))
        plt.hist(confidence_scores, bins=50, alpha=0.7, density=True, color='skyblue')
        plt.axvline(np.mean(confidence_scores), color='red', linestyle='--', 
                   label=f'Mean: {np.mean(confidence_scores):.3f}')
        plt.title('CTC Prediction Confidence Distribution')
        plt.xlabel('Confidence Score')
        plt.ylabel('Density')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'confidence_distribution.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()

# stage4_main.py
def main_stage4():
    """Main training script for Stage 4 CTC alignment"""
    # Configuration
    config = {
        'root_train_folder': '/home/pvvkishore/Desktop/TVC_May21/train',
        'annotations_folder': '/home/pvvkishore/Desktop/TVC_May21',
        'stage3_model_path': 'stage3_checkpoints/best_stage3_classifier.pth',
        'label_encoder_path': 'stage3_checkpoints/label_encoder.pkl',
        'batch_size': 8,  # Smaller due to CTC memory requirements
        'num_epochs': 1,
        'hidden_dim': 512,
        'num_layers': 2,
        'dropout': 0.3,
        'max_seq_length': 100,
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'save_dir': 'stage4_checkpoints',
        'train_split': 0.8,
    }
    
    print(f"Using device: {config['device']}")
    
    # Create Stage 4 dataset
    print("Loading Stage 4 CTC dataset...")
    full_loader, full_dataset = get_stage4_data_loader(
        root_train_folder=config['root_train_folder'],
        annotations_folder=config['annotations_folder'],
        stage3_model_path=config['stage3_model_path'],
        label_encoder_path=config['label_encoder_path'],
        batch_size=config['batch_size'],
        shuffle=False
    )
    
    # Save vocabulary
    os.makedirs(config['save_dir'], exist_ok=True)
    vocab_path = os.path.join(config['save_dir'], 'ctc_vocabulary.pkl')
    full_dataset.save_vocab(vocab_path)
    vocab_info = full_dataset.get_vocab_info()
    
    print(f"Dataset loaded with {len(full_dataset)} samples")
    print(f"CTC vocabulary size: {vocab_info['vocab_size']}")
    
    # Create train/validation split
    from torch.utils.data import random_split
    train_size = int(config['train_split'] * len(full_dataset))
    val_size = len(full_dataset) - train_size
    
    train_dataset, val_dataset = random_split(
        full_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=2,  # Reduced due to Stage 3 model loading
        pin_memory=True,
        collate_fn=stage4_collate_fn
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=2,
        pin_memory=True,
        collate_fn=stage4_collate_fn
    )
    
    print(f"Train samples: {len(train_dataset)}, Val samples: {len(val_dataset)}")
    
    # Initialize Stage 4 CTC model
    print("Initializing Stage 4 CTC Model...")
    stage4_model = Stage4CTCModel(
        stage3_model_path=config['stage3_model_path'],
        label_encoder_path=config['label_encoder_path'],
        vocab_size=vocab_info['vocab_size'],
        hidden_dim=config['hidden_dim'],
        num_layers=config['num_layers'],
        dropout=config['dropout'],
        device=config['device']
    )
    
    # Initialize trainer
    trainer = Stage4CTCTrainer(
        model=stage4_model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=config['device']
    )
    
    # Start training
    trainer.train(
        num_epochs=config['num_epochs'],
        save_dir=config['save_dir']
    )
    
    print("Stage 4 CTC training completed successfully!")
    
    # Evaluate on validation set
    print("\nEvaluating CTC model on validation set...")
    evaluator = Stage4CTCEvaluator(
        model=stage4_model,
        vocab_info=vocab_info,
        device=config['device']
    )
    
    eval_results = evaluator.evaluate(
        val_loader,
        use_beam_search=True,
        save_dir=os.path.join(config['save_dir'], 'evaluation')
    )
    
    print(f"Edit Distance (CER): {eval_results['edit_distance']:.4f}")
    print(f"Word Accuracy: {eval_results['word_accuracy']:.4f}")
    print(f"Sequence Accuracy: {eval_results['sequence_accuracy']:.4f}")
    print(f"Average Confidence: {eval_results['average_confidence']:.4f}")

# Complete inference pipeline
class Stage4Pipeline:
    """Complete end-to-end pipeline from video to text"""
    
    def __init__(self, stage4_model_path, vocab_path, stage3_model_path, 
                 label_encoder_path, device='cuda'):
        """
        Initialize complete Stage 4 pipeline
        
        Args:
            stage4_model_path: Path to trained Stage 4 CTC model
            vocab_path: Path to CTC vocabulary
            stage3_model_path: Path to Stage 3 model
            label_encoder_path: Path to Stage 3 label encoder
            device: Device for computation
        """
        self.ctc_inference = Stage4CTCInference(
            model_path=stage4_model_path,
            vocab_path=vocab_path,
            stage3_model_path=stage3_model_path,
            label_encoder_path=label_encoder_path,
            device=device
        )
        self.device = device
    
    def predict_from_video_path(self, video_path, use_beam_search=True):
        """
        Complete pipeline: video file → text transcription
        
        Args:
            video_path: Path to video file
            use_beam_search: Whether to use beam search decoding
            
        Returns:
            transcription: Dictionary with decoded text and confidence
        """
        import cv2
        from torchvision import transforms
        
        # Load video frames
        cap = cv2.VideoCapture(video_path)
        frames = []
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (112, 112))
            frames.append(frame)
        
        cap.release()
        
        if len(frames) == 0:
            raise ValueError("No frames found in video")
        
        # Convert to tensor and normalize
        transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((112, 112)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        frame_tensors = []
        for frame in frames:
            frame_tensor = transform(frame)
            frame_tensors.append(frame_tensor)
        
        video_tensor = torch.stack(frame_tensors)  # (num_frames, 3, 112, 112)
        
        # Get CTC prediction
        result = self.ctc_inference.predict_single(
            video_tensor, 
            use_beam_search=use_beam_search
        )
        
        return result
    
    def batch_process_videos(self, video_folder, output_file=None):
        """
        Process multiple videos and save transcriptions
        
        Args:
            video_folder: Folder containing video files
            output_file: Optional file to save results
            
        Returns:
            results: Dictionary mapping video names to transcriptions
        """
        import glob
        import json
        
        video_files = (glob.glob(os.path.join(video_folder, "*.mp4")) +
                      glob.glob(os.path.join(video_folder, "*.avi")) +
                      glob.glob(os.path.join(video_folder, "*.mov")))
        
        results = {}
        
        for video_file in tqdm(video_files, desc="Processing videos"):
            video_name = os.path.basename(video_file)
            try:
                transcription = self.predict_from_video_path(video_file)
                results[video_name] = {
                    'text': transcription['decoded_text'],
                    'confidence': transcription['confidence']
                }
                print(f"{video_name}: '{transcription['decoded_text']}' ({transcription['confidence']:.3f})")
            except Exception as e:
                print(f"Error processing {video_name}: {str(e)}")
                results[video_name] = {'error': str(e)}
        
        # Save results if output file specified
        if output_file:
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)
        
        return results

# Example usage and utilities
def example_stage4_usage():
    """Example of using Stage 4 for complete sign language transcription"""
    
    # Initialize complete pipeline
    pipeline = Stage4Pipeline(
        stage4_model_path='stage4_checkpoints/best_stage4_ctc.pth',
        vocab_path='stage4_checkpoints/ctc_vocabulary.pkl',
        stage3_model_path='stage3_checkpoints/best_stage3_classifier.pth',
        label_encoder_path='stage3_checkpoints/label_encoder.pkl'
    )
    
    # Example: Transcribe a single video
    # result = pipeline.predict_from_video_path('example_video.mp4')
    # print(f"Transcription: '{result['decoded_text']}'")
    # print(f"Confidence: {result['confidence']:.4f}")
    
    # Example: Batch process videos
    # results = pipeline.batch_process_videos(
    #     'test_videos/',
    #     'transcriptions.json'
    # )

# Utility functions
def create_demo_interface():
    """Create a simple demo interface for Stage 4"""
    try:
        import gradio as gr
        
        def transcribe_video(video_path):
            """Gradio interface function"""
            pipeline = Stage4Pipeline(
                stage4_model_path='stage4_checkpoints/best_stage4_ctc.pth',
                vocab_path='stage4_checkpoints/ctc_vocabulary.pkl',
                stage3_model_path='stage3_checkpoints/best_stage3_classifier.pth',
                label_encoder_path='stage3_checkpoints/label_encoder.pkl'
            )
            
            result = pipeline.predict_from_video_path(video_path)
            return result['decoded_text'], result['confidence']
        
        # Create Gradio interface
        interface = gr.Interface(
            fn=transcribe_video,
            inputs=gr.Video(),
            outputs=[
                gr.Textbox(label="Transcription"),
                gr.Number(label="Confidence")
            ],
            title="Sign Language Transcription",
            description="Upload a sign language video to get text transcription"
        )
        
        return interface
        
    except ImportError:
        print("Gradio not available. Install with: pip install gradio")
        return None

if __name__ == "__main__":
    # Run Stage 4 training
    main_stage4()
    
    print("\n" + "="*70)
    print("🎉 COMPLETE SIGN LANGUAGE SYSTEM - ALL STAGES COMPLETED! 🎉")
    print("="*70)
    print("✅ Stage 1: Multi-modal visual-text alignment")
    print("✅ Stage 2: Motion-selected sparse spatial features (MS3F)")
    print("✅ Stage 3: Bi-LSTM classification with attention")
    print("✅ Stage 4: CTC temporal alignment for sequence transcription")
    print("="*70)
    print("\n🚀 COMPLETE PIPELINE CAPABILITIES:")
    print("• Video → Stage 1 → Visual & Text Features")
    print("• Video → Stage 2 → Motion-Selected Spatial Features")
    print("• Video → Stage 3 → Gloss Classification")
    print("• Video → Stage 4 → Complete Text Transcription")
    print("="*70)
    print("\n🎯 READY FOR DEPLOYMENT:")
    print("• Real-time sign language recognition")
    print("• Batch video processing")
    print("• Educational applications")
    print("• Accessibility solutions")
    print("• Research and analysis tools")
    print("="*70)