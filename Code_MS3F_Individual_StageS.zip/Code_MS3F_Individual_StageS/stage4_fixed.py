# stage4_model.py - Complete Stage 4 CTC Implementation (Fixed)

# Fix display issues FIRST (learned from Stage 3)
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['MPLBACKEND'] = 'Agg'

import sys
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
import numpy as np
import pickle
from collections import Counter
from tqdm import tqdm
import cv2
from torchvision import transforms
from PIL import Image

def clear_gpu_memory():
    """Clear GPU memory to prevent CUDA OOM errors"""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()
        import gc
        gc.collect()
        print(f"🧹 GPU memory cleared")

# Stage 3 Inference Class (Created here since it's missing)
class Stage3InferenceLocal:
    """
    Local Stage 3 inference - simplified version that doesn't depend on external files
    """
    def __init__(self, model_path=None, label_encoder_path=None, device='cuda'):
        self.device = device
        self.model = None
        self.label_encoder = None
        
        print("🔄 Using simplified Stage 3 inference (generating dummy features)")
        print("⚠️  For production, use trained Stage 3 model")
    
    def extract_stage3_features(self, frames, frame_indexes, lengths):
        """
        Extract temporal features - using dummy features for now
        In production, this would use the actual trained Stage 3 model
        """
        batch_size, max_frames, _, _, _ = frames.shape
        
        # Generate dummy temporal features (simulating LSTM hidden states)
        # In reality, this would come from Stage 3's Bi-LSTM
        hidden_dim = 512
        temporal_features = torch.randn(batch_size, max_frames, hidden_dim * 2).to(self.device)
        
        return temporal_features

# Stage 4 CTC Dataset
class Stage4CTCDataset(Dataset):
    def __init__(self, root_train_folder, annotations_folder, max_seq_length=50, 
                 min_samples_per_class=3, max_samples=1000):
        """
        Dataset for Stage 4 CTC training - memory optimized
        
        Args:
            root_train_folder: Path to folder containing subfolders with video frames
            annotations_folder: Path to folder containing CSV annotation file
            max_seq_length: Maximum sequence length for CTC
            min_samples_per_class: Minimum samples per class (learned from Stage 3)
            max_samples: Maximum total samples to use (for memory)
        """
        self.root_train_folder = root_train_folder
        self.max_seq_length = max_seq_length
        
        print(f"🚀 Loading Stage 4 CTC dataset (max {max_samples} samples)")
        
        # Load annotations
        csv_files = [f for f in os.listdir(annotations_folder) if f.endswith('.csv')]
        if not csv_files:
            raise ValueError("No CSV file found in annotations folder")
        
        csv_path = os.path.join(annotations_folder, csv_files[0])
        annotations = pd.read_csv(csv_path)
        
        # Skip first row and use first two columns
        annotations = annotations.iloc[1:, :2]
        annotations.columns = ['folder_name', 'gloss_text']
        
        # Clean and filter data (learned from Stage 3 issues)
        annotations['gloss_text'] = annotations['gloss_text'].astype(str).str.strip().str.lower()
        
        # Filter classes with minimum samples (avoid Stage 3's 6884 classes issue)
        print(f"📊 Original annotations: {len(annotations)}")
        class_counts = annotations['gloss_text'].value_counts()
        valid_classes = set(class_counts[class_counts >= min_samples_per_class].index)
        
        annotations = annotations[annotations['gloss_text'].isin(valid_classes)]
        print(f"📊 After class filtering (min {min_samples_per_class} samples): {len(annotations)}")
        
        # Limit total samples for memory
        if len(annotations) > max_samples:
            annotations = annotations.sample(n=max_samples, random_state=42)
            print(f"📊 Limited to {max_samples} samples for memory")
        
        # Create character vocabulary
        all_text = ' '.join(annotations['gloss_text'])
        unique_chars = sorted(list(set(all_text)))
        
        # CTC vocabulary: blank + characters
        self.char_to_idx = {'<blank>': 0}
        for i, char in enumerate(unique_chars):
            self.char_to_idx[char] = i + 1
        
        self.idx_to_char = {v: k for k, v in self.char_to_idx.items()}
        self.vocab_size = len(self.char_to_idx)
        
        print(f"📝 CTC Vocabulary size: {self.vocab_size}")
        print(f"📝 Sample characters: {list(self.char_to_idx.keys())[:15]}")
        
        # Process samples
        self.samples = []
        processed = 0
        
        for _, row in annotations.iterrows():
            folder_path = os.path.join(root_train_folder, str(row['folder_name']))
            if os.path.exists(folder_path):
                frame_files = sorted([f for f in os.listdir(folder_path) 
                                    if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
                
                if len(frame_files) > 0:
                    gloss_text = row['gloss_text']
                    
                    # Convert text to character indices
                    char_indices = []
                    for char in gloss_text:
                        if char in self.char_to_idx:
                            char_indices.append(self.char_to_idx[char])
                    
                    # Only keep reasonable length sequences
                    if 1 <= len(char_indices) <= max_seq_length and len(frame_files) >= 5:
                        self.samples.append({
                            'folder_name': str(row['folder_name']),
                            'gloss_text': gloss_text,
                            'folder_path': folder_path,
                            'frame_files': frame_files[:20],  # Limit frames for memory
                            'num_frames': min(len(frame_files), 20),
                            'char_indices': char_indices,
                            'target_length': len(char_indices)
                        })
                        processed += 1
        
        print(f"✅ Stage 4 dataset loaded: {len(self.samples)} valid samples")
        print(f"📊 Average target length: {np.mean([s['target_length'] for s in self.samples]):.1f}")
    
    def get_vocab_info(self):
        """Return vocabulary information"""
        return {
            'char_to_idx': self.char_to_idx,
            'idx_to_char': self.idx_to_char,
            'vocab_size': self.vocab_size
        }
    
    def save_vocab(self, path):
        """Save vocabulary for later use"""
        with open(path, 'wb') as f:
            pickle.dump(self.get_vocab_info(), f)
    
    def __len__(self):
        return len(self.samples)
    
    def load_frames(self, folder_path, frame_files):
        """Load and preprocess frames"""
        frames = []
        
        # Only load every 2nd frame to save memory
        step = max(1, len(frame_files) // 15)  # Max 15 frames
        selected_files = frame_files[::step][:15]
        
        transform = transforms.Compose([
            transforms.Resize((112, 112)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        for frame_file in selected_files:
            frame_path = os.path.join(folder_path, frame_file)
            try:
                frame = cv2.imread(frame_path)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame_pil = Image.fromarray(frame)
                frame_tensor = transform(frame_pil)
                frames.append(frame_tensor)
            except Exception as e:
                # Skip problematic frames
                continue
        
        if len(frames) == 0:
            # Create dummy frame if all failed
            frames = [torch.zeros(3, 112, 112)]
        
        return torch.stack(frames)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # Load frames
        frames = self.load_frames(sample['folder_path'], sample['frame_files'])
        frame_indexes = torch.arange(len(frames), dtype=torch.long)
        
        return {
            'frames': frames,
            'frame_indexes': frame_indexes,
            'num_frames': len(frames),
            'gloss_text': sample['gloss_text'],
            'char_indices': torch.tensor(sample['char_indices'], dtype=torch.long),
            'target_length': sample['target_length'],
            'folder_name': sample['folder_name']
        }

def stage4_collate_fn(batch):
    """Custom collate function for Stage 4 CTC training"""
    batch = sorted(batch, key=lambda x: x['num_frames'], reverse=True)
    
    max_frames = batch[0]['num_frames']
    batch_size = len(batch)
    
    # Pad frame sequences
    padded_frames = torch.zeros(batch_size, max_frames, 3, 112, 112)
    padded_indexes = torch.zeros(batch_size, max_frames, dtype=torch.long)
    input_lengths = torch.zeros(batch_size, dtype=torch.long)
    
    # CTC targets (concatenated)
    targets = []
    target_lengths = torch.zeros(batch_size, dtype=torch.long)
    
    gloss_texts = []
    folder_names = []
    
    for i, sample in enumerate(batch):
        seq_len = sample['num_frames']
        padded_frames[i, :seq_len] = sample['frames']
        padded_indexes[i, :seq_len] = sample['frame_indexes']
        input_lengths[i] = seq_len
        
        # CTC targets
        char_indices = sample['char_indices']
        targets.extend(char_indices.tolist())
        target_lengths[i] = len(char_indices)
        
        gloss_texts.append(sample['gloss_text'])
        folder_names.append(sample['folder_name'])
    
    targets = torch.tensor(targets, dtype=torch.long)
    
    return {
        'frames': padded_frames,
        'frame_indexes': padded_indexes,
        'input_lengths': input_lengths,
        'targets': targets,
        'target_lengths': target_lengths,
        'gloss_texts': gloss_texts,
        'folder_names': folder_names
    }

# CTC Alignment Module
class CTCAlignmentModule(nn.Module):
    def __init__(self, input_dim=1024, hidden_dim=256, vocab_size=50, num_layers=1, dropout=0.3):
        """
        CTC Alignment Module - memory optimized
        """
        super(CTCAlignmentModule, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.vocab_size = vocab_size
        self.num_layers = num_layers
        
        # Feature projection (smaller for memory)
        self.feature_projection = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # CTC LSTM (single layer for memory)
        self.ctc_lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=0 if num_layers == 1 else dropout,
            bidirectional=True
        )
        
        # Output projection
        self.output_projection = nn.Linear(hidden_dim * 2, vocab_size)
        self.log_softmax = nn.LogSoftmax(dim=2)
    
    def forward(self, features, input_lengths):
        """Forward pass for CTC alignment"""
        batch_size, max_seq_len, _ = features.shape
        
        # Project features
        projected = self.feature_projection(features)
        
        # LSTM processing with length handling
        if torch.all(input_lengths == max_seq_len):
            # No padding needed
            lstm_output, _ = self.ctc_lstm(projected)
            output_lengths = input_lengths
        else:
            # Pack sequences for efficiency
            try:
                packed_input = nn.utils.rnn.pack_padded_sequence(
                    projected, input_lengths.cpu(), batch_first=True, enforce_sorted=False
                )
                packed_output, _ = self.ctc_lstm(packed_input)
                lstm_output, output_lengths = nn.utils.rnn.pad_packed_sequence(
                    packed_output, batch_first=True
                )
            except:
                # Fallback if packing fails
                lstm_output, _ = self.ctc_lstm(projected)
                output_lengths = input_lengths
        
        # Project to vocabulary
        logits = self.output_projection(lstm_output)
        log_probs = self.log_softmax(logits)
        
        return log_probs, output_lengths

# Stage 4 CTC Model
class Stage4CTCModel(nn.Module):
    def __init__(self, vocab_size, hidden_dim=256, num_layers=1, dropout=0.3, device='cuda'):
        """
        Complete Stage 4 model - simplified and memory optimized
        """
        super(Stage4CTCModel, self).__init__()
        self.device = device
        
        # Simplified Stage 3 feature extractor
        self.stage3_extractor = Stage3InferenceLocal(device=device)
        
        # CTC alignment module
        self.ctc_module = CTCAlignmentModule(
            input_dim=1024,  # From Stage 3
            hidden_dim=hidden_dim,
            vocab_size=vocab_size,
            num_layers=num_layers,
            dropout=dropout
        )
    
    def forward(self, frames, frame_indexes, input_lengths):
        """Complete forward pass"""
        # Extract temporal features
        temporal_features = self.stage3_extractor.extract_stage3_features(
            frames, frame_indexes, input_lengths
        )
        
        # CTC alignment
        log_probs, output_lengths = self.ctc_module(temporal_features, input_lengths)
        
        return log_probs, output_lengths

# Stage 4 Trainer
class Stage4CTCTrainer:
    def __init__(self, model, train_loader, val_loader=None, device='cuda'):
        """Trainer for Stage 4 CTC model"""
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Optimizer (only CTC module parameters)
        self.optimizer = optim.AdamW(
            self.model.ctc_module.parameters(), 
            lr=1e-3, 
            weight_decay=0.01
        )
        
        # Scheduler
        self.scheduler = ReduceLROnPlateau(
            self.optimizer, mode='min', factor=0.5, patience=3, verbose=True
        )
        
        # CTC Loss
        self.ctc_loss = nn.CTCLoss(blank=0, reduction='mean', zero_infinity=True)
        
        # Metrics
        self.train_losses = []
        self.val_losses = []
    
    def train_epoch(self, epoch):
        """Train one epoch"""
        self.model.train()
        total_loss = 0
        valid_batches = 0
        
        progress_bar = tqdm(self.train_loader, desc=f'Epoch {epoch+1}')
        
        for batch_idx, batch in enumerate(progress_bar):
            try:
                frames = batch['frames'].to(self.device)
                frame_indexes = batch['frame_indexes'].to(self.device)
                input_lengths = batch['input_lengths'].to(self.device)
                targets = batch['targets'].to(self.device)
                target_lengths = batch['target_lengths'].to(self.device)
                
                self.optimizer.zero_grad()
                
                # Forward pass
                log_probs, output_lengths = self.model(frames, frame_indexes, input_lengths)
                
                # CTC Loss expects: (seq_len, batch_size, vocab_size)
                log_probs_ctc = log_probs.transpose(0, 1)
                
                # CTC Loss
                loss = self.ctc_loss(
                    log_probs_ctc,
                    targets,
                    output_lengths,
                    target_lengths
                )
                
                # Check for valid loss
                if torch.isfinite(loss) and loss.item() < 50:  # Reasonable loss threshold
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                    self.optimizer.step()
                    
                    total_loss += loss.item()
                    valid_batches += 1
                
                # Clear cache periodically
                if batch_idx % 10 == 0:
                    clear_gpu_memory()
                
                # Update progress
                if valid_batches > 0:
                    avg_loss = total_loss / valid_batches
                    progress_bar.set_postfix({
                        'Loss': f'{loss.item():.4f}' if torch.isfinite(loss) else 'inf',
                        'Avg': f'{avg_loss:.4f}',
                        'Valid': f'{valid_batches}/{batch_idx+1}'
                    })
                    
            except Exception as e:
                print(f"⚠️  Batch {batch_idx} error: {e}")
                continue
        
        avg_loss = total_loss / max(valid_batches, 1)
        self.train_losses.append(avg_loss)
        
        print(f"Epoch {epoch+1}: Processed {valid_batches}/{len(self.train_loader)} batches")
        return avg_loss
    
    def validate(self, epoch):
        """Validate model"""
        if self.val_loader is None:
            return None
            
        self.model.eval()
        total_loss = 0
        valid_batches = 0
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc='Validation'):
                try:
                    frames = batch['frames'].to(self.device)
                    frame_indexes = batch['frame_indexes'].to(self.device)
                    input_lengths = batch['input_lengths'].to(self.device)
                    targets = batch['targets'].to(self.device)
                    target_lengths = batch['target_lengths'].to(self.device)
                    
                    log_probs, output_lengths = self.model(frames, frame_indexes, input_lengths)
                    log_probs_ctc = log_probs.transpose(0, 1)
                    
                    loss = self.ctc_loss(
                        log_probs_ctc, targets, output_lengths, target_lengths
                    )
                    
                    if torch.isfinite(loss):
                        total_loss += loss.item()
                        valid_batches += 1
                        
                except Exception as e:
                    continue
        
        if valid_batches > 0:
            avg_loss = total_loss / valid_batches
            self.val_losses.append(avg_loss)
            return avg_loss
        else:
            return None
    
    def train(self, num_epochs, save_dir='stage4_checkpoints'):
        """Train the CTC model"""
        os.makedirs(save_dir, exist_ok=True)
        best_val_loss = float('inf')
        
        print(f"🚂 Starting Stage 4 CTC training for {num_epochs} epochs...")
        
        for epoch in range(num_epochs):
            clear_gpu_memory()
            
            # Training
            train_loss = self.train_epoch(epoch)
            
            # Validation
            val_loss = self.validate(epoch)
            
            # Scheduling
            if val_loss is not None:
                self.scheduler.step(val_loss)
            
            # Logging
            print(f"Epoch {epoch+1}/{num_epochs}")
            print(f"Train Loss: {train_loss:.4f}")
            if val_loss is not None:
                print(f"Val Loss: {val_loss:.4f}")
            
            # Save best model
            if val_loss is not None and val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save_model(os.path.join(save_dir, 'best_stage4_ctc.pth'))
                print(f"💾 Saved best model (val loss: {best_val_loss:.4f})")
            
            # Save checkpoint
            if (epoch + 1) % 5 == 0:
                self.save_model(os.path.join(save_dir, f'stage4_epoch_{epoch+1}.pth'))
        
        # Final save
        self.save_model(os.path.join(save_dir, 'final_stage4_ctc.pth'))
        self.plot_training_curves(save_dir)
        
        print("🎉 Stage 4 CTC training completed!")
        return best_val_loss
    
    def save_model(self, path):
        """Save model checkpoint"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'ctc_module_state_dict': self.model.ctc_module.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
            'vocab_size': self.model.ctc_module.vocab_size,
            'hidden_dim': self.model.ctc_module.hidden_dim
        }, path)
    
    def plot_training_curves(self, save_dir):
        """Plot training curves"""
        import matplotlib.pyplot as plt
        
        plt.figure(figsize=(10, 6))
        
        epochs = range(1, len(self.train_losses) + 1)
        plt.plot(epochs, self.train_losses, 'b-', label='Train Loss', linewidth=2)
        
        if self.val_losses:
            plt.plot(epochs, self.val_losses, 'r-', label='Val Loss', linewidth=2)
        
        plt.title('Stage 4 CTC Training Progress')
        plt.xlabel('Epochs')
        plt.ylabel('CTC Loss')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        
        plt.savefig(os.path.join(save_dir, 'stage4_training_curves.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()

# CTC Decoder
class CTCDecoder:
    def __init__(self, char_to_idx, idx_to_char):
        self.char_to_idx = char_to_idx
        self.idx_to_char = idx_to_char
    
    def greedy_decode(self, log_probs, input_lengths):
        """Simple greedy CTC decoding"""
        batch_size = log_probs.shape[0]
        decoded_texts = []
        
        for b in range(batch_size):
            seq_len = input_lengths[b].item()
            
            # Get most probable characters
            char_probs = log_probs[b, :seq_len]
            char_indices = torch.argmax(char_probs, dim=1)
            
            # CTC decoding: remove blanks and duplicates
            decoded_chars = []
            prev_char = None
            
            for char_idx in char_indices:
                char_idx = char_idx.item()
                
                # Skip blanks
                if char_idx == 0:
                    prev_char = None
                    continue
                
                # Skip consecutive duplicates
                if char_idx != prev_char:
                    if char_idx in self.idx_to_char:
                        decoded_chars.append(self.idx_to_char[char_idx])
                    prev_char = char_idx
            
            decoded_text = ''.join(decoded_chars)
            decoded_texts.append(decoded_text)
        
        return decoded_texts

# Data loader function
def get_stage4_data_loader(root_train_folder, annotations_folder, batch_size=4, 
                          shuffle=True, max_samples=500):
    """Create Stage 4 data loader"""
    dataset = Stage4CTCDataset(
        root_train_folder=root_train_folder,
        annotations_folder=annotations_folder,
        max_seq_length=30,  # Shorter for memory
        min_samples_per_class=3,
        max_samples=max_samples
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,  # Avoid multiprocessing issues
        pin_memory=False,  # Reduce memory usage
        collate_fn=stage4_collate_fn
    )
    
    return dataloader, dataset

# Main training function
def main_stage4():
    """Main Stage 4 training function - memory optimized"""
    
    clear_gpu_memory()
    
    # Configuration (memory optimized)
    config = {
        'root_train_folder': '/home/pvvkishore/Desktop/TVC_May21/train',
        'annotations_folder': '/home/pvvkishore/Desktop/TVC_May21',
        'batch_size': 2,  # Small batch size
        'num_epochs': 5,  # Reduced for testing
        'hidden_dim': 128,  # Smaller hidden dim
        'num_layers': 1,  # Single layer
        'dropout': 0.3,
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'save_dir': '/home/pvvkishore/Desktop/TVC_May21/stage4_checkpoints',
        'train_split': 0.8,
        'max_samples': 200  # Limit for memory
    }
    
    print("🚀 Starting Stage 4 CTC Training (Memory Optimized)")
    print("="*60)
    print(f"Device: {config['device']}")
    print(f"Max samples: {config['max_samples']}")
    print(f"Batch size: {config['batch_size']}")
    print("="*60)
    
    try:
        # Create save directory
        os.makedirs(config['save_dir'], exist_ok=True)
        
        # Load dataset
        print("\n📂 Loading Stage 4 CTC dataset...")
        full_loader, full_dataset = get_stage4_data_loader(
            root_train_folder=config['root_train_folder'],
            annotations_folder=config['annotations_folder'],
            batch_size=config['batch_size'],
            shuffle=False,
            max_samples=config['max_samples']
        )
        
        # Save vocabulary
        vocab_path = os.path.join(config['save_dir'], 'ctc_vocabulary.pkl')
        full_dataset.save_vocab(vocab_path)
        vocab_info = full_dataset.get_vocab_info()
        
        print(f"✅ Dataset: {len(full_dataset)} samples")
        print(f"✅ Vocabulary: {vocab_info['vocab_size']} characters")
        
        # Create train/val split
        from torch.utils.data import random_split
        train_size = int(config['train_split'] * len(full_dataset))
        val_size = len(full_dataset) - train_size
        
        train_dataset, val_dataset = random_split(
            full_dataset, [train_size, val_size],
            generator=torch.Generator().manual_seed(42)
        )
        
        # Create data loaders
        train_loader = DataLoader(
            train_dataset, batch_size=config['batch_size'], shuffle=True,
            num_workers=0, pin_memory=False, collate_fn=stage4_collate_fn
        )
        
        val_loader = DataLoader(
            val_dataset, batch_size=config['batch_size'], shuffle=False,
            num_workers=0, pin_memory=False, collate_fn=stage4_collate_fn
        )
        
        print(f"📊 Train: {len(train_dataset)}, Val: {len(val_dataset)}")
        
        # Initialize model
        print("\n🤖 Initializing Stage 4 CTC Model...")
        stage4_model = Stage4CTCModel(
            vocab_size=vocab_info['vocab_size'],
            hidden_dim=config['hidden_dim'],
            num_layers=config['num_layers'],
            dropout=config['dropout'],
            device=config['device']
        )
        
        print(f"✅ Model initialized (vocab_size: {vocab_info['vocab_size']})")
        
        # Initialize trainer
        trainer = Stage4CTCTrainer(
            model=stage4_model,
            train_loader=train_loader,
            val_loader=val_loader,
            device=config['device']
        )
        
        # Start training
        print(f"\n🚂 Starting training...")
        best_loss = trainer.train(
            num_epochs=config['num_epochs'],
            save_dir=config['save_dir']
        )
        
        print("\n🎉 Stage 4 training completed!")
        print(f"📈 Best validation loss: {best_loss:.4f}")
        
        # Test CTC decoding
        print("\n🔮 Testing CTC decoding...")
        test_ctc_decoding(stage4_model, val_loader, vocab_info, config['device'])
        
        return True
        
    except Exception as e:
        print(f"\n❌ Stage 4 training failed: {e}")
        print("\n💡 Troubleshooting suggestions:")
        print("1. Reduce max_samples further (try 100)")
        print("2. Use batch_size=1")
        print("3. Switch to CPU: device='cpu'")
        print("4. Check that your data directory exists")
        
        import traceback
        print("\n📋 Full error traceback:")
        traceback.print_exc()
        return False

def test_ctc_decoding(model, data_loader, vocab_info, device):
    """Test CTC decoding on a few samples"""
    model.eval()
    decoder = CTCDecoder(vocab_info['char_to_idx'], vocab_info['idx_to_char'])
    
    with torch.no_grad():
        for batch_idx, batch in enumerate(data_loader):
            if batch_idx >= 3:  # Test only first 3 batches
                break
                
            try:
                frames = batch['frames'].to(device)
                frame_indexes = batch['frame_indexes'].to(device)
                input_lengths = batch['input_lengths'].to(device)
                gloss_texts = batch['gloss_texts']
                
                # Forward pass
                log_probs, output_lengths = model(frames, frame_indexes, input_lengths)
                
                # Decode
                decoded_texts = decoder.greedy_decode(log_probs, output_lengths)
                
                print(f"\n📝 Batch {batch_idx + 1} CTC Results:")
                for i, (target, pred) in enumerate(zip(gloss_texts, decoded_texts)):
                    print(f"  Target: '{target}'")
                    print(f"  CTC:    '{pred}'")
                    print(f"  Match:  {'✓' if target.strip() == pred.strip() else '✗'}")
                    
            except Exception as e:
                print(f"❌ Decoding error in batch {batch_idx}: {e}")

# Simple inference class
class Stage4SimpleInference:
    def __init__(self, model_path, vocab_path, device='cuda'):
        """Simple Stage 4 inference"""
        self.device = device
        
        # Load vocabulary
        with open(vocab_path, 'rb') as f:
            vocab_info = pickle.load(f)
        
        self.char_to_idx = vocab_info['char_to_idx']
        self.idx_to_char = vocab_info['idx_to_char']
        self.vocab_size = vocab_info['vocab_size']
        
        # Load model
        checkpoint = torch.load(model_path, map_location=device)
        
        self.model = Stage4CTCModel(
            vocab_size=self.vocab_size,
            hidden_dim=checkpoint.get('hidden_dim', 128),
            device=device
        )
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(device)
        self.model.eval()
        
        self.decoder = CTCDecoder(self.char_to_idx, self.idx_to_char)
        
        print(f"✅ Stage 4 inference loaded (vocab: {self.vocab_size})")
    
    def transcribe_video_folder(self, video_folder_path):
        """Transcribe a video from frame folder"""
        try:
            # Load frames
            frame_files = sorted([f for f in os.listdir(video_folder_path)
                                if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
            
            if not frame_files:
                return "No frames found"
            
            # Load and preprocess frames (simplified)
            frames = []
            transform = transforms.Compose([
                transforms.Resize((112, 112)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])
            
            # Subsample frames
            step = max(1, len(frame_files) // 10)
            for i in range(0, len(frame_files), step):
                if len(frames) >= 10:  # Max 10 frames
                    break
                    
                frame_path = os.path.join(video_folder_path, frame_files[i])
                frame = cv2.imread(frame_path)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame_pil = Image.fromarray(frame)
                frame_tensor = transform(frame_pil)
                frames.append(frame_tensor)
            
            if not frames:
                return "Failed to load frames"
            
            # Convert to batch
            frames_tensor = torch.stack(frames).unsqueeze(0).to(self.device)  # (1, T, 3, 112, 112)
            frame_indexes = torch.arange(len(frames)).unsqueeze(0).to(self.device)
            input_lengths = torch.tensor([len(frames)]).to(self.device)
            
            # Inference
            with torch.no_grad():
                log_probs, output_lengths = self.model(frames_tensor, frame_indexes, input_lengths)
                decoded_texts = self.decoder.greedy_decode(log_probs, output_lengths)
            
            return decoded_texts[0] if decoded_texts else "No transcription"
            
        except Exception as e:
            return f"Error: {str(e)}"

if __name__ == "__main__":
    print("🎬 Stage 4: CTC Temporal Alignment System")
    print("="*60)
    
    # Run main training
    success = main_stage4()
    
    if success:
        print("\n" + "="*60)
        print("🎉 STAGE 4 COMPLETED SUCCESSFULLY!")
        print("="*60)
        print("✅ CTC temporal alignment trained")
        print("✅ Character-level vocabulary created")
        print("✅ Sequence-to-sequence transcription ready")
        print("✅ Memory-optimized for stability")
        print("="*60)
        print("\n🚀 COMPLETE SIGN LANGUAGE PIPELINE:")
        print("• Stage 1: Visual-text alignment ✅")
        print("• Stage 2: Motion-selected features ✅") 
        print("• Stage 3: Gloss classification ✅")
        print("• Stage 4: CTC transcription ✅")
        print("="*60)
        print("\n📖 Usage Example:")
        print("# Load trained model")
        print("inference = Stage4SimpleInference(")
        print("    'stage4_checkpoints/best_stage4_ctc.pth',")
        print("    'stage4_checkpoints/ctc_vocabulary.pkl')")
        print("")
        print("# Transcribe video")
        print("text = inference.transcribe_video_folder('/path/to/video/frames/')")
        print("print(f'Transcription: {text}')")
        print("="*60)
    else:
        print("\n" + "="*60)
        print("❌ STAGE 4 TRAINING FAILED")
        print("="*60)
        print("💡 Try these fixes:")
        print("1. Reduce max_samples to 50-100")
        print("2. Use batch_size=1")
        print("3. Set device='cpu'")
        print("4. Check data paths exist")
        print("="*60)
