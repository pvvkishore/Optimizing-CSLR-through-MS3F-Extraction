# data_loader.py
import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
import cv2
import numpy as np
import random

class SignLanguageDataset(Dataset):
    def __init__(self, root_train_folder, annotations_folder, transform=None, max_frames=16):
        """
        Args:
            root_train_folder: Path to folder containing subfolders with video frames
            annotations_folder: Path to folder containing CSV annotation file
            transform: Optional transform to be applied on frames
            max_frames: Maximum number of frames to sample from each video
        """
        self.root_train_folder = root_train_folder
        self.transform = transform
        self.max_frames = max_frames
        
        # Load annotations
        csv_files = [f for f in os.listdir(annotations_folder) if f.endswith('.csv')]
        if not csv_files:
            raise ValueError("No CSV file found in annotations folder")
        
        csv_path = os.path.join(annotations_folder, csv_files[0])
        self.annotations = pd.read_csv(csv_path)
        
        # Skip first row and use first two columns
        self.annotations = self.annotations.iloc[1:, :2]
        self.annotations.columns = ['folder_name', 'gloss_text']
        
        # Filter annotations to only include existing folders
        self.valid_annotations = []
        for _, row in self.annotations.iterrows():
            folder_path = os.path.join(root_train_folder, str(row['folder_name']))
            if os.path.exists(folder_path):
                self.valid_annotations.append({
                    'folder_name': str(row['folder_name']),
                    'gloss_text': str(row['gloss_text']),
                    'folder_path': folder_path
                })
        
        print(f"Loaded {len(self.valid_annotations)} valid samples")
    
    def __len__(self):
        return len(self.valid_annotations)
    
    def load_frames(self, folder_path):
        """Load and sample frames from video folder"""
        frame_files = sorted([f for f in os.listdir(folder_path) 
                            if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
        
        if len(frame_files) == 0:
            raise ValueError(f"No image files found in {folder_path}")
        
        # Sample frames uniformly if there are more than max_frames
        if len(frame_files) > self.max_frames:
            indices = np.linspace(0, len(frame_files)-1, self.max_frames, dtype=int)
            frame_files = [frame_files[i] for i in indices]
        
        frames = []
        for frame_file in frame_files:
            frame_path = os.path.join(folder_path, frame_file)
            frame = cv2.imread(frame_path)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (112, 112))
            frames.append(frame)
        
        # Pad with last frame if necessary
        while len(frames) < self.max_frames:
            frames.append(frames[-1])
        
        return np.stack(frames)
    
    def __getitem__(self, idx):
        sample = self.valid_annotations[idx]
        
        # Load frames
        frames = self.load_frames(sample['folder_path'])
        
        # Apply transforms
        if self.transform:
            transformed_frames = []
            for frame in frames:
                frame_pil = Image.fromarray(frame)
                transformed_frame = self.transform(frame_pil)
                transformed_frames.append(transformed_frame)
            frames = torch.stack(transformed_frames)
        else:
            frames = torch.from_numpy(frames).permute(0, 3, 1, 2).float() / 255.0
        
        return {
            'frames': frames,
            'gloss_text': sample['gloss_text'],
            'folder_name': sample['folder_name']
        }

def get_data_loader(root_train_folder, annotations_folder, batch_size=16, shuffle=True, num_workers=4):
    """Create data loader with appropriate transforms"""
    transform = transforms.Compose([
        transforms.Resize((112, 112)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    dataset = SignLanguageDataset(
        root_train_folder=root_train_folder,
        annotations_folder=annotations_folder,
        transform=transform
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return dataloader, dataset

# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import resnet50
from transformers import BertTokenizer, BertModel
import math

class VisualEncoder(nn.Module):
    def __init__(self, feature_dim=1024):
        super(VisualEncoder, self).__init__()
        # Load pre-trained ResNet-50
        self.resnet = resnet50(pretrained=True)
        
        # Remove the final classification layer
        self.resnet = nn.Sequential(*list(self.resnet.children())[:-1])
        
        # Add projection layer
        self.projection = nn.Sequential(
            nn.Linear(2048, 2048),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(2048, feature_dim),
            nn.LayerNorm(feature_dim)
        )
        
        # Temporal aggregation
        self.temporal_pool = nn.AdaptiveAvgPool1d(1)
        
    def forward(self, x):
        # x shape: (batch_size, num_frames, 3, 112, 112)
        batch_size, num_frames = x.shape[:2]
        
        # Reshape to process all frames at once
        x = x.view(-1, 3, 112, 112)
        
        # Extract features with ResNet
        features = self.resnet(x)  # (batch_size * num_frames, 2048, 1, 1)
        features = features.view(batch_size, num_frames, -1)  # (batch_size, num_frames, 2048)
        
        # Temporal aggregation (simple average)
        features = features.mean(dim=1)  # (batch_size, 2048)
        
        # Project to final dimension
        features = self.projection(features)  # (batch_size, feature_dim)
        
        return features

class TextEncoder(nn.Module):
    def __init__(self, feature_dim=1024, bert_model='bert-base-uncased'):
        super(TextEncoder, self).__init__()
        self.tokenizer = BertTokenizer.from_pretrained(bert_model)
        self.bert = BertModel.from_pretrained(bert_model)
        
        # Freeze BERT parameters initially
        for param in self.bert.parameters():
            param.requires_grad = False
        
        # Unfreeze last few layers for fine-tuning
        for param in self.bert.encoder.layer[-2:].parameters():
            param.requires_grad = True
        
        # Projection layer
        self.projection = nn.Sequential(
            nn.Linear(768, 1536),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(1536, feature_dim),
            nn.LayerNorm(feature_dim)
        )
    
    def forward(self, text_list):
        # Tokenize text
        encoded = self.tokenizer(
            text_list,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors='pt',
            return_attention_mask=True
        )
        
        # Move to device
        device = next(self.parameters()).device
        input_ids = encoded['input_ids'].to(device)
        attention_mask = encoded['attention_mask'].to(device)
        
        # Get BERT embeddings
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        
        # Use [CLS] token embedding
        text_features = outputs.last_hidden_state[:, 0, :]  # (batch_size, 768)
        
        # Project to final dimension
        text_features = self.projection(text_features)  # (batch_size, feature_dim)
        
        return text_features

class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.07):
        super(ContrastiveLoss, self).__init__()
        self.temperature = temperature
    
    def forward(self, visual_features, text_features):
        # Normalize features
        visual_features = F.normalize(visual_features, dim=1)
        text_features = F.normalize(text_features, dim=1)
        
        # Compute similarity matrix
        similarity_matrix = torch.matmul(visual_features, text_features.T) / self.temperature
        
        batch_size = similarity_matrix.shape[0]
        labels = torch.arange(batch_size).to(similarity_matrix.device)
        
        # Compute cross-entropy loss for both directions
        loss_v2t = F.cross_entropy(similarity_matrix, labels)
        loss_t2v = F.cross_entropy(similarity_matrix.T, labels)
        
        return (loss_v2t + loss_t2v) / 2

class SignLanguageModel(nn.Module):
    def __init__(self, feature_dim=1024):
        super(SignLanguageModel, self).__init__()
        self.visual_encoder = VisualEncoder(feature_dim)
        self.text_encoder = TextEncoder(feature_dim)
        self.contrastive_loss = ContrastiveLoss()
        
    def forward(self, frames, text_list, return_features=False):
        visual_features = self.visual_encoder(frames)
        text_features = self.text_encoder(text_list)
        
        if return_features:
            return visual_features, text_features
        
        loss = self.contrastive_loss(visual_features, text_features)
        return loss, visual_features, text_features

# training.py
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
import os
from tqdm import tqdm
from datetime import datetime

# Optional wandb import for experiment tracking
try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False
    print("Warning: wandb not available. Install with 'pip install wandb' for experiment tracking.")

class SignLanguageTrainer:
    def __init__(self, model, train_loader, val_loader=None, device='cuda', use_wandb=False):
        """
        Trainer for Stage 1 sign language model
        
        Args:
            model: SignLanguageModel instance
            train_loader: Training data loader
            val_loader: Validation data loader (optional)
            device: Device for training
            use_wandb: Whether to use Weights & Biases for logging
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.use_wandb = use_wandb and WANDB_AVAILABLE
        
        if self.use_wandb and not WANDB_AVAILABLE:
            print("Warning: wandb requested but not available. Logging disabled.")
            self.use_wandb = False
        
        # Optimizer with different learning rates for different components
        self.optimizer = optim.AdamW([
            {'params': self.model.visual_encoder.parameters(), 'lr': 1e-4},
            {'params': self.model.text_encoder.parameters(), 'lr': 2e-5}
        ], weight_decay=0.01)
        
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=100)
        
        # Training metrics
        self.train_losses = []
        self.val_losses = []
        
    def train_epoch(self, epoch):
        self.model.train()
        total_loss = 0
        num_batches = len(self.train_loader)
        
        progress_bar = tqdm(self.train_loader, desc=f'Epoch {epoch+1}')
        
        for batch_idx, batch in enumerate(progress_bar):
            frames = batch['frames'].to(self.device)
            text_list = batch['gloss_text']
            
            self.optimizer.zero_grad()
            
            # Forward pass
            loss, visual_features, text_features = self.model(frames, text_list)
            
            # Backward pass
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += loss.item()
            
            # Update progress bar
            progress_bar.set_postfix({
                'Loss': f'{loss.item():.4f}',
                'Avg Loss': f'{total_loss/(batch_idx+1):.4f}'
            })
        
        avg_loss = total_loss / num_batches
        self.train_losses.append(avg_loss)
        return avg_loss
    
    def validate(self, epoch):
        if self.val_loader is None:
            return None
            
        self.model.eval()
        total_loss = 0
        num_batches = len(self.val_loader)
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc='Validation'):
                frames = batch['frames'].to(self.device)
                text_list = batch['gloss_text']
                
                loss, _, _ = self.model(frames, text_list)
                total_loss += loss.item()
        
        avg_loss = total_loss / num_batches
        self.val_losses.append(avg_loss)
        return avg_loss
    
    def train(self, num_epochs, save_dir='checkpoints'):
        os.makedirs(save_dir, exist_ok=True)
        best_val_loss = float('inf')
        
        print(f"Starting training for {num_epochs} epochs...")
        
        for epoch in range(num_epochs):
            # Training
            train_loss = self.train_epoch(epoch)
            
            # Validation
            val_loss = self.validate(epoch)
            
            # Scheduler step
            self.scheduler.step()
            
            # Logging
            print(f"Epoch {epoch+1}/{num_epochs}")
            print(f"Train Loss: {train_loss:.4f}")
            if val_loss is not None:
                print(f"Val Loss: {val_loss:.4f}")
            
            # Save best model
            if val_loss is not None and val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save_model(os.path.join(save_dir, 'best_model.pth'))
                print("Saved best model!")
            
            # Save checkpoint every 10 epochs
            if (epoch + 1) % 10 == 0:
                self.save_model(os.path.join(save_dir, f'checkpoint_epoch_{epoch+1}.pth'))
        
        # Save final model
        self.save_model(os.path.join(save_dir, 'final_model.pth'))
        print("Training completed!")
    
    def save_model(self, path):
        """Save model with both encoders for downstream tasks"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'visual_encoder_state_dict': self.model.visual_encoder.state_dict(),
            'text_encoder_state_dict': self.model.text_encoder.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
        }, path)

# inference.py
class SignLanguageInference:
    def __init__(self, model_path, device='cuda'):
        self.device = device
        
        # Load model
        checkpoint = torch.load(model_path, map_location=device)
        
        # Initialize model architecture
        self.model = SignLanguageModel()
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(device)
        self.model.eval()
        
        print(f"Model loaded from {model_path}")
    
    def extract_visual_features(self, frames):
        """Extract visual features from video frames"""
        with torch.no_grad():
            frames = frames.to(self.device)
            visual_features = self.model.visual_encoder(frames)
            return visual_features.cpu().numpy()
    
    def extract_text_features(self, text_list):
        """Extract text features from gloss descriptions"""
        with torch.no_grad():
            text_features = self.model.text_encoder(text_list)
            return text_features.cpu().numpy()
    
    def extract_both_features(self, frames, text_list):
        """Extract both visual and text features"""
        with torch.no_grad():
            frames = frames.to(self.device)
            visual_features, text_features = self.model(frames, text_list, return_features=True)
            return visual_features.cpu().numpy(), text_features.cpu().numpy()

# main.py - Training script
def main():
    # Configuration
    config = {
        'root_train_folder': '/home/pvvkishore/Desktop/TVC_May21/New_Code/train/',
        'annotations_folder': '/home/pvvkishore/Desktop/TVC_May21/New_Code/annotations_folder/',
        'batch_size': 4,
        'num_epochs': 1,
        'feature_dim': 1024,
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'save_dir': 'checkpoints'
    }
    
    print(f"Using device: {config['device']}")
    
    # Create data loader
    print("Loading dataset...")
    train_loader, dataset = get_data_loader(
        root_train_folder=config['root_train_folder'],
        annotations_folder=config['annotations_folder'],
        batch_size=config['batch_size']
    )
    
    print(f"Dataset loaded with {len(dataset)} samples")
    
    # Initialize model
    print("Initializing model...")
    model = SignLanguageModel(feature_dim=config['feature_dim'])
    
    # Initialize trainer
    trainer = SignLanguageTrainer(
        model=model,
        train_loader=train_loader,
        device=config['device']
    )
    
    # Start training
    trainer.train(
        num_epochs=config['num_epochs'],
        save_dir=config['save_dir']
    )
    
    print("Training completed successfully!")

# Example usage for inference
def example_inference():
    # Load trained model
    inference_model = SignLanguageInference('checkpoints/best_model.pth')
    
    # Example: Extract features from new data
    # frames = torch.randn(1, 16, 3, 112, 112)  # Batch of video frames
    # text_list = ["hello world"]  # Corresponding gloss text
    
    # visual_features, text_features = inference_model.extract_both_features(frames, text_list)
    # print(f"Visual features shape: {visual_features.shape}")
    # print(f"Text features shape: {text_features.shape}")

if __name__ == "__main__":
    main()