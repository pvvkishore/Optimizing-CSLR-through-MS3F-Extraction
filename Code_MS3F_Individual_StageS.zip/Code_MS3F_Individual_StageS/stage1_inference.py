# stage1_inference.py - Fixed version
import torch
import numpy as np
import os

class SignLanguageInference:
    def __init__(self, model_path, device='cuda'):
        self.device = device
        self.model_path = model_path
        
        print(f"Loading Stage 1 model from: {model_path}")
        
        # Check if model file exists
        if not os.path.exists(model_path):
            print(f"⚠️  Model file not found: {model_path}")
            print("Creating dummy Stage 1 model for testing...")
            self.model = None
            self.tokenizer = None
            self.is_dummy = True
            return
        
        try:
            # Load Stage 1 model
            if model_path.endswith('.pth'):
                checkpoint = torch.load(model_path, map_location=device)
                
                # Try to import actual model
                try:
                    from stage1_model import SignLanguageModel
                    self.model = SignLanguageModel()
                    self.model.load_state_dict(checkpoint['model_state_dict'])
                    
                    # Try to load tokenizer
                    try:
                        from transformers import BertTokenizer
                        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
                    except ImportError:
                        print("⚠️  BERT tokenizer not available, using dummy tokenizer")
                        self.tokenizer = None
                        
                except ImportError:
                    print("SignLanguageModel not found, creating dummy model...")
                    self.model = None
                    self.tokenizer = None
                    self.is_dummy = True
                    return
            
            if self.model:
                self.model.to(device)
                self.model.eval()
                self.is_dummy = False
                print("✅ Stage 1 model loaded successfully")
            else:
                self.is_dummy = True
                
        except Exception as e:
            print(f"Error loading Stage 1 model: {e}")
            print("Creating dummy Stage 1 model for testing...")
            self.model = None
            self.tokenizer = None
            self.is_dummy = True
    
    def extract_text_features(self, texts):
        """Extract text features from gloss texts"""
        if self.is_dummy or self.model is None:
            # Return dummy text features
            batch_size = len(texts)
            feature_dim = 1024
            
            print(f"🔄 Using dummy text features: ({batch_size}, {feature_dim})")
            dummy_features = np.random.randn(batch_size, feature_dim).astype(np.float32)
            return dummy_features
        
        # Real text feature extraction
        with torch.no_grad():
            try:
                # Use the model's text encoder directly
                text_features = self.model.text_encoder(texts)
                return text_features.cpu().numpy()
            except Exception as e:
                print(f"⚠️  Error in text feature extraction: {e}")
                print("Using fallback text feature extraction...")
                
                # Fallback to simple text features
                text_features = []
                for text in texts:
                    simple_feat = self.simple_text_to_features(text)
                    text_features.append(simple_feat)
                
                return np.vstack(text_features)
    
    def simple_text_to_features(self, text):
        """Simple text to feature conversion for fallback"""
        # Create features based on text characteristics
        words = text.lower().split()
        feature_dim = 1024
        
        # Simple hash-based feature generation
        features = np.zeros(feature_dim)
        for i, word in enumerate(words):
            hash_val = hash(word) % feature_dim
            features[hash_val] += 1.0 / (i + 1)
        
        # Normalize
        features = features / (np.linalg.norm(features) + 1e-8)
        return features.reshape(1, -1)