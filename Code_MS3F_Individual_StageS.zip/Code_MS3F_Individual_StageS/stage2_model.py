# stage2_data_loader.py
import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
import cv2
import numpy as np
from collections import defaultdict

class Stage2Dataset(Dataset):
    def __init__(self, root_train_folder, annotations_folder, transform=None):
        """
        Dataset for Stage 2 - extracts all frames with their indexes
        
        Args:
            root_train_folder: Path to folder containing subfolders with video frames
            annotations_folder: Path to folder containing CSV annotation file
            transform: Optional transform to be applied on frames
        """
        self.root_train_folder = root_train_folder
        self.transform = transform
        
        # Load annotations
        csv_files = [f for f in os.listdir(annotations_folder) if f.endswith('.csv')]
        if not csv_files:
            raise ValueError("No CSV file found in annotations folder")
        
        csv_path = os.path.join(annotations_folder, csv_files[0])
        self.annotations = pd.read_csv(csv_path)
        
        # Skip first row and use first two columns
        self.annotations = self.annotations.iloc[1:, :2]
        self.annotations.columns = ['folder_name', 'gloss_text']
        
        # Build sample data with frame information
        self.samples = []
        for _, row in self.annotations.iterrows():
            folder_path = os.path.join(root_train_folder, str(row['folder_name']))
            if os.path.exists(folder_path):
                frame_files = sorted([f for f in os.listdir(folder_path) 
                                    if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
                
                if len(frame_files) > 0:
                    self.samples.append({
                        'folder_name': str(row['folder_name']),
                        'gloss_text': str(row['gloss_text']),
                        'folder_path': folder_path,
                        'frame_files': frame_files,
                        'num_frames': len(frame_files)
                    })
        
        print(f"Loaded {len(self.samples)} samples for Stage 2")
    
    def __len__(self):
        return len(self.samples)
    
    def load_all_frames(self, folder_path, frame_files):
        """Load all frames from a sample folder"""
        frames = []
        frame_indexes = []
        
        for idx, frame_file in enumerate(frame_files):
            frame_path = os.path.join(folder_path, frame_file)
            frame = cv2.imread(frame_path)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (112, 112))
            frames.append(frame)
            frame_indexes.append(idx)
        
        return np.stack(frames), frame_indexes
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # Load all frames
        frames, frame_indexes = self.load_all_frames(
            sample['folder_path'], 
            sample['frame_files']
        )
        
        # Apply transforms
        if self.transform:
            transformed_frames = []
            for frame in frames:
                frame_pil = Image.fromarray(frame)
                transformed_frame = self.transform(frame_pil)
                transformed_frames.append(transformed_frame)
            frames = torch.stack(transformed_frames)
        else:
            frames = torch.from_numpy(frames).permute(0, 3, 1, 2).float() / 255.0
        
        return {
            'frames': frames,  # (T, 3, 112, 112)
            'frame_indexes': torch.tensor(frame_indexes, dtype=torch.long),
            'gloss_text': sample['gloss_text'],
            'folder_name': sample['folder_name'],
            'num_frames': sample['num_frames']
        }

def stage2_collate_fn(batch):
    """Custom collate function to handle variable length sequences"""
    # Sort by sequence length (descending)
    batch = sorted(batch, key=lambda x: x['num_frames'], reverse=True)
    
    max_frames = batch[0]['num_frames']
    batch_size = len(batch)
    
    # Pad sequences
    padded_frames = torch.zeros(batch_size, max_frames, 3, 112, 112)
    padded_indexes = torch.zeros(batch_size, max_frames, dtype=torch.long)
    lengths = torch.zeros(batch_size, dtype=torch.long)
    
    gloss_texts = []
    folder_names = []
    
    for i, sample in enumerate(batch):
        seq_len = sample['num_frames']
        padded_frames[i, :seq_len] = sample['frames']
        padded_indexes[i, :seq_len] = sample['frame_indexes']
        lengths[i] = seq_len
        gloss_texts.append(sample['gloss_text'])
        folder_names.append(sample['folder_name'])
    
    return {
        'frames': padded_frames,
        'frame_indexes': padded_indexes,
        'lengths': lengths,
        'gloss_texts': gloss_texts,
        'folder_names': folder_names
    }

def get_stage2_data_loader(root_train_folder, annotations_folder, batch_size=8, shuffle=True, num_workers=4):
    """Create data loader for Stage 2"""
    transform = transforms.Compose([
        transforms.Resize((112, 112)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    dataset = Stage2Dataset(
        root_train_folder=root_train_folder,
        annotations_folder=annotations_folder,
        transform=transform
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=stage2_collate_fn
    )
    
    return dataloader, dataset

# holistic_feature_extractor.py
import torch
import torch.nn as nn
from stage1_model import SignLanguageModel  # Import from Stage 1

class HolisticSpatialFeatureExtractor:
    def __init__(self, stage1_model_path, device='cuda'):
        """
        Extract Holistic Spatial Features using trained Stage 1 model
        
        Args:
            stage1_model_path: Path to trained Stage 1 model
            device: Device for computation
        """
        self.device = device
        
        # Load Stage 1 model
        checkpoint = torch.load(stage1_model_path, map_location=device)
        self.stage1_model = SignLanguageModel(feature_dim=1024)
        self.stage1_model.load_state_dict(checkpoint['model_state_dict'])
        self.stage1_model.to(device)
        self.stage1_model.eval()
        
        # Extract only visual encoder
        self.visual_encoder = self.stage1_model.visual_encoder
        
        print(f"Holistic Spatial Feature Extractor loaded from {stage1_model_path}")
    
    def extract_holistic_features(self, frames):
        """
        Extract holistic spatial features from frames
        
        Args:
            frames: Tensor of shape (batch_size, num_frames, 3, 112, 112)
            
        Returns:
            features: Tensor of shape (batch_size, num_frames, 1024)
        """
        with torch.no_grad():
            batch_size, num_frames = frames.shape[:2]
            
            # Reshape to process all frames
            frames_flat = frames.view(-1, 3, 112, 112)
            
            # Extract features using ResNet backbone only (before temporal aggregation)
            features = self.visual_encoder.resnet(frames_flat)  # (B*T, 2048, 1, 1)
            features = features.view(batch_size * num_frames, -1)  # (B*T, 2048)
            
            # Apply projection
            features = self.visual_encoder.projection(features)  # (B*T, 1024)
            
            # Reshape back to sequence format
            features = features.view(batch_size, num_frames, -1)  # (B, T, 1024)
            
            return features

# motion_feature_extractor.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class MotionFeatureExtractor(nn.Module):
    def __init__(self, feature_dim=1024):
        """
        Extract motion features using frame differencing
        
        Args:
            feature_dim: Dimension of holistic spatial features
        """
        super(MotionFeatureExtractor, self).__init__()
        self.feature_dim = feature_dim
        
        # Motion feature processing layers
        self.motion_processor = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(feature_dim, feature_dim),
            nn.LayerNorm(feature_dim)
        )
    
    def forward(self, holistic_features, frame_indexes, lengths):
        """
        Extract motion features using frame differencing
        
        Args:
            holistic_features: (batch_size, max_frames, feature_dim)
            frame_indexes: (batch_size, max_frames) 
            lengths: (batch_size,) actual sequence lengths
            
        Returns:
            motion_features: (batch_size, max_frames-1, feature_dim)
            motion_indexes: (batch_size, max_frames-1, 2) - pairs of frame indexes
        """
        batch_size, max_frames, feature_dim = holistic_features.shape
        device = holistic_features.device
        
        # Initialize motion features and indexes
        motion_features = []
        motion_indexes = []
        
        for b in range(batch_size):
            seq_len = lengths[b].item()
            
            if seq_len > 1:
                # Get features for this sequence
                seq_features = holistic_features[b, :seq_len]  # (seq_len, feature_dim)
                seq_indexes = frame_indexes[b, :seq_len]  # (seq_len,)
                
                # Compute frame differences
                frame_diffs = seq_features[1:] - seq_features[:-1]  # (seq_len-1, feature_dim)
                
                # Process motion features
                processed_motion = self.motion_processor(frame_diffs)  # (seq_len-1, feature_dim)
                
                # Create index pairs (consecutive frames)
                index_pairs = torch.stack([seq_indexes[:-1], seq_indexes[1:]], dim=1)  # (seq_len-1, 2)
                
                motion_features.append(processed_motion)
                motion_indexes.append(index_pairs)
            else:
                # Handle single frame case
                dummy_motion = torch.zeros(1, feature_dim, device=device)
                dummy_indexes = torch.zeros(1, 2, dtype=torch.long, device=device)
                motion_features.append(dummy_motion)
                motion_indexes.append(dummy_indexes)
        
        # Pad motion features and indexes
        max_motion_len = max(mf.shape[0] for mf in motion_features)
        
        padded_motion_features = torch.zeros(batch_size, max_motion_len, feature_dim, device=device)
        padded_motion_indexes = torch.zeros(batch_size, max_motion_len, 2, dtype=torch.long, device=device)
        
        for b, (mf, mi) in enumerate(zip(motion_features, motion_indexes)):
            seq_len = mf.shape[0]
            padded_motion_features[b, :seq_len] = mf
            padded_motion_indexes[b, :seq_len] = mi
        
        return padded_motion_features, padded_motion_indexes

# gru_motion_selector.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class GRUMotionSelector(nn.Module):
    def __init__(self, feature_dim=1024, hidden_dim=512, num_layers=2, top_k=8):
        """
        GRU-based motion feature selector
        
        Args:
            feature_dim: Dimension of motion features
            hidden_dim: Hidden dimension of GRU
            num_layers: Number of GRU layers
            top_k: Number of top motion features to select
        """
        super(GRUMotionSelector, self).__init__()
        self.feature_dim = feature_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.top_k = top_k
        
        # GRU for processing motion features
        self.gru = nn.GRU(
            input_size=feature_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.1 if num_layers > 1 else 0,
            bidirectional=True
        )
        
        # Attention mechanism for motion importance scoring
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),  # *2 for bidirectional
            nn.Tanh(),
            nn.Linear(hidden_dim, 1)
        )
        
        # Motion importance predictor
        self.importance_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
    
    def forward(self, motion_features, motion_indexes, motion_lengths):
        """
        Select top-K motion features using GRU
        
        Args:
            motion_features: (batch_size, max_motion_len, feature_dim)
            motion_indexes: (batch_size, max_motion_len, 2)
            motion_lengths: (batch_size,) actual motion sequence lengths
            
        Returns:
            selected_indexes: (batch_size, top_k, 2) - selected frame index pairs
            importance_scores: (batch_size, max_motion_len) - importance scores
        """
        batch_size, max_motion_len, feature_dim = motion_features.shape
        device = motion_features.device
        
        # Pack padded sequences for GRU
        packed_motion = nn.utils.rnn.pack_padded_sequence(
            motion_features, 
            motion_lengths.cpu(), 
            batch_first=True, 
            enforce_sorted=False
        )
        
        # Process with GRU
        packed_output, hidden = self.gru(packed_motion)
        
        # Unpack sequences
        gru_output, _ = nn.utils.rnn.pad_packed_sequence(
            packed_output, 
            batch_first=True
        )  # (batch_size, max_motion_len, hidden_dim*2)
        
        # Compute importance scores
        importance_scores = self.importance_head(gru_output).squeeze(-1)  # (batch_size, max_motion_len)
        
        # Mask padded positions
        mask = torch.arange(max_motion_len, device=device).unsqueeze(0) < motion_lengths.unsqueeze(1)
        importance_scores = importance_scores.masked_fill(~mask, -float('inf'))
        
        # Select top-K motion features
        selected_indexes_list = []
        
        for b in range(batch_size):
            seq_len = motion_lengths[b].item()
            if seq_len > 0:
                # Get valid importance scores
                valid_scores = importance_scores[b, :seq_len]
                valid_indexes = motion_indexes[b, :seq_len]
                
                # Select top-K
                k = min(self.top_k, seq_len)
                _, top_indices = torch.topk(valid_scores, k)
                
                # Get selected frame index pairs
                selected = valid_indexes[top_indices]  # (k, 2)
                
                # Pad if necessary
                if k < self.top_k:
                    padding = torch.zeros(self.top_k - k, 2, dtype=torch.long, device=device)
                    selected = torch.cat([selected, padding], dim=0)
                
                selected_indexes_list.append(selected)
            else:
                # Handle empty sequence
                selected_indexes_list.append(torch.zeros(self.top_k, 2, dtype=torch.long, device=device))
        
        selected_indexes = torch.stack(selected_indexes_list, dim=0)  # (batch_size, top_k, 2)
        
        return selected_indexes, importance_scores

# ms3f_model.py
import torch
import torch.nn as nn

class MS3FExtractor(nn.Module):
    def __init__(self, stage1_model_path, feature_dim=1024, hidden_dim=512, num_layers=2, top_k=8, device='cuda'):
        """
        Complete MS3F (Motion Selected Sparse Spatial Features) Extractor
        
        Args:
            stage1_model_path: Path to trained Stage 1 model
            feature_dim: Feature dimension (1024)
            hidden_dim: GRU hidden dimension
            num_layers: Number of GRU layers
            top_k: Number of top motion features to select
            device: Device for computation
        """
        super(MS3FExtractor, self).__init__()
        self.top_k = top_k
        self.feature_dim = feature_dim
        self.device = device
        
        # Initialize components
        self.holistic_extractor = HolisticSpatialFeatureExtractor(stage1_model_path, device)
        self.motion_extractor = MotionFeatureExtractor(feature_dim)
        self.gru_selector = GRUMotionSelector(feature_dim, hidden_dim, num_layers, top_k)
        
    def forward(self, frames, frame_indexes, lengths):
        """
        Extract MS3F features
        
        Args:
            frames: (batch_size, max_frames, 3, 112, 112)
            frame_indexes: (batch_size, max_frames)
            lengths: (batch_size,) actual sequence lengths
            
        Returns:
            ms3f_features: (batch_size, top_k, feature_dim) - Motion Selected Sparse Spatial Features
            selected_frame_indexes: (batch_size, top_k, 2) - Selected frame index pairs
            importance_scores: (batch_size, max_motion_len) - Motion importance scores
        """
        # Step 1: Extract Holistic Spatial Features
        holistic_features = self.holistic_extractor.extract_holistic_features(frames)
        
        # Step 2: Extract Motion Features using frame differencing
        motion_features, motion_indexes = self.motion_extractor(
            holistic_features, frame_indexes, lengths
        )
        
        # Compute motion sequence lengths (one less than frame lengths)
        motion_lengths = torch.clamp(lengths - 1, min=0)
        
        # Step 3: Select top-K motion features using GRU
        selected_indexes, importance_scores = self.gru_selector(
            motion_features, motion_indexes, motion_lengths
        )
        
        # Step 4: Create MS3F by selecting corresponding holistic features
        batch_size = frames.shape[0]
        ms3f_features = torch.zeros(batch_size, self.top_k, self.feature_dim, device=self.device)
        
        for b in range(batch_size):
            for k in range(self.top_k):
                frame_idx_pair = selected_indexes[b, k]  # (2,)
                frame1_idx, frame2_idx = frame_idx_pair[0].item(), frame_idx_pair[1].item()
                
                # Use the average of the two frames' holistic features
                if frame1_idx < lengths[b] and frame2_idx < lengths[b]:
                    feat1 = holistic_features[b, frame1_idx]
                    feat2 = holistic_features[b, frame2_idx]
                    ms3f_features[b, k] = (feat1 + feat2) / 2
        
        return ms3f_features, selected_indexes, importance_scores

# stage2_training.py
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
import os
from tqdm import tqdm

class MS3FTrainer:
    def __init__(self, model, train_loader, val_loader=None, device='cuda'):
        """
        Trainer for MS3F Extractor
        
        Args:
            model: MS3FExtractor model
            train_loader: Training data loader
            val_loader: Validation data loader (optional)
            device: Device for training
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Only train the motion extractor and GRU selector
        # Freeze holistic feature extractor (Stage 1 model)
        for param in self.model.holistic_extractor.visual_encoder.parameters():
            param.requires_grad = False
        
        # Optimizer for trainable parameters only
        trainable_params = [
            {'params': self.model.motion_extractor.parameters(), 'lr': 1e-4},
            {'params': self.model.gru_selector.parameters(), 'lr': 1e-4}
        ]
        
        self.optimizer = optim.AdamW(trainable_params, weight_decay=0.01)
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=50)
        
        # Loss function: Motion diversity and importance loss
        self.criterion = self.create_motion_loss()
        
        # Training metrics
        self.train_losses = []
        self.val_losses = []
    
    def create_motion_loss(self):
        """Create motion-based loss function"""
        def motion_loss(ms3f_features, importance_scores, motion_lengths):
            batch_size = ms3f_features.shape[0]
            total_loss = 0
            
            for b in range(batch_size):
                if motion_lengths[b] > 0:
                    # Diversity loss: encourage diverse selected features
                    features = ms3f_features[b]  # (top_k, feature_dim)
                    similarity_matrix = torch.mm(features, features.t())
                    diversity_loss = torch.mean(torch.triu(similarity_matrix, diagonal=1))
                    
                    # Importance loss: encourage high importance scores for selected features
                    scores = importance_scores[b, :motion_lengths[b]]
                    importance_loss = -torch.mean(scores)
                    
                    total_loss += diversity_loss + 0.1 * importance_loss
            
            return total_loss / batch_size
        
        return motion_loss
    
    def train_epoch(self, epoch):
        """Train one epoch"""
        self.model.train()
        total_loss = 0
        num_batches = len(self.train_loader)
        
        progress_bar = tqdm(self.train_loader, desc=f'Epoch {epoch+1}')
        
        for batch_idx, batch in enumerate(progress_bar):
            frames = batch['frames'].to(self.device)
            frame_indexes = batch['frame_indexes'].to(self.device)
            lengths = batch['lengths'].to(self.device)
            
            self.optimizer.zero_grad()
            
            # Forward pass
            ms3f_features, selected_indexes, importance_scores = self.model(
                frames, frame_indexes, lengths
            )
            
            # Compute motion lengths for loss
            motion_lengths = torch.clamp(lengths - 1, min=0)
            
            # Compute loss
            loss = self.criterion(ms3f_features, importance_scores, motion_lengths)
            
            # Backward pass
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += loss.item()
            
            # Update progress bar
            progress_bar.set_postfix({
                'Loss': f'{loss.item():.4f}',
                'Avg Loss': f'{total_loss/(batch_idx+1):.4f}'
            })
        
        avg_loss = total_loss / num_batches
        self.train_losses.append(avg_loss)
        return avg_loss
    
    def validate(self, epoch):
        """Validate model"""
        if self.val_loader is None:
            return None
            
        self.model.eval()
        total_loss = 0
        num_batches = len(self.val_loader)
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc='Validation'):
                frames = batch['frames'].to(self.device)
                frame_indexes = batch['frame_indexes'].to(self.device)
                lengths = batch['lengths'].to(self.device)
                
                ms3f_features, selected_indexes, importance_scores = self.model(
                    frames, frame_indexes, lengths
                )
                
                motion_lengths = torch.clamp(lengths - 1, min=0)
                loss = self.criterion(ms3f_features, importance_scores, motion_lengths)
                total_loss += loss.item()
        
        avg_loss = total_loss / num_batches
        self.val_losses.append(avg_loss)
        return avg_loss
    
    def train(self, num_epochs, save_dir='stage2_checkpoints'):
        """Train the MS3F extractor"""
        os.makedirs(save_dir, exist_ok=True)
        best_val_loss = float('inf')
        
        print(f"Starting Stage 2 training for {num_epochs} epochs...")
        
        for epoch in range(num_epochs):
            # Training
            train_loss = self.train_epoch(epoch)
            
            # Validation
            val_loss = self.validate(epoch)
            
            # Scheduler step
            self.scheduler.step()
            
            # Logging
            print(f"Epoch {epoch+1}/{num_epochs}")
            print(f"Train Loss: {train_loss:.4f}")
            if val_loss is not None:
                print(f"Val Loss: {val_loss:.4f}")
            
            # Save best model
            if val_loss is not None and val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save_model(os.path.join(save_dir, 'best_ms3f_extractor.pth'))
                print("Saved best MS3F extractor!")
            
            # Save checkpoint every 10 epochs
            if (epoch + 1) % 10 == 0:
                self.save_model(os.path.join(save_dir, f'ms3f_checkpoint_epoch_{epoch+1}.pth'))
        
        # Save final model
        self.save_model(os.path.join(save_dir, 'final_ms3f_extractor.pth'))
        print("Stage 2 training completed!")
    
    def save_model(self, path):
        """Save MS3F extractor model"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'motion_extractor_state_dict': self.model.motion_extractor.state_dict(),
            'gru_selector_state_dict': self.model.gru_selector.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
            'top_k': self.model.top_k,
            'feature_dim': self.model.feature_dim
        }, path)

# stage2_inference.py
class MS3FInference:
    def __init__(self, ms3f_model_path, device='cuda'):
        """
        Inference class for MS3F extractor
        
        Args:
            ms3f_model_path: Path to trained MS3F model
            device: Device for computation
        """
        self.device = device
        
        # Load model
        checkpoint = torch.load(ms3f_model_path, map_location=device)
        
        # Note: You'll need to provide the stage1_model_path when loading
        # This should be saved in the checkpoint or provided separately
        self.model = MS3FExtractor(
            #stage1_model_path='/home/pvvkishore/Desktop/TVC_May21/stage1_checkpoints/best_model.pth',
            stage1_model_path='/home/pvvkishore/Desktop/TVC_May21/checkpoints/final_model.pth',# Update this path
            top_k=checkpoint.get('top_k', 8),
            feature_dim=checkpoint.get('feature_dim', 1024),
            device=device
        )
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(device)
        self.model.eval()
        
        print(f"MS3F Extractor loaded from {ms3f_model_path}")
    
    def extract_ms3f_features(self, frames, frame_indexes, lengths):
        """
        Extract MS3F features for downstream classification tasks
        
        Args:
            frames: (batch_size, max_frames, 3, 112, 112)
            frame_indexes: (batch_size, max_frames)
            lengths: (batch_size,)
            
        Returns:
            ms3f_features: (batch_size, top_k, 1024) - Motion Selected Sparse Spatial Features
        """
        with torch.no_grad():
            frames = frames.to(self.device)
            frame_indexes = frame_indexes.to(self.device)
            lengths = lengths.to(self.device)
            
            ms3f_features, selected_indexes, importance_scores = self.model(
                frames, frame_indexes, lengths
            )
            
            return ms3f_features.cpu().numpy()

# stage2_main.py
def main_stage2():
    """Main training script for Stage 2"""
    # Configuration
    config = {
        'root_train_folder': '/home/pvvkishore/Desktop/TVC_May21/train/',
        'annotations_folder': 'annotations_folder',
        'stage1_model_path': 'checkpoints/final_model.pth',  # From Stage 1
        'batch_size': 1,  # Smaller batch size due to variable length sequences
        'num_epochs': 3,
        'top_k': 8,  # Number of top motion features to select
        'feature_dim': 1024,
        'hidden_dim': 512,
        'num_layers': 2,
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'save_dir': 'stage2_checkpoints'
    }
    
    print(f"Using device: {config['device']}")
    
    # Create Stage 2 data loader
    print("Loading Stage 2 dataset...")
    train_loader, dataset = get_stage2_data_loader(
        root_train_folder=config['root_train_folder'],
        annotations_folder=config['annotations_folder'],
        batch_size=config['batch_size']
    )
    
    print(f"Stage 2 dataset loaded with {len(dataset)} samples")
    
    # Initialize MS3F extractor
    print("Initializing MS3F Extractor...")
    ms3f_model = MS3FExtractor(
        stage1_model_path=config['stage1_model_path'],
        feature_dim=config['feature_dim'],
        hidden_dim=config['hidden_dim'],
        num_layers=config['num_layers'],
        top_k=config['top_k'],
        device=config['device']
    )
    
    # Initialize trainer
    trainer = MS3FTrainer(
        model=ms3f_model,
        train_loader=train_loader,
        device=config['device']
    )
    
    # Start training
    trainer.train(
        num_epochs=config['num_epochs'],
        save_dir=config['save_dir']
    )
    
    print("Stage 2 training completed successfully!")

# Example usage for downstream classification
def example_downstream_usage():
    """Example of using MS3F features for downstream classification tasks"""
    
    # Load trained MS3F extractor
    ms3f_extractor = MS3FInference('stage2_checkpoints/best_ms3f_extractor.pth')
    
    # Example: Extract MS3F features from new data
    # frames = torch.randn(1, 20, 3, 112, 112)  # Variable length video
    # frame_indexes = torch.arange(20).unsqueeze(0)  # Frame indexes
    # lengths = torch.tensor([20])  # Actual sequence length
    
    # ms3f_features = ms3f_extractor.extract_ms3f_features(frames, frame_indexes, lengths)
    # print(f"MS3F features shape: {ms3f_features.shape}")  # (1, 8, 1024)
    
    # These features can now be used for:
    # 1. Sign language classification
    # 2. Action recognition
    # 3. Temporal sequence modeling
    # 4. Any downstream task requiring motion-aware spatial features

# requirements_stage2.txt content
requirements_stage2 = """
torch>=1.9.0
torchvision>=0.10.0
transformers>=4.20.0
opencv-python>=4.5.0
pandas>=1.3.0
numpy>=1.21.0
Pillow>=8.3.0
tqdm>=4.62.0
scikit-learn>=1.0.0
"""

# Utility functions for Stage 2
class MS3FVisualizer:
    """Utility class for visualizing MS3F selection results"""
    
    def __init__(self, ms3f_model):
        self.model = ms3f_model
        
    def visualize_motion_selection(self, frames, frame_indexes, lengths, save_path=None):
        """
        Visualize which frames were selected by the motion selector
        
        Args:
            frames: Input video frames
            frame_indexes: Frame indexes
            lengths: Sequence lengths
            save_path: Optional path to save visualization
        """
        import matplotlib.pyplot as plt
        
        with torch.no_grad():
            ms3f_features, selected_indexes, importance_scores = self.model(
                frames, frame_indexes, lengths
            )
        
        batch_size = frames.shape[0]
        
        for b in range(min(batch_size, 4)):  # Show first 4 samples
            seq_len = lengths[b].item()
            
            # Plot importance scores
            plt.figure(figsize=(12, 4))
            
            plt.subplot(1, 2, 1)
            scores = importance_scores[b, :seq_len-1].cpu().numpy()
            plt.plot(scores, 'b-', linewidth=2)
            plt.title(f'Motion Importance Scores (Sample {b+1})')
            plt.xlabel('Motion Index')
            plt.ylabel('Importance Score')
            plt.grid(True)
            
            # Highlight selected motions
            selected = selected_indexes[b].cpu().numpy()
            for k in range(self.model.top_k):
                if selected[k, 0] < seq_len and selected[k, 1] < seq_len:
                    motion_idx = selected[k, 0]  # Use first frame of pair as motion index
                    if motion_idx < len(scores):
                        plt.scatter(motion_idx, scores[motion_idx], 
                                  color='red', s=100, zorder=5)
            
            # Show selected frame pairs
            plt.subplot(1, 2, 2)
            selected_pairs = []
            for k in range(self.model.top_k):
                if selected[k, 0] < seq_len and selected[k, 1] < seq_len:
                    selected_pairs.append((selected[k, 0], selected[k, 1]))
            
            if selected_pairs:
                pairs_array = np.array(selected_pairs)
                plt.scatter(pairs_array[:, 0], pairs_array[:, 1], 
                          c=range(len(pairs_array)), cmap='viridis', s=100)
                plt.plot([0, seq_len], [0, seq_len], 'k--', alpha=0.3)
                plt.title(f'Selected Frame Pairs (Sample {b+1})')
                plt.xlabel('Frame 1 Index')
                plt.ylabel('Frame 2 Index')
                plt.grid(True)
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(f"{save_path}_sample_{b+1}.png", dpi=300, bbox_inches='tight')
            else:
                plt.show()
            
            plt.close()

# Advanced MS3F configuration and utilities
class MS3FConfig:
    """Configuration class for MS3F extractor with advanced options"""
    
    def __init__(self):
        # Model architecture
        self.feature_dim = 1024
        self.hidden_dim = 512
        self.num_layers = 2
        self.top_k = 8
        
        # Training parameters
        self.batch_size = 8
        self.num_epochs = 50
        self.learning_rate = 1e-4
        self.weight_decay = 0.01
        
        # Motion selection parameters
        self.motion_threshold = 0.1  # Minimum motion magnitude
        self.diversity_weight = 1.0  # Weight for diversity loss
        self.importance_weight = 0.1  # Weight for importance loss
        
        # Data parameters
        self.max_frames = 64  # Maximum frames per video
        self.frame_stride = 1  # Frame sampling stride
        
        # Paths
        self.stage1_model_path = '/home/pvvkishore/Desktop/TVC_May21/checkpoints/best_model.pth'
        self.save_dir = 'stage2_checkpoints'
        
    def to_dict(self):
        """Convert config to dictionary"""
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}
    
    @classmethod
    def from_dict(cls, config_dict):
        """Create config from dictionary"""
        config = cls()
        for key, value in config_dict.items():
            if hasattr(config, key):
                setattr(config, key, value)
        return config

# Performance evaluation utilities
class MS3FEvaluator:
    """Utility class for evaluating MS3F extractor performance"""
    
    def __init__(self, ms3f_model):
        self.model = ms3f_model
        
    def evaluate_motion_diversity(self, data_loader):
        """
        Evaluate the diversity of selected motion features
        
        Args:
            data_loader: DataLoader for evaluation
            
        Returns:
            average_diversity: Average diversity score across all samples
        """
        self.model.eval()
        diversity_scores = []
        
        with torch.no_grad():
            for batch in tqdm(data_loader, desc='Evaluating motion diversity'):
                frames = batch['frames'].to(self.model.device)
                frame_indexes = batch['frame_indexes'].to(self.model.device)
                lengths = batch['lengths'].to(self.model.device)
                
                ms3f_features, _, _ = self.model(frames, frame_indexes, lengths)
                
                # Compute diversity for each sample in batch
                for b in range(ms3f_features.shape[0]):
                    features = ms3f_features[b]  # (top_k, feature_dim)
                    
                    # Compute pairwise cosine similarities
                    features_norm = F.normalize(features, dim=1)
                    similarity_matrix = torch.mm(features_norm, features_norm.t())
                    
                    # Extract upper triangular part (excluding diagonal)
                    upper_tri = torch.triu(similarity_matrix, diagonal=1)
                    similarities = upper_tri[upper_tri != 0]
                    
                    # Diversity is 1 - average similarity
                    diversity = 1 - torch.mean(similarities).item()
                    diversity_scores.append(diversity)
        
        return np.mean(diversity_scores)
    
    def evaluate_motion_importance_distribution(self, data_loader):
        """
        Evaluate the distribution of motion importance scores
        
        Args:
            data_loader: DataLoader for evaluation
            
        Returns:
            importance_stats: Dictionary with statistics about importance scores
        """
        self.model.eval()
        all_importance_scores = []
        
        with torch.no_grad():
            for batch in tqdm(data_loader, desc='Evaluating importance distribution'):
                frames = batch['frames'].to(self.model.device)
                frame_indexes = batch['frame_indexes'].to(self.model.device)
                lengths = batch['lengths'].to(self.model.device)
                
                _, _, importance_scores = self.model(frames, frame_indexes, lengths)
                
                # Collect valid importance scores
                for b in range(importance_scores.shape[0]):
                    motion_length = max(0, lengths[b].item() - 1)
                    if motion_length > 0:
                        valid_scores = importance_scores[b, :motion_length]
                        all_importance_scores.extend(valid_scores.cpu().numpy())
        
        all_scores = np.array(all_importance_scores)
        
        return {
            'mean': np.mean(all_scores),
            'std': np.std(all_scores),
            'min': np.min(all_scores),
            'max': np.max(all_scores),
            'median': np.median(all_scores),
            'q25': np.percentile(all_scores, 25),
            'q75': np.percentile(all_scores, 75)
        }

if __name__ == "__main__":
    # Run Stage 2 training
    main_stage2()
    
    # Example downstream usage
    print("\n" + "="*50)
    print("Stage 2 Training Completed!")
    print("="*50)
    print("The trained MS3F extractor can now be used for:")
    print("1. Sign language classification")
    print("2. Action recognition")
    print("3. Temporal sequence modeling")
    print("4. Motion-aware feature extraction")
    print("="*50)