# stage5_model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from stage1_model import SignLanguageModel as Stage1Model
from stage2_model import MS3FExtractor
from stage3_model import Stage3Model
from stage4_model import Stage4CTCModel
import numpy as np

class Stage5EndToEndModel(nn.Module):
    def __init__(self, stage1_path, stage2_path, stage3_path, stage4_path, 
                 vocab_path, label_encoder_path, device='cuda'):
        """
        Complete end-to-end model combining all 4 stages for fine-tuning
        
        Args:
            stage1_path: Path to trained Stage 1 model
            stage2_path: Path to trained Stage 2 model  
            stage3_path: Path to trained Stage 3 model
            stage4_path: Path to trained Stage 4 model
            vocab_path: Path to CTC vocabulary
            label_encoder_path: Path to Stage 3 label encoder
            device: Device for computation
        """
        super(Stage5EndToEndModel, self).__init__()
        self.device = device
        
        # Load all trained models
        self.load_pretrained_models(stage1_path, stage2_path, stage3_path, 
                                   stage4_path, vocab_path, label_encoder_path)
        
        # Configure which layers to unfreeze for fine-tuning
        self.configure_unfreezing()
        
        print("Stage 5 End-to-End Model initialized with all 4 stages")
        
    def load_pretrained_models(self, stage1_path, stage2_path, stage3_path, 
                              stage4_path, vocab_path, label_encoder_path):
        """Load all pretrained models"""
        
        # Load Stage 1 model
        stage1_checkpoint = torch.load(stage1_path, map_location=self.device)
        self.stage1_model = Stage1Model(feature_dim=1024)
        self.stage1_model.load_state_dict(stage1_checkpoint['model_state_dict'])
        
        # Load Stage 2 model  
        stage2_checkpoint = torch.load(stage2_path, map_location=self.device)
        self.stage2_model = MS3FExtractor(
            stage1_model_path=stage1_path,
            feature_dim=1024,
            top_k=8,
            device=self.device
        )
        self.stage2_model.load_state_dict(stage2_checkpoint['model_state_dict'])
        
        # Load Stage 3 model
        stage3_checkpoint = torch.load(stage3_path, map_location=self.device)
        self.stage3_model = Stage3Model(
            stage1_model_path=stage1_path,
            stage2_model_path=stage2_path,
            num_classes=stage3_checkpoint['num_classes'],
            device=self.device
        )
        self.stage3_model.load_state_dict(stage3_checkpoint['model_state_dict'])
        
        # Load Stage 4 model
        stage4_checkpoint = torch.load(stage4_path, map_location=self.device)
        with open(vocab_path, 'rb') as f:
            import pickle
            vocab_info = pickle.load(f)
        
        self.stage4_model = Stage4CTCModel(
            stage3_model_path=stage3_path,
            label_encoder_path=label_encoder_path,
            vocab_size=vocab_info['vocab_size'],
            device=self.device
        )
        self.stage4_model.load_state_dict(stage4_checkpoint['model_state_dict'])
        
        # Store vocab info for CTC
        self.vocab_info = vocab_info
        
    def configure_unfreezing(self):
        """Configure which layers to unfreeze for end-to-end fine-tuning"""
        
        # Stage 1: Unfreeze last 2 layers of visual encoder and text encoder
        # Keep most layers frozen to preserve learned representations
        for param in self.stage1_model.parameters():
            param.requires_grad = False
        
        # Unfreeze last layers of visual encoder
        for param in self.stage1_model.visual_encoder.projection[-2:].parameters():
            param.requires_grad = True
            
        # Unfreeze last layers of text encoder  
        for param in self.stage1_model.text_encoder.projection[-2:].parameters():
            param.requires_grad = True
        
        print("Stage 1: Unfroze projection layers")
        
        # Stage 2: Unfreeze motion extractor and GRU selector (keep holistic extractor frozen)
        for param in self.stage2_model.holistic_extractor.parameters():
            param.requires_grad = False
            
        for param in self.stage2_model.motion_extractor.parameters():
            param.requires_grad = True
            
        for param in self.stage2_model.gru_selector.parameters():
            param.requires_grad = True
            
        print("Stage 2: Unfroze motion extractor and GRU selector")
        
        # Stage 3: Unfreeze classifier (keep feature extractors frozen)
        for param in self.stage3_model.feature_extractor.parameters():
            param.requires_grad = False
            
        for param in self.stage3_model.classifier.parameters():
            param.requires_grad = True
            
        print("Stage 3: Unfroze classifier")
        
        # Stage 4: Unfreeze CTC module (keep Stage 3 features frozen)
        for param in self.stage4_model.stage3_model.parameters():
            param.requires_grad = False
            
        for param in self.stage4_model.ctc_module.parameters():
            param.requires_grad = True
            
        print("Stage 4: Unfroze CTC module")
        
    def forward(self, frames, frame_indexes, lengths, gloss_texts, 
                gloss_labels, ctc_targets, ctc_target_lengths):
        """
        Complete forward pass through all stages
        
        Args:
            frames: Video frames (batch_size, max_frames, 3, 112, 112)
            frame_indexes: Frame indexes (batch_size, max_frames)
            lengths: Sequence lengths (batch_size,)
            gloss_texts: List of gloss text descriptions
            gloss_labels: Classification labels (batch_size,)
            ctc_targets: CTC target sequences (concatenated)
            ctc_target_lengths: CTC target lengths (batch_size,)
            
        Returns:
            Dictionary with outputs and intermediate features from all stages
        """
        batch_size = frames.shape[0]
        
        # Stage 1: Multi-modal alignment
        stage1_loss, visual_features, text_features = self.stage1_model(
            frames.view(batch_size, -1, 3, 112, 112),  # Flatten temporal dimension temporarily
            gloss_texts
        )
        
        # Stage 2: MS3F extraction
        ms3f_features, selected_indexes, importance_scores = self.stage2_model(
            frames, frame_indexes, lengths
        )
        
        # Compute motion lengths for Stage 2 loss
        motion_lengths = torch.clamp(lengths - 1, min=0)
        
        # Stage 3: Classification
        classification_logits, attention_weights = self.stage3_model.classifier(
            ms3f_features, text_features
        )
        
        # Stage 4: CTC alignment
        ctc_log_probs, ctc_output_lengths = self.stage4_model.ctc_module(
            ms3f_features, lengths  # Use MS3F features directly for CTC
        )
        
        return {
            # Stage 1 outputs
            'stage1_loss': stage1_loss,
            'visual_features': visual_features,
            'text_features': text_features,
            
            # Stage 2 outputs
            'ms3f_features': ms3f_features,
            'selected_indexes': selected_indexes,
            'importance_scores': importance_scores,
            'motion_lengths': motion_lengths,
            
            # Stage 3 outputs
            'classification_logits': classification_logits,
            'attention_weights': attention_weights,  # For visualization
            'gloss_labels': gloss_labels,
            
            # Stage 4 outputs
            'ctc_log_probs': ctc_log_probs,
            'ctc_output_lengths': ctc_output_lengths,
            'ctc_targets': ctc_targets,
            'ctc_target_lengths': ctc_target_lengths
        }

class Stage5CollectiveLoss(nn.Module):
    def __init__(self, loss_fractions=None, regularization_fraction=0.01):
        """
        Collective loss function combining all stage losses
        
        Args:
            loss_fractions: Dictionary with loss fractions for each stage
            regularization_fraction: Fraction for regularization loss
        """
        super(Stage5CollectiveLoss, self).__init__()
        
        if loss_fractions is None:
            self.loss_fractions = {
                'stage1': 0.14,  # Contrastive alignment loss
                'stage2': 0.25,  # Motion diversity loss  
                'stage3': 0.20,  # Classification loss
                'stage4': 0.40,  # CTC loss
                'regularization': 0.01  # L2 regularization
            }
        else:
            self.loss_fractions = loss_fractions
            self.loss_fractions['regularization'] = regularization_fraction
        
        # Individual loss functions
        self.classification_loss = nn.CrossEntropyLoss()
        self.ctc_loss = nn.CTCLoss(blank=0, reduction='mean', zero_infinity=True)
        
        print(f"Collective loss fractions: {self.loss_fractions}")
    
    def compute_stage2_loss(self, ms3f_features, importance_scores, motion_lengths):
        """Compute Stage 2 motion diversity and importance loss"""
        batch_size = ms3f_features.shape[0]
        total_loss = 0
        valid_samples = 0
        
        for b in range(batch_size):
            if motion_lengths[b] > 0:
                # Diversity loss: encourage diverse selected features
                features = ms3f_features[b]  # (top_k, feature_dim)
                features_norm = F.normalize(features, dim=1)
                similarity_matrix = torch.mm(features_norm, features_norm.t())
                diversity_loss = torch.mean(torch.triu(similarity_matrix, diagonal=1))
                
                # Importance loss: encourage high importance scores for selected features
                seq_len = motion_lengths[b].item()
                if seq_len > 0:
                    scores = importance_scores[b, :seq_len]
                    importance_loss = -torch.mean(scores)
                else:
                    importance_loss = 0
                
                total_loss += diversity_loss + 0.1 * importance_loss
                valid_samples += 1
        
        return total_loss / max(valid_samples, 1)
    
    def compute_regularization_loss(self, model):
        """Compute L2 regularization loss for unfrozen parameters"""
        reg_loss = 0
        param_count = 0
        
        for param in model.parameters():
            if param.requires_grad:
                reg_loss += torch.sum(param ** 2)
                param_count += param.numel()
        
        return reg_loss / max(param_count, 1)
    
    def forward(self, model_outputs, model):
        """
        Compute collective loss from all stages
        
        Args:
            model_outputs: Dictionary with outputs from all stages
            model: The complete Stage 5 model for regularization
            
        Returns:
            collective_loss: Weighted sum of all losses
            loss_breakdown: Individual loss values for monitoring
        """
        losses = {}
        
        # Stage 1 loss (already computed in forward pass)
        losses['stage1'] = model_outputs['stage1_loss']
        
        # Stage 2 loss (motion diversity and importance)
        losses['stage2'] = self.compute_stage2_loss(
            model_outputs['ms3f_features'],
            model_outputs['importance_scores'],
            model_outputs['motion_lengths']
        )
        
        # Stage 3 loss (classification)
        losses['stage3'] = self.classification_loss(
            model_outputs['classification_logits'],
            model_outputs['gloss_labels']
        )
        
        # Stage 4 loss (CTC)
        ctc_log_probs = model_outputs['ctc_log_probs'].transpose(0, 1)  # (seq_len, batch, vocab)
        if torch.all(torch.isfinite(ctc_log_probs)):
            losses['stage4'] = self.ctc_loss(
                ctc_log_probs,
                model_outputs['ctc_targets'],
                model_outputs['ctc_output_lengths'],
                model_outputs['ctc_target_lengths']
            )
        else:
            losses['stage4'] = torch.tensor(0.0, device=ctc_log_probs.device)
        
        # Regularization loss
        losses['regularization'] = self.compute_regularization_loss(model)
        
        # Collective loss with specified fractions
        collective_loss = 0
        for stage, loss_value in losses.items():
            if torch.isfinite(loss_value):
                weighted_loss = self.loss_fractions[stage] * loss_value
                collective_loss += weighted_loss
        
        return collective_loss, losses

# stage5_data_loader.py
import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import cv2
import numpy as np
import pickle

class Stage5Dataset(Dataset):
    def __init__(self, root_train_folder, annotations_folder, 
                 label_encoder_path, vocab_path, transform=None):
        """
        Dataset for Stage 5 end-to-end training
        Combines requirements from all previous stages
        """
        self.root_train_folder = root_train_folder
        self.transform = transform
        
        # Load annotations
        csv_files = [f for f in os.listdir(annotations_folder) if f.endswith('.csv')]
        csv_path = os.path.join(annotations_folder, csv_files[0])
        self.annotations = pd.read_csv(csv_path).iloc[1:, :2]
        self.annotations.columns = ['folder_name', 'gloss_text']
        
        # Load Stage 3 label encoder
        with open(label_encoder_path, 'rb') as f:
            self.gloss_label_encoder = pickle.load(f)
        
        # Load Stage 4 vocabulary
        with open(vocab_path, 'rb') as f:
            vocab_info = pickle.load(f)
            self.char_to_idx = vocab_info['char_to_idx']
            self.idx_to_char = vocab_info['idx_to_char']
            self.vocab_size = vocab_info['vocab_size']
        
        # Build samples
        self.samples = []
        for _, row in self.annotations.iterrows():
            folder_path = os.path.join(root_train_folder, str(row['folder_name']))
            if os.path.exists(folder_path):
                frame_files = sorted([f for f in os.listdir(folder_path) 
                                    if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
                
                if len(frame_files) > 0:
                    gloss_text = str(row['gloss_text']).strip().lower()
                    
                    # Stage 3 label
                    try:
                        gloss_label = self.gloss_label_encoder.transform([gloss_text])[0]
                    except:
                        continue  # Skip unknown labels
                    
                    # Stage 4 character indices
                    char_indices = []
                    for char in gloss_text:
                        if char in self.char_to_idx:
                            char_indices.append(self.char_to_idx[char])
                    
                    if len(char_indices) > 0:
                        self.samples.append({
                            'folder_name': str(row['folder_name']),
                            'gloss_text': gloss_text,
                            'gloss_label': gloss_label,
                            'folder_path': folder_path,
                            'frame_files': frame_files,
                            'num_frames': len(frame_files),
                            'char_indices': char_indices,
                            'target_length': len(char_indices)
                        })
        
        print(f"Stage 5 dataset loaded with {len(self.samples)} samples")
    
    def __len__(self):
        return len(self.samples)
    
    def load_frames(self, folder_path, frame_files):
        """Load and preprocess frames"""
        frames = []
        for frame_file in frame_files:
            frame_path = os.path.join(folder_path, frame_file)
            frame = cv2.imread(frame_path)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (112, 112))
            frames.append(frame)
        
        # Apply transforms
        if self.transform:
            transformed_frames = []
            for frame in frames:
                frame_pil = transforms.ToPILImage()(frame)
                transformed_frame = self.transform(frame_pil)
                transformed_frames.append(transformed_frame)
            return torch.stack(transformed_frames)
        else:
            frames = torch.from_numpy(np.stack(frames)).permute(0, 3, 1, 2).float() / 255.0
            return frames
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # Load frames
        frames = self.load_frames(sample['folder_path'], sample['frame_files'])
        frame_indexes = torch.arange(len(sample['frame_files']), dtype=torch.long)
        
        return {
            'frames': frames,
            'frame_indexes': frame_indexes,
            'num_frames': sample['num_frames'],
            'gloss_text': sample['gloss_text'],
            'gloss_label': sample['gloss_label'],
            'char_indices': torch.tensor(sample['char_indices'], dtype=torch.long),
            'target_length': sample['target_length'],
            'folder_name': sample['folder_name']
        }

def stage5_collate_fn(batch):
    """Custom collate function for Stage 5"""
    batch = sorted(batch, key=lambda x: x['num_frames'], reverse=True)
    
    max_frames = batch[0]['num_frames']
    batch_size = len(batch)
    
    # Pad sequences
    padded_frames = torch.zeros(batch_size, max_frames, 3, 112, 112)
    padded_indexes = torch.zeros(batch_size, max_frames, dtype=torch.long)
    lengths = torch.zeros(batch_size, dtype=torch.long)
    gloss_labels = torch.zeros(batch_size, dtype=torch.long)
    
    # CTC targets
    ctc_targets = []
    ctc_target_lengths = torch.zeros(batch_size, dtype=torch.long)
    
    gloss_texts = []
    folder_names = []
    
    for i, sample in enumerate(batch):
        seq_len = sample['num_frames']
        padded_frames[i, :seq_len] = sample['frames']
        padded_indexes[i, :seq_len] = sample['frame_indexes']
        lengths[i] = seq_len
        gloss_labels[i] = sample['gloss_label']
        
        # CTC targets
        char_indices = sample['char_indices']
        ctc_targets.extend(char_indices.tolist())
        ctc_target_lengths[i] = len(char_indices)
        
        gloss_texts.append(sample['gloss_text'])
        folder_names.append(sample['folder_name'])
    
    ctc_targets = torch.tensor(ctc_targets, dtype=torch.long)
    
    return {
        'frames': padded_frames,
        'frame_indexes': padded_indexes,
        'lengths': lengths,
        'gloss_texts': gloss_texts,
        'gloss_labels': gloss_labels,
        'ctc_targets': ctc_targets,
        'ctc_target_lengths': ctc_target_lengths,
        'folder_names': folder_names
    }

def get_stage5_data_loader(root_train_folder, annotations_folder,
                          label_encoder_path, vocab_path, batch_size=4, 
                          shuffle=True, num_workers=2):
    """Create data loader for Stage 5"""
    transform = transforms.Compose([
        transforms.Resize((112, 112)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    dataset = Stage5Dataset(
        root_train_folder=root_train_folder,
        annotations_folder=annotations_folder,
        label_encoder_path=label_encoder_path,
        vocab_path=vocab_path,
        transform=transform
    )
    
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=stage5_collate_fn
    )
    
    return dataloader, dataset

# stage5_training.py
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
import os
from tqdm import tqdm
import matplotlib.pyplot as plt

class Stage5Trainer:
    def __init__(self, model, train_loader, val_loader=None, device='cuda'):
        """
        Trainer for Stage 5 end-to-end fine-tuning
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Collective loss function
        self.criterion = Stage5CollectiveLoss()
        
        # Optimizer for all unfrozen parameters
        trainable_params = [p for p in self.model.parameters() if p.requires_grad]
        print(f"Training {len(trainable_params)} parameter groups")
        
        # Different learning rates for different stages
        optimizer_params = [
            {'params': [p for n, p in self.model.named_parameters() 
                       if 'stage1' in n and p.requires_grad], 'lr': 1e-5},
            {'params': [p for n, p in self.model.named_parameters() 
                       if 'stage2' in n and p.requires_grad], 'lr': 5e-5},
            {'params': [p for n, p in self.model.named_parameters() 
                       if 'stage3' in n and p.requires_grad], 'lr': 1e-4},
            {'params': [p for n, p in self.model.named_parameters() 
                       if 'stage4' in n and p.requires_grad], 'lr': 1e-4},
        ]
        
        self.optimizer = optim.AdamW(optimizer_params, weight_decay=0.01)
        self.scheduler = ReduceLROnPlateau(self.optimizer, mode='min', factor=0.5, patience=3)
        
        # Training metrics
        self.train_losses = {'total': [], 'stage1': [], 'stage2': [], 'stage3': [], 'stage4': []}
        self.val_losses = {'total': [], 'stage1': [], 'stage2': [], 'stage3': [], 'stage4': []}
    
    def train_epoch(self, epoch):
        """Training epoch with collective loss"""
        self.model.train()
        epoch_losses = {'total': 0, 'stage1': 0, 'stage2': 0, 'stage3': 0, 'stage4': 0}
        num_batches = len(self.train_loader)
        
        progress_bar = tqdm(self.train_loader, desc=f'Epoch {epoch+1}')
        
        for batch_idx, batch in enumerate(progress_bar):
            # Move data to device
            frames = batch['frames'].to(self.device)
            frame_indexes = batch['frame_indexes'].to(self.device)
            lengths = batch['lengths'].to(self.device)
            gloss_texts = batch['gloss_texts']
            gloss_labels = batch['gloss_labels'].to(self.device)
            ctc_targets = batch['ctc_targets'].to(self.device)
            ctc_target_lengths = batch['ctc_target_lengths'].to(self.device)
            
            self.optimizer.zero_grad()
            
            # Forward pass through all stages
            model_outputs = self.model(
                frames, frame_indexes, lengths, gloss_texts,
                gloss_labels, ctc_targets, ctc_target_lengths
            )
            
            # Compute collective loss
            total_loss, loss_breakdown = self.criterion(model_outputs, self.model)
            
            # Backward pass
            if torch.isfinite(total_loss):
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer.step()
                
                # Update metrics
                epoch_losses['total'] += total_loss.item()
                for stage, loss_val in loss_breakdown.items():
                    if stage != 'regularization' and torch.isfinite(loss_val):
                        epoch_losses[stage] += loss_val.item()
            
            # Update progress bar
            progress_bar.set_postfix({
                'Total': f'{total_loss.item():.4f}' if torch.isfinite(total_loss) else 'inf',
                'S1': f'{loss_breakdown["stage1"].item():.3f}',
                'S2': f'{loss_breakdown["stage2"].item():.3f}',
                'S3': f'{loss_breakdown["stage3"].item():.3f}',
                'S4': f'{loss_breakdown["stage4"].item():.3f}'
            })
        
        # Average losses
        for key in epoch_losses:
            epoch_losses[key] /= num_batches
            self.train_losses[key].append(epoch_losses[key])
        
        return epoch_losses
    
    def validate(self, epoch):
        """Validation with collective loss"""
        if self.val_loader is None:
            return None
            
        self.model.eval()
        epoch_losses = {'total': 0, 'stage1': 0, 'stage2': 0, 'stage3': 0, 'stage4': 0}
        num_batches = len(self.val_loader)
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc='Validation'):
                frames = batch['frames'].to(self.device)
                frame_indexes = batch['frame_indexes'].to(self.device)
                lengths = batch['lengths'].to(self.device)
                gloss_texts = batch['gloss_texts']
                gloss_labels = batch['gloss_labels'].to(self.device)
                ctc_targets = batch['ctc_targets'].to(self.device)
                ctc_target_lengths = batch['ctc_target_lengths'].to(self.device)
                
                model_outputs = self.model(
                    frames, frame_indexes, lengths, gloss_texts,
                    gloss_labels, ctc_targets, ctc_target_lengths
                )
                
                total_loss, loss_breakdown = self.criterion(model_outputs, self.model)
                
                if torch.isfinite(total_loss):
                    epoch_losses['total'] += total_loss.item()
                    for stage, loss_val in loss_breakdown.items():
                        if stage != 'regularization' and torch.isfinite(loss_val):
                            epoch_losses[stage] += loss_val.item()
        
        # Average losses
        for key in epoch_losses:
            epoch_losses[key] /= num_batches
            self.val_losses[key].append(epoch_losses[key])
        
        return epoch_losses
    
    def train(self, num_epochs, save_dir='stage5_checkpoints'):
        """Complete training loop"""
        os.makedirs(save_dir, exist_ok=True)
        best_val_loss = float('inf')
        
        print(f"Starting Stage 5 end-to-end fine-tuning for {num_epochs} epochs...")
        
        for epoch in range(num_epochs):
            # Training
            train_losses = self.train_epoch(epoch)
            
            # Validation  
            val_losses = self.validate(epoch)
            
            # Learning rate scheduling
            if val_losses is not None:
                self.scheduler.step(val_losses['total'])
            
            # Logging
            print(f"\nEpoch {epoch+1}/{num_epochs}")
            print(f"Train - Total: {train_losses['total']:.4f}, S1: {train_losses['stage1']:.4f}, "
                  f"S2: {train_losses['stage2']:.4f}, S3: {train_losses['stage3']:.4f}, S4: {train_losses['stage4']:.4f}")
            
            if val_losses is not None:
                print(f"Val   - Total: {val_losses['total']:.4f}, S1: {val_losses['stage1']:.4f}, "
                      f"S2: {val_losses['stage2']:.4f}, S3: {val_losses['stage3']:.4f}, S4: {val_losses['stage4']:.4f}")
                
                # Save best model
                if val_losses['total'] < best_val_loss:
                    best_val_loss = val_losses['total']
                    self.save_model(os.path.join(save_dir, 'best_stage5_end2end.pth'))
                    print(f"Saved best model with val loss: {best_val_loss:.4f}")
            
            # Save checkpoint every 5 epochs
            if (epoch + 1) % 5 == 0:
                self.save_model(os.path.join(save_dir, f'stage5_checkpoint_epoch_{epoch+1}.pth'))
        
        # Save final model
        self.save_model(os.path.join(save_dir, 'final_stage5_end2end.pth'))
        
        # Plot training curves
        self.plot_training_curves(save_dir)
        
        print("Stage 5 end-to-end fine-tuning completed!")
        print(f"Best validation loss: {best_val_loss:.4f}")
    
    def save_model(self, path):
        """Save the complete end-to-end model"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
            'loss_fractions': self.criterion.loss_fractions
        }, path)
    
    def plot_training_curves(self, save_dir):
        """Plot comprehensive training curves"""
        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
        
        epochs = range(1, len(self.train_losses['total']) + 1)
        
        # Total loss
        axes[0, 0].plot(epochs, self.train_losses['total'], 'b-', label='Train', linewidth=2)
        if self.val_losses['total']:
            axes[0, 0].plot(epochs, self.val_losses['total'], 'r-', label='Val', linewidth=2)
        axes[0, 0].set_title('Total Collective Loss')
        axes[0, 0].set_xlabel('Epochs')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # Individual stage losses
        stages = ['stage1', 'stage2', 'stage3', 'stage4']
        stage_titles = ['Stage 1 (Contrastive)', 'Stage 2 (Motion)', 
                       'Stage 3 (Classification)', 'Stage 4 (CTC)']
        
        for i, (stage, title) in enumerate(zip(stages, stage_titles)):
            row = (i + 1) // 3
            col = (i + 1) % 3
            
            axes[row, col].plot(epochs, self.train_losses[stage], 'b-', label='Train', linewidth=2)
            if self.val_losses[stage]:
                axes[row, col].plot(epochs, self.val_losses[stage], 'r-', label='Val', linewidth=2)
            axes[row, col].set_title(title)
            axes[row, col].set_xlabel('Epochs')
            axes[row, col].set_ylabel('Loss')
            axes[row, col].legend()
            axes[row, col].grid(True, alpha=0.3)
        
        # Loss fractions pie chart
        fractions = [self.criterion.loss_fractions[f'stage{i+1}'] for i in range(4)]
        labels = [f'Stage {i+1}' for i in range(4)]
        axes[1, 2].pie(fractions, labels=labels, autopct='%1.1f%%', startangle=90)
        axes[1, 2].set_title('Loss Fractions')
        
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'stage5_training_curves.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()

# stage5_evaluation.py
import torch
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import editdistance
import cv2
import os

class Stage5Evaluator:
    def __init__(self, model, vocab_info, label_encoder, device='cuda'):
        """
        Comprehensive evaluator for Stage 5 end-to-end model
        """
        self.model = model
        self.vocab_info = vocab_info
        self.label_encoder = label_encoder
        self.device = device
        self.model.eval()
    
    def evaluate_comprehensive(self, data_loader, save_dir=None):
        """
        Comprehensive evaluation across all stages
        """
        print("Starting comprehensive evaluation...")
        
        results = {
            'stage1': {'visual_features': [], 'text_features': []},
            'stage2': {'ms3f_features': [], 'attention_weights': []},
            'stage3': {'predictions': [], 'labels': [], 'probabilities': []},
            'stage4': {'decoded_texts': [], 'target_texts': [], 'confidences': []},
            'folder_names': []
        }
        
        self.model.eval()
        with torch.no_grad():
            for batch in tqdm(data_loader, desc='Evaluating'):
                frames = batch['frames'].to(self.device)
                frame_indexes = batch['frame_indexes'].to(self.device)
                lengths = batch['lengths'].to(self.device)
                gloss_texts = batch['gloss_texts']
                gloss_labels = batch['gloss_labels'].to(self.device)
                ctc_targets = batch['ctc_targets'].to(self.device)
                ctc_target_lengths = batch['ctc_target_lengths'].to(self.device)
                
                # Forward pass
                outputs = self.model(
                    frames, frame_indexes, lengths, gloss_texts,
                    gloss_labels, ctc_targets, ctc_target_lengths
                )
                
                # Collect Stage 1 results
                results['stage1']['visual_features'].extend(
                    outputs['visual_features'].cpu().numpy()
                )
                results['stage1']['text_features'].extend(
                    outputs['text_features'].cpu().numpy()
                )
                
                # Collect Stage 2 results
                results['stage2']['ms3f_features'].extend(
                    outputs['ms3f_features'].cpu().numpy()
                )
                results['stage2']['attention_weights'].extend(
                    outputs['attention_weights'].cpu().numpy()
                )
                
                # Collect Stage 3 results
                stage3_probs = torch.softmax(outputs['classification_logits'], dim=1)
                stage3_preds = torch.argmax(stage3_probs, dim=1)
                
                results['stage3']['predictions'].extend(stage3_preds.cpu().numpy())
                results['stage3']['labels'].extend(gloss_labels.cpu().numpy())
                results['stage3']['probabilities'].extend(stage3_probs.cpu().numpy())
                
                # Collect Stage 4 results (CTC decoding)
                ctc_decoded = self.decode_ctc_batch(
                    outputs['ctc_log_probs'], 
                    outputs['ctc_output_lengths']
                )
                
                results['stage4']['decoded_texts'].extend(ctc_decoded)
                results['stage4']['target_texts'].extend(gloss_texts)
                
                # Calculate CTC confidences
                ctc_probs = torch.exp(outputs['ctc_log_probs'])
                for b in range(len(gloss_texts)):
                    seq_len = outputs['ctc_output_lengths'][b].item()
                    max_probs = torch.max(ctc_probs[b, :seq_len], dim=1)[0]
                    confidence = torch.mean(max_probs).item()
                    results['stage4']['confidences'].append(confidence)
                
                results['folder_names'].extend(batch['folder_names'])
        
        # Calculate metrics
        metrics = self.calculate_all_metrics(results)
        
        # Save results
        if save_dir:
            os.makedirs(save_dir, exist_ok=True)
            self.save_evaluation_results(results, metrics, save_dir)
        
        return results, metrics
    
    def decode_ctc_batch(self, log_probs, lengths):
        """Decode CTC outputs to text"""
        batch_size = log_probs.shape[0]
        decoded_texts = []
        
        for b in range(batch_size):
            seq_len = lengths[b].item()
            char_probs = log_probs[b, :seq_len]
            char_indices = torch.argmax(char_probs, dim=1)
            
            # CTC decoding: remove blanks and consecutive duplicates
            decoded_chars = []
            prev_char = None
            
            for char_idx in char_indices:
                char_idx = char_idx.item()
                if char_idx == 0:  # blank
                    prev_char = None
                    continue
                if char_idx != prev_char:
                    if char_idx in self.vocab_info['idx_to_char']:
                        decoded_chars.append(self.vocab_info['idx_to_char'][char_idx])
                    prev_char = char_idx
            
            decoded_texts.append(''.join(decoded_chars))
        
        return decoded_texts
    
    def calculate_all_metrics(self, results):
        """Calculate metrics for all stages"""
        metrics = {}
        
        # Stage 1 metrics (feature alignment)
        visual_feats = np.array(results['stage1']['visual_features'])
        text_feats = np.array(results['stage1']['text_features'])
        
        # Cosine similarity between visual and text features
        visual_norm = visual_feats / np.linalg.norm(visual_feats, axis=1, keepdims=True)
        text_norm = text_feats / np.linalg.norm(text_feats, axis=1, keepdims=True)
        alignment_scores = np.sum(visual_norm * text_norm, axis=1)
        
        metrics['stage1'] = {
            'mean_alignment': np.mean(alignment_scores),
            'std_alignment': np.std(alignment_scores)
        }
        
        # Stage 2 metrics (attention diversity)
        attention_weights = np.array(results['stage2']['attention_weights'])
        
        # Calculate attention entropy (higher = more diverse)
        attention_entropy = []
        for attn in attention_weights:
            entropy = -np.sum(attn * np.log(attn + 1e-8))
            attention_entropy.append(entropy)
        
        metrics['stage2'] = {
            'mean_attention_entropy': np.mean(attention_entropy),
            'std_attention_entropy': np.std(attention_entropy)
        }
        
        # Stage 3 metrics (classification)
        stage3_acc = accuracy_score(
            results['stage3']['labels'], 
            results['stage3']['predictions']
        )
        
        metrics['stage3'] = {
            'accuracy': stage3_acc,
            'classification_report': classification_report(
                results['stage3']['labels'],
                results['stage3']['predictions'],
                target_names=[str(i) for i in range(len(self.label_encoder.classes_))],
                output_dict=True
            )
        }
        
        # Stage 4 metrics (CTC transcription)
        cer_scores = []
        word_acc_scores = []
        seq_acc_count = 0
        
        for pred, target in zip(results['stage4']['decoded_texts'], 
                               results['stage4']['target_texts']):
            # Character Error Rate
            cer = editdistance.eval(pred, target) / max(len(target), 1)
            cer_scores.append(cer)
            
            # Word accuracy
            pred_words = pred.split()
            target_words = target.split()
            
            correct_words = 0
            for i in range(min(len(pred_words), len(target_words))):
                if pred_words[i] == target_words[i]:
                    correct_words += 1
            
            word_acc = correct_words / max(len(target_words), 1)
            word_acc_scores.append(word_acc)
            
            # Sequence accuracy
            if pred.strip() == target.strip():
                seq_acc_count += 1
        
        metrics['stage4'] = {
            'character_error_rate': np.mean(cer_scores),
            'word_accuracy': np.mean(word_acc_scores),
            'sequence_accuracy': seq_acc_count / len(results['stage4']['decoded_texts']),
            'mean_confidence': np.mean(results['stage4']['confidences'])
        }
        
        return metrics
    
    def save_evaluation_results(self, results, metrics, save_dir):
        """Save comprehensive evaluation results"""
        
        # Save metrics summary
        with open(os.path.join(save_dir, 'evaluation_summary.txt'), 'w') as f:
            f.write("Stage 5 End-to-End Evaluation Results\n")
            f.write("=" * 50 + "\n\n")
            
            f.write("Stage 1 (Multi-modal Alignment):\n")
            f.write(f"  Mean Alignment Score: {metrics['stage1']['mean_alignment']:.4f}\n")
            f.write(f"  Std Alignment Score:  {metrics['stage1']['std_alignment']:.4f}\n\n")
            
            f.write("Stage 2 (Motion Selection):\n")
            f.write(f"  Mean Attention Entropy: {metrics['stage2']['mean_attention_entropy']:.4f}\n")
            f.write(f"  Std Attention Entropy:  {metrics['stage2']['std_attention_entropy']:.4f}\n\n")
            
            f.write("Stage 3 (Classification):\n")
            f.write(f"  Accuracy: {metrics['stage3']['accuracy']:.4f}\n\n")
            
            f.write("Stage 4 (CTC Transcription):\n")
            f.write(f"  Character Error Rate: {metrics['stage4']['character_error_rate']:.4f}\n")
            f.write(f"  Word Accuracy:        {metrics['stage4']['word_accuracy']:.4f}\n")
            f.write(f"  Sequence Accuracy:    {metrics['stage4']['sequence_accuracy']:.4f}\n")
            f.write(f"  Mean Confidence:      {metrics['stage4']['mean_confidence']:.4f}\n")
        
        # Plot comprehensive results
        self.plot_comprehensive_results(results, metrics, save_dir)
        
        # Save sample predictions
        self.save_sample_predictions(results, save_dir)
    
    def plot_comprehensive_results(self, results, metrics, save_dir):
        """Plot comprehensive evaluation visualizations"""
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # Stage 1: Alignment scores distribution
        visual_feats = np.array(results['stage1']['visual_features'])
        text_feats = np.array(results['stage1']['text_features'])
        visual_norm = visual_feats / np.linalg.norm(visual_feats, axis=1, keepdims=True)
        text_norm = text_feats / np.linalg.norm(text_feats, axis=1, keepdims=True)
        alignment_scores = np.sum(visual_norm * text_norm, axis=1)
        
        axes[0, 0].hist(alignment_scores, bins=50, alpha=0.7, color='skyblue')
        axes[0, 0].axvline(np.mean(alignment_scores), color='red', linestyle='--', 
                          label=f'Mean: {np.mean(alignment_scores):.3f}')
        axes[0, 0].set_title('Stage 1: Visual-Text Alignment Scores')
        axes[0, 0].set_xlabel('Cosine Similarity')
        axes[0, 0].set_ylabel('Frequency')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # Stage 2: Attention entropy distribution
        attention_weights = np.array(results['stage2']['attention_weights'])
        attention_entropy = [-np.sum(attn * np.log(attn + 1e-8)) for attn in attention_weights]
        
        axes[0, 1].hist(attention_entropy, bins=50, alpha=0.7, color='lightgreen')
        axes[0, 1].axvline(np.mean(attention_entropy), color='red', linestyle='--',
                          label=f'Mean: {np.mean(attention_entropy):.3f}')
        axes[0, 1].set_title('Stage 2: Attention Entropy Distribution')
        axes[0, 1].set_xlabel('Entropy')
        axes[0, 1].set_ylabel('Frequency')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # Stage 3: Confusion matrix
        cm = confusion_matrix(results['stage3']['labels'], results['stage3']['predictions'])
        sns.heatmap(cm[:10, :10], annot=True, fmt='d', cmap='Blues', ax=axes[0, 2])  # Show first 10 classes
        axes[0, 2].set_title('Stage 3: Confusion Matrix (First 10 Classes)')
        axes[0, 2].set_xlabel('Predicted')
        axes[0, 2].set_ylabel('Actual')
        
        # Stage 4: CTC confidence distribution
        confidences = results['stage4']['confidences']
        axes[1, 0].hist(confidences, bins=50, alpha=0.7, color='orange')
        axes[1, 0].axvline(np.mean(confidences), color='red', linestyle='--',
                          label=f'Mean: {np.mean(confidences):.3f}')
        axes[1, 0].set_title('Stage 4: CTC Confidence Distribution')
        axes[1, 0].set_xlabel('Confidence')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].legend()
        axes[1, 0].grid(True, alpha=0.3)
        
        # Combined metrics comparison
        stage_names = ['Stage 1\n(Alignment)', 'Stage 2\n(Attention)', 
                      'Stage 3\n(Classification)', 'Stage 4\n(CTC)']
        stage_scores = [
            metrics['stage1']['mean_alignment'],
            metrics['stage2']['mean_attention_entropy'] / 3,  # Normalize entropy
            metrics['stage3']['accuracy'],
            1 - metrics['stage4']['character_error_rate']  # Convert CER to accuracy
        ]
        
        bars = axes[1, 1].bar(stage_names, stage_scores, 
                             color=['skyblue', 'lightgreen', 'lightcoral', 'orange'])
        axes[1, 1].set_title('Stage Performance Comparison')
        axes[1, 1].set_ylabel('Normalized Score')
        axes[1, 1].set_ylim(0, 1)
        
        # Add value labels on bars
        for bar, score in zip(bars, stage_scores):
            height = bar.get_height()
            axes[1, 1].text(bar.get_x() + bar.get_width()/2., height + 0.01,
                           f'{score:.3f}', ha='center', va='bottom')
        
        # Overall system metrics
        system_metrics = ['Visual-Text\nAlignment', 'Motion\nDiversity', 
                         'Classification\nAccuracy', 'Transcription\nQuality']
        system_values = [
            metrics['stage1']['mean_alignment'],
            min(metrics['stage2']['mean_attention_entropy'] / 3, 1.0),
            metrics['stage3']['accuracy'],
            metrics['stage4']['sequence_accuracy']
        ]
        
        wedges, texts, autotexts = axes[1, 2].pie(system_values, labels=system_metrics, 
                                                 autopct='%1.2f', startangle=90,
                                                 colors=['skyblue', 'lightgreen', 
                                                        'lightcoral', 'orange'])
        axes[1, 2].set_title('End-to-End System Performance')
        
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'comprehensive_evaluation.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def save_sample_predictions(self, results, save_dir):
        """Save sample predictions from all stages"""
        
        with open(os.path.join(save_dir, 'sample_predictions.txt'), 'w') as f:
            f.write("Sample Predictions from All Stages\n")
            f.write("=" * 50 + "\n\n")
            
            # Show first 10 samples
            for i in range(min(10, len(results['folder_names']))):
                f.write(f"Sample {i+1}: {results['folder_names'][i]}\n")
                f.write("-" * 30 + "\n")
                
                # Stage 3 prediction
                stage3_pred = results['stage3']['predictions'][i]
                stage3_label = results['stage3']['labels'][i]
                stage3_prob = np.max(results['stage3']['probabilities'][i])
                
                f.write(f"Stage 3 Classification:\n")
                f.write(f"  Predicted: {stage3_pred} (confidence: {stage3_prob:.3f})\n")
                f.write(f"  Actual:    {stage3_label}\n")
                f.write(f"  Correct:   {'✓' if stage3_pred == stage3_label else '✗'}\n\n")
                
                # Stage 4 transcription
                stage4_pred = results['stage4']['decoded_texts'][i]
                stage4_target = results['stage4']['target_texts'][i]
                stage4_conf = results['stage4']['confidences'][i]
                
                f.write(f"Stage 4 Transcription:\n")
                f.write(f"  Predicted: '{stage4_pred}' (confidence: {stage4_conf:.3f})\n")
                f.write(f"  Target:    '{stage4_target}'\n")
                f.write(f"  Match:     {'✓' if stage4_pred.strip() == stage4_target.strip() else '✗'}\n")
                
                # Character error rate for this sample
                cer = editdistance.eval(stage4_pred, stage4_target) / max(len(stage4_target), 1)
                f.write(f"  CER:       {cer:.3f}\n\n")

    def generate_attention_overlays(self, data_loader, sample_folder, save_dir, num_samples=5):
        """
        Generate attention map overlays on video frames for specified sample folder
        """
        print(f"Generating attention overlays for folder: {sample_folder}")
        
        os.makedirs(save_dir, exist_ok=True)
        
        # Find the specific sample
        target_sample = None
        self.model.eval()
        
        with torch.no_grad():
            for batch in data_loader:
                folder_names = batch['folder_names']
                
                if sample_folder in folder_names:
                    sample_idx = folder_names.index(sample_folder)
                    
                    frames = batch['frames'][sample_idx:sample_idx+1].to(self.device)
                    frame_indexes = batch['frame_indexes'][sample_idx:sample_idx+1].to(self.device)
                    lengths = batch['lengths'][sample_idx:sample_idx+1].to(self.device)
                    gloss_texts = [batch['gloss_texts'][sample_idx]]
                    gloss_labels = batch['gloss_labels'][sample_idx:sample_idx+1].to(self.device)
                    ctc_targets = batch['ctc_targets'].to(self.device)  # This needs proper indexing
                    ctc_target_lengths = batch['ctc_target_lengths'][sample_idx:sample_idx+1].to(self.device)
                    
                    # Forward pass
                    outputs = self.model(
                        frames, frame_indexes, lengths, gloss_texts,
                        gloss_labels, ctc_targets, ctc_target_lengths  
                    )
                    
                    # Get attention weights from Stage 3
                    attention_weights = outputs['attention_weights'][0].cpu().numpy()  # (num_ms3f_features,)
                    
                    # Get original frames for visualization
                    original_frames = frames[0].cpu().numpy()  # (num_frames, 3, 112, 112)
                    
                    # Create attention overlays
                    self.create_attention_overlay_frames(
                        original_frames, attention_weights, 
                        sample_folder, save_dir, outputs
                    )
                    
                    break
    
    def create_attention_overlay_frames(self, frames, attention_weights, folder_name, save_dir, outputs):
        """Create attention overlay visualizations on frames"""
        
        num_frames = frames.shape[0]
        
        # Normalize frames for display
        frames_display = np.transpose(frames, (0, 2, 3, 1))  # (T, H, W, C)
        frames_display = (frames_display * np.array([0.229, 0.224, 0.225]) + 
                         np.array([0.485, 0.456, 0.406]))  # Denormalize
        frames_display = np.clip(frames_display, 0, 1)
        
        # Create attention heatmap
        # attention_weights shape: (num_ms3f_features,) typically (8,)
        # We need to map this to frame-level attention
        
        # Simple mapping: distribute attention across frames uniformly
        frame_attention = np.ones(num_frames) * np.mean(attention_weights)
        
        # Create more sophisticated mapping if we have frame-to-MS3F correspondence
        if hasattr(outputs, 'selected_indexes'):
            selected_indexes = outputs['selected_indexes'][0].cpu().numpy()  # (top_k, 2)
            frame_attention = np.zeros(num_frames)
            
            for i, attn_weight in enumerate(attention_weights):
                if i < len(selected_indexes):
                    frame1_idx, frame2_idx = selected_indexes[i]
                    if frame1_idx < num_frames:
                        frame_attention[frame1_idx] += attn_weight
                    if frame2_idx < num_frames:
                        frame_attention[frame2_idx] += attn_weight
        
        # Normalize frame attention
        if np.max(frame_attention) > 0:
            frame_attention = frame_attention / np.max(frame_attention)
        
        # Create overlay visualization
        fig, axes = plt.subplots(2, min(8, num_frames), figsize=(20, 8))
        if num_frames == 1:
            axes = axes.reshape(2, 1)
        
        for i in range(min(8, num_frames)):  # Show first 8 frames
            frame = frames_display[i]
            attention = frame_attention[i]
            
            # Original frame
            axes[0, i].imshow(frame)
            axes[0, i].set_title(f'Frame {i+1}')
            axes[0, i].axis('off')
            
            # Frame with attention overlay
            axes[1, i].imshow(frame)
            
            # Create attention heatmap overlay
            attention_map = np.full((112, 112), attention, dtype=np.float32)
            overlay = axes[1, i].imshow(attention_map, alpha=0.4, cmap='jet', vmin=0, vmax=1)
            
            axes[1, i].set_title(f'Attention: {attention:.3f}')
            axes[1, i].axis('off')
        
        # Add colorbar
        cbar = plt.colorbar(overlay, ax=axes[1, :], orientation='horizontal', 
                           fraction=0.05, pad=0.1)
        cbar.set_label('Attention Weight')
        
        plt.suptitle(f'Attention Overlay for Sample: {folder_name}', fontsize=16)
        plt.tight_layout()
        
        # Save the visualization
        plt.savefig(os.path.join(save_dir, f'{folder_name}_attention_overlay.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()
        
        # Also create a summary attention plot
        plt.figure(figsize=(12, 6))
        
        # Plot 1: MS3F feature attention
        plt.subplot(1, 2, 1)
        plt.bar(range(len(attention_weights)), attention_weights, color='skyblue')
        plt.title('MS3F Feature Attention Weights')
        plt.xlabel('MS3F Feature Index')
        plt.ylabel('Attention Weight')
        plt.grid(True, alpha=0.3)
        
        # Plot 2: Frame-level attention
        plt.subplot(1, 2, 2)
        plt.plot(range(num_frames), frame_attention, 'ro-', linewidth=2, markersize=6)
        plt.title('Frame-Level Attention')
        plt.xlabel('Frame Index')
        plt.ylabel('Attention Weight')
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f'{folder_name}_attention_analysis.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Attention overlays saved for {folder_name}")

# stage5_main.py
def main_stage5():
    """Main training script for Stage 5 end-to-end fine-tuning"""
    # Configuration
    config = {
        'root_train_folder': 'path/to/train/folders',
        'annotations_folder': 'path/to/annotations',
        'stage1_model_path': 'stage1_checkpoints/best_model.pth',
        'stage2_model_path': 'stage2_checkpoints/best_ms3f_extractor.pth',
        'stage3_model_path': 'stage3_checkpoints/best_stage3_classifier.pth',
        'stage4_model_path': 'stage4_checkpoints/best_stage4_ctc.pth',
        'label_encoder_path': 'stage3_checkpoints/label_encoder.pkl',
        'vocab_path': 'stage4_checkpoints/ctc_vocabulary.pkl',
        'batch_size': 4,  # Small batch size due to memory requirements
        'num_epochs': 30,  # Fewer epochs for fine-tuning
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'save_dir': 'stage5_checkpoints',
        'train_split': 0.8,
        'evaluation_samples': 'sample_folder_name'  # For attention visualization
    }
    
    print(f"Using device: {config['device']}")
    print("Starting Stage 5: End-to-End Multi-Stage Fine-tuning")
    
    # Load dataset
    print("Loading Stage 5 dataset...")
    full_loader, full_dataset = get_stage5_data_loader(
        root_train_folder=config['root_train_folder'],
        annotations_folder=config['annotations_folder'],
        label_encoder_path=config['label_encoder_path'],
        vocab_path=config['vocab_path'],
        batch_size=config['batch_size'],
        shuffle=False
    )
    
    print(f"Dataset loaded with {len(full_dataset)} samples")
    
    # Create train/validation split
    from torch.utils.data import random_split
    train_size = int(config['train_split'] * len(full_dataset))
    val_size = len(full_dataset) - train_size
    
    train_dataset, val_dataset = random_split(
        full_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    train_loader = DataLoader(
        train_dataset, batch_size=config['batch_size'], shuffle=True,
        num_workers=2, pin_memory=True, collate_fn=stage5_collate_fn
    )
    
    val_loader = DataLoader(
        val_dataset, batch_size=config['batch_size'], shuffle=False,
        num_workers=2, pin_memory=True, collate_fn=stage5_collate_fn
    )
    
    print(f"Train samples: {len(train_dataset)}, Val samples: {len(val_dataset)}")
    
    # Initialize Stage 5 end-to-end model
    print("Initializing Stage 5 End-to-End Model...")
    stage5_model = Stage5EndToEndModel(
        stage1_path=config['stage1_model_path'],
        stage2_path=config['stage2_model_path'],
        stage3_path=config['stage3_model_path'],
        stage4_path=config['stage4_model_path'],
        vocab_path=config['vocab_path'],
        label_encoder_path=config['label_encoder_path'],
        device=config['device']
    )
    
    # Initialize trainer
    trainer = Stage5Trainer(
        model=stage5_model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=config['device']
    )
    
    # Start end-to-end fine-tuning
    trainer.train(
        num_epochs=config['num_epochs'],
        save_dir=config['save_dir']
    )
    
    print("Stage 5 end-to-end fine-tuning completed!")
    
    # Comprehensive evaluation
    print("\nStarting comprehensive evaluation...")
    
    # Load vocabulary and label encoder for evaluation
    with open(config['vocab_path'], 'rb') as f:
        import pickle
        vocab_info = pickle.load(f)
        
    with open(config['label_encoder_path'], 'rb') as f:
        label_encoder = pickle.load(f)
    
    evaluator = Stage5Evaluator(
        model=stage5_model,
        vocab_info=vocab_info,
        label_encoder=label_encoder,
        device=config['device']
    )
    
    # Comprehensive evaluation
    results, metrics = evaluator.evaluate_comprehensive(
        val_loader,
        save_dir=os.path.join(config['save_dir'], 'evaluation')
    )
    
    # Print final results
    print("\n" + "="*60)
    print("STAGE 5 END-TO-END FINE-TUNING RESULTS")
    print("="*60)
    print(f"Stage 1 - Visual-Text Alignment:     {metrics['stage1']['mean_alignment']:.4f}")
    print(f"Stage 2 - Attention Diversity:       {metrics['stage2']['mean_attention_entropy']:.4f}")
    print(f"Stage 3 - Classification Accuracy:   {metrics['stage3']['accuracy']:.4f}")
    print(f"Stage 4 - CTC Character Error Rate:  {metrics['stage4']['character_error_rate']:.4f}")
    print(f"Stage 4 - CTC Sequence Accuracy:     {metrics['stage4']['sequence_accuracy']:.4f}")
    print("="*60)
    
    # Generate attention overlays for sample
    if config['evaluation_samples']:
        print(f"\nGenerating attention overlays for sample: {config['evaluation_samples']}")
        evaluator.generate_attention_overlays(
            val_loader,
            config['evaluation_samples'],
            os.path.join(config['save_dir'], 'attention_overlays')
        )
    
    print("\n🎉 COMPLETE SIGN LANGUAGE SYSTEM READY! 🎉")
    print("All 5 stages completed with end-to-end optimization!")

if __name__ == "__main__":
    main_stage5()