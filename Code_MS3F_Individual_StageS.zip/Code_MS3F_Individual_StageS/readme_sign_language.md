# Sign Language Multi-Modal Learning: Stage 1 - Visual and Text Feature Extraction & Alignment

This repository implements a comprehensive multi-modal learning system for sign language understanding, focusing on aligning visual sign language representations with textual gloss descriptions through contrastive learning.

## 🎯 Overview

The system extracts and aligns features from two modalities:
- **Visual**: Sign language video sequences using ResNet-50
- **Textual**: Gloss descriptions using fine-tuned BERT

Through contrastive cross-modal learning, the model learns to create a shared embedding space where semantically similar visual signs and text descriptions are positioned close together.

## 🏗️ Architecture

### Model Components

1. **Visual Encoder (ResNet-50)**
   - Pre-trained ResNet-50 backbone for spatial feature extraction
   - Temporal aggregation for video sequence processing
   - Input: 112×112×3 RGB frames
   - Output: 1024-dimensional visual features

2. **Text Encoder (Fine-tuned BERT)**
   - BERT-base-uncased with selective fine-tuning (last 2 layers)
   - Processes gloss text descriptions
   - Output: 1024-dimensional text features

3. **Contrastive Loss Function**
   - InfoNCE-style contrastive learning
   - Temperature-scaled similarity computation
   - Bidirectional alignment (visual→text, text→visual)

### Data Flow

```
Video Frames (B×T×3×112×112) → ResNet-50 → Visual Features (B×1024)
                                                ↓
                                        Contrastive Loss
                                                ↑
Gloss Text (B×sequences)     → BERT    → Text Features (B×1024)
```

## 📁 Project Structure

```
sign-language-multimodal/
├── data_loader.py          # Dataset and data loading utilities
├── model.py               # Model architectures and loss functions
├── training.py            # Training pipeline and utilities
├── inference.py           # Inference and feature extraction
├── main.py               # Main training script
├── requirements.txt       # Python dependencies
├── checkpoints/          # Model checkpoints (created during training)
├── configs/              # Configuration files
└── README.md            # This file
```

## 🚀 Quick Start

### 1. Installation

```bash
# Clone the repository
git clone <repository-url>
cd sign-language-multimodal

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Data Preparation

Organize your data as follows:

```
data/
├── train/                    # Root train folder
│   ├── video_001/           # Subfolder containing video frames
│   │   ├── frame_001.jpg
│   │   ├── frame_002.jpg
│   │   └── ...
│   ├── video_002/
│   └── ...
└── annotations/             # Annotations folder
    └── annotations.csv      # CSV file with gloss descriptions
```

**CSV Format:**
```csv
header_row_to_skip,header_col_2
video_001,hello world
video_002,good morning
video_003,thank you
...
```

- First row: Discarded (headers)
- First column: Subfolder names from train directory
- Second column: Gloss text descriptions

### 3. Configuration

Update the configuration in `main.py`:

```python
config = {
    'root_train_folder': 'data/train',           # Path to video folders
    'annotations_folder': 'data/annotations',     # Path to CSV annotations
    'batch_size': 16,                            # Batch size for training
    'num_epochs': 100,                           # Number of training epochs
    'feature_dim': 1024,                         # Feature embedding dimension
    'device': 'cuda',                            # 'cuda' or 'cpu'
    'save_dir': 'checkpoints'                    # Directory to save models
}
```

### 4. Training

```bash
# Start training
python main.py
```

Training will:
- Load and preprocess the dataset
- Initialize the multi-modal model
- Train with contrastive loss
- Save checkpoints every 10 epochs
- Save the best model based on validation loss

### 5. Monitor Training

```bash
# Training output example
Using device: cuda
Loading dataset...
Loaded 1250 valid samples
Dataset loaded with 1250 samples
Initializing model...

Epoch 1/100: 100%|██████████| 79/79 [02:15<00:00]
Train Loss: 2.3456
Val Loss: 2.1234
Saved best model!

Epoch 10/100: 100%|██████████| 79/79 [02:12<00:00]
Train Loss: 1.8765
Val Loss: 1.7432
```

## 🔧 Usage Examples

### Feature Extraction for Downstream Tasks

```python
from inference import SignLanguageInference
import torch

# Load trained model
model = SignLanguageInference('checkpoints/best_model.pth')

# Example video frames (batch_size=1, frames=16, channels=3, height=112, width=112)
frames = torch.randn(1, 16, 3, 112, 112)
text_list = ["hello world"]

# Extract visual features only
visual_features = model.extract_visual_features(frames)
print(f"Visual features shape: {visual_features.shape}")  # (1, 1024)

# Extract text features only
text_features = model.extract_text_features(text_list)
print(f"Text features shape: {text_features.shape}")      # (1, 1024)

# Extract both features simultaneously
visual_feats, text_feats = model.extract_both_features(frames, text_list)
```

### Custom Data Loading

```python
from data_loader import get_data_loader

# Create custom data loader
train_loader, dataset = get_data_loader(
    root_train_folder='path/to/your/data',
    annotations_folder='path/to/your/annotations',
    batch_size=32,
    shuffle=True
)

# Iterate through data
for batch in train_loader:
    frames = batch['frames']          # (B, T, 3, 112, 112)
    gloss_text = batch['gloss_text']  # List of strings
    folder_names = batch['folder_name']  # List of folder names
    break
```

## 📊 Model Performance

### Training Hyperparameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| Visual Learning Rate | 1e-4 | ResNet-50 encoder learning rate |
| Text Learning Rate | 2e-5 | BERT encoder learning rate |
| Weight Decay | 0.01 | L2 regularization |
| Batch Size | 16 | Training batch size |
| Temperature | 0.07 | Contrastive loss temperature |
| Max Frames | 16 | Maximum frames per video |
| Feature Dimension | 1024 | Embedding dimension |

### Expected Training Metrics

- **Initial Loss**: ~2.5-3.0 (random initialization)
- **Converged Loss**: ~0.8-1.2 (well-aligned features)
- **Training Time**: ~2-3 minutes/epoch (GPU with batch_size=16)

## 🛠️ Advanced Usage

### Custom Model Configuration

```python
from model import SignLanguageModel

# Initialize with custom feature dimension
model = SignLanguageModel(feature_dim=1024)

# Access individual encoders
visual_encoder = model.visual_encoder
text_encoder = model.text_encoder
```

### Fine-tuning Strategies

1. **Freeze Visual Encoder**: For text-heavy tasks
```python
for param in model.visual_encoder.parameters():
    param.requires_grad = False
```

2. **Different Learning Rates**: Already implemented in trainer
```python
optimizer = optim.AdamW([
    {'params': model.visual_encoder.parameters(), 'lr': 1e-4},
    {'params': model.text_encoder.parameters(), 'lr': 2e-5}
])
```

## 🔍 Troubleshooting

### Common Issues

1. **CUDA Out of Memory**
   ```python
   # Reduce batch size
   config['batch_size'] = 8
   
   # Or reduce max frames
   dataset = SignLanguageDataset(..., max_frames=8)
   ```

2. **Missing Video Frames**
   ```bash
   # Check data structure
   ls data/train/video_001/
   # Should contain: frame_001.jpg, frame_002.jpg, etc.
   ```

3. **CSV Format Issues**
   ```python
   # Verify CSV structure
   import pandas as pd
   df = pd.read_csv('data/annotations/annotations.csv')
   print(df.head())
   ```

### Performance Optimization

1. **Multi-GPU Training**: Wrap model with `DataParallel`
2. **Mixed Precision**: Use `torch.cuda.amp` for faster training
3. **Data Loading**: Increase `num_workers` in DataLoader

## 📈 Next Steps (Future Stages)

- **Stage 2**: Sign language recognition and classification
- **Stage 3**: Cross-modal retrieval (video→text, text→video)
- **Stage 4**: Generative sign language synthesis
- **Stage 5**: Real-time sign language translation

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/new-feature`)
3. Commit changes (`git commit -am 'Add new feature'`)
4. Push to branch (`git push origin feature/new-feature`)
5. Create Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- ResNet architecture: [Deep Residual Learning for Image Recognition](https://arxiv.org/abs/1512.03385)
- BERT model: [BERT: Pre-training of Deep Bidirectional Transformers](https://arxiv.org/abs/1810.04805)
- Contrastive Learning: [Learning Transferable Visual Models From Natural Language Supervision](https://arxiv.org/abs/2103.00020)

## 📞 Support

For questions and support:
- Open an issue on GitHub
- Contact: [your-email@example.com]
- Documentation: [project-docs-url]

---

**Note**: This is Stage 1 of a multi-stage sign language understanding system. The trained model from this stage provides aligned visual and textual features that serve as the foundation for downstream tasks in subsequent stages.