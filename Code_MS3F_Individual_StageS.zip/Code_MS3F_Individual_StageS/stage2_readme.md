# Stage 2: Motion Selected Sparse Spatial Features (MS3F) Extractor

Building upon Stage 1's aligned visual-text features, Stage 2 develops a sophisticated motion-aware feature selection system that identifies the most informative spatial features based on temporal motion patterns.

## 🎯 Overview

Stage 2 introduces **Motion Selected Sparse Spatial Features (MS3F)** - a novel approach that:

1. **Extracts Holistic Spatial Features** from individual frames using the trained Stage 1 model
2. **Computes Motion Features** through frame differencing to capture temporal dynamics  
3. **Applies GRU-based Selection** to identify top-K most important motion patterns
4. **Creates Sparse Spatial Features** by selecting corresponding holistic features

This results in a compact, motion-aware representation that focuses on the most discriminative spatial-temporal patterns for sign language understanding.

## 🏗️ Architecture

### Pipeline Overview

```
Input Video Frames → Stage 1 Visual Encoder → Holistic Spatial Features (1024-dim per frame)
                                                        ↓
                                              Frame Differencing
                                                        ↓
                                              Motion Features (1024-dim per frame pair)
                                                        ↓
                                              GRU Motion Selector
                                                        ↓
                                              Top-K Motion Indexes
                                                        ↓
                                              MS3F Features (K×1024-dim)
```

### Key Components

1. **Holistic Spatial Feature Extractor**
   - Uses frozen Stage 1 visual encoder
   - Extracts 1024-dim features per frame
   - Maintains frame-level spatial information

2. **Motion Feature Extractor**
   - Computes frame differences: `f(t+1) - f(t)`
   - Processes differences through neural network
   - Preserves temporal relationships between frames

3. **GRU Motion Selector**
   - Bidirectional GRU processes motion sequence
   - Attention mechanism scores motion importance
   - Selects top-K most informative motions

4. **MS3F Creator**
   - Maps selected motion indexes back to spatial features
   - Creates compact representation: K×1024 features
   - Preserves most discriminative spatial-temporal patterns

## 📁 Project Structure

```
stage2-ms3f/
├── stage2_data_loader.py          # Variable-length sequence data loading
├── holistic_feature_extractor.py  # Stage 1 model integration
├── motion_feature_extractor.py    # Frame differencing and motion processing
├── gru_motion_selector.py         # GRU-based motion selection
├── ms3f_model.py                  # Complete MS3F extractor
├── stage2_training.py             # Training pipeline
├── stage2_inference.py            # Inference and feature extraction
├── stage2_main.py                 # Main training script
├── utils/
│   ├── visualizer.py             # Motion selection visualization
│   ├── evaluator.py              # Performance evaluation
│   └── config.py                 # Configuration management
├── stage2_checkpoints/           # Trained models
└── README.md                     # This file
```

## 🚀 Quick Start

### 1. Prerequisites

Ensure Stage 1 is completed and you have:
- Trained Stage 1 model: `stage1_checkpoints/best_model.pth`
- Same data structure as Stage 1

```bash
# Install additional dependencies for Stage 2
pip install matplotlib seaborn  # For visualization
```

### 2. Configuration

Update paths in `stage2_main.py`:

```python
config = {
    'root_train_folder': 'data/train',                    # Same as Stage 1
    'annotations_folder': 'data/annotations',             # Same as Stage 1  
    'stage1_model_path': 'stage1_checkpoints/best_model.pth',  # Stage 1 output
    'batch_size': 8,                                      # Smaller due to variable lengths
    'num_epochs': 50,                                     # Fewer epochs needed
    'top_k': 8,                                          # Number of motion features to select
    'feature_dim': 1024,                                 # Feature dimension
    'hidden_dim': 512,                                   # GRU hidden dimension
    'device': 'cuda',
    'save_dir': 'stage2_checkpoints'
}
```

### 3. Training

```bash
# Start Stage 2 training
python stage2_main.py
```

Training Process:
```
Loading Stage 2 dataset...
Loaded 1250 samples for Stage 2
Initializing MS3F Extractor...
Holistic Spatial Feature Extractor loaded from stage1_checkpoints/best_model.pth

Epoch 1/50: 100%|██████████| 157/157 [03:45<00:00]
Train Loss: 0.8234
Val Loss: 0.7891

Epoch 10/50: 100%|██████████| 157/157 [03:42<00:00]  
Train Loss: 0.4567
Val Loss: 0.4234
Saved best MS3F extractor!
```

## 📊 Model Architecture Details

### Holistic Spatial Features
- **Input**: Video frames (B×T×3×112×112)
- **Processing**: Stage 1 ResNet-50 encoder (frozen)
- **Output**: Per-frame features (B×T×1024)
- **Purpose**: Capture spatial patterns in each frame

### Motion Features  
- **Input**: Holistic spatial features (B×T×1024)
- **Processing**: Frame differencing + neural processing
- **Output**: Motion features (B×(T-1)×1024) 
- **Purpose**: Capture temporal dynamics between frames

### GRU Motion Selector
- **Architecture**: 2-layer bidirectional GRU
- **Hidden Size**: 512 (1024 with bidirection)
- **Attention**: Single-layer attention mechanism
- **Output**: Top-K motion importance scores
- **Purpose**: Select most informative motion patterns

### MS3F Features
- **Input**: Top-K motion indexes + holistic features
- **Processing**: Index-based feature selection
- **Output**: Compact representation (B×K×1024)
- **Purpose**: Motion-aware sparse spatial features

## 🔧 Usage Examples

### Basic Feature Extraction

```python
from stage2_inference import MS3FInference
import torch

# Load trained MS3F extractor  
ms3f_extractor = MS3FInference('stage2_checkpoints/best_ms3f_extractor.pth')

# Example input (variable length video)
frames = torch.randn(1, 25, 3, 112, 112)  # 25 frames
frame_indexes = torch.arange(25).unsqueeze(0)
lengths = torch.tensor([25])

# Extract MS3F features
ms3f_features = ms3f_extractor.extract_ms3f_features(frames, frame_indexes, lengths)
print(f"MS3F shape: {ms3f_features.shape}")  # (1, 8, 1024)

# Use for downstream classification
# classifier_input = ms3f_features.flatten(1)  # (1, 8192)
```

### Advanced Usage with Visualization

```python
from utils.visualizer import MS3FVisualizer
import matplotlib.pyplot as plt

# Initialize visualizer
visualizer = MS3FVisualizer(ms3f_extractor.model)

# Visualize motion selection for a batch
visualizer.visualize_motion_selection(
    frames=frames,
    frame_indexes=frame_indexes, 
    lengths=lengths,
    save_path='motion_selection_viz'
)
```

### Performance Evaluation

```python
from utils.evaluator import MS3FEvaluator

# Initialize evaluator
evaluator = MS3FEvaluator(ms3f_extractor.model)

# Evaluate motion diversity
diversity_score = evaluator.evaluate_motion_diversity(test_loader)
print(f"Average motion diversity: {diversity_score:.3f}")

# Evaluate importance score distribution  
importance_stats = evaluator.evaluate_motion_importance_distribution(test_loader)
print(f"Importance scores - Mean: {importance_stats['mean']:.3f}, Std: {importance_stats['std']:.3f}")
```

## 📈 Training Parameters & Performance

### Hyperparameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| Batch Size | 8 | Smaller due to variable sequence lengths |
| Learning Rate | 1e-4 | Same for motion extractor and GRU |
| Weight Decay | 0.01 | L2 regularization |
| Top-K | 8 | Number of selected motion features |
| GRU Hidden Dim | 512 | Hidden dimension (1024 with bidirection) |
| GRU Layers | 2 | Number of GRU layers |
| Max Epochs | 50 | Fewer epochs due to pre-trained backbone |

### Expected Performance

- **Initial Loss**: ~0.8-1.0 (motion diversity + importance)
- **Converged Loss**: ~0.3-0.5 (well-selected diverse motions)  
- **Training Time**: ~3-4 minutes/epoch (GPU, batch_size=8)
- **Motion Diversity**: >0.7 (high diversity in selected features)
- **Feature Compression**: 8-16x reduction (from T×1024 to 8×1024)

### Loss Components

1. **Diversity Loss**: Encourages diverse selected features
   ```python
   diversity_loss = mean(cosine_similarity(selected_features))
   ```

2. **Importance Loss**: Encourages high importance scores
   ```python  
   importance_loss = -mean(importance_scores)
   ```

3. **Total Loss**: `diversity_loss + 0.1 * importance_loss`

## 🔍 Advanced Configuration

### Custom Top-K Selection

```python
# Different K values for different applications
config_classification = {'top_k': 8}    # Standard classification
config_retrieval = {'top_k': 16}        # More features for retrieval
config_mobile = {'top_k': 4}            # Lightweight for mobile
```

### Motion Sensitivity Tuning

```python
# Adjust motion threshold for different sign languages
config = {
    'motion_threshold': 0.05,  # More sensitive (subtle motions)
    'motion_threshold': 0.15,  # Less sensitive (major motions only)
}
```

### GRU Architecture Variants

```python
# Lightweight version
config_light = {
    'hidden_dim': 256,
    'num_layers': 1,
}

# Heavy version  
config_heavy = {
    'hidden_dim': 1024,
    'num_layers': 3,
}
```

## 🛠️ Troubleshooting

### Common Issues

1. **Variable Sequence Lengths**
   ```python
   # Ensure proper padding in data loader
   # Use custom collate function: stage2_collate_fn
   ```

2. **Memory Issues with Long Videos**
   ```python
   # Reduce batch size or implement sequence chunking
   config['batch_size'] = 4
   config['max_frames'] = 32
   ```

3. **Poor Motion Selection**
   ```python
   # Adjust diversity weight
   config['diversity_weight'] = 2.0  # Increase diversity
   config['importance_weight'] = 0.05  # Reduce importance weight
   ```

### Performance Optimization

1. **Faster Training**: Freeze more Stage 1 layers
2. **Better Selection**: Increase GRU hidden dimension  
3. **Memory Efficiency**: Use gradient checkpointing

## 📊 Comparison with Stage 1

| Aspect | Stage 1 | Stage 2 (MS3F) |
|--------|---------|----------------|
| **Output** | Full temporal features | Sparse selected features |
| **Size** | T×1024 (variable) | 8×1024 (fixed) |
| **Focus** | Cross-modal alignment | Motion-aware selection |
| **Computation** | High (full sequence) | Low (sparse features) |
| **Downstream** | General purpose | Motion-optimized |

## 🎯 Applications & Next Steps

### Immediate Applications
- **Sign Language Classification**: Use MS3F as classifier input
- **Action Recognition**: Apply to general action videos
- **Video Retrieval**: Compact motion-aware representations
- **Real-time Processing**: Efficient sparse feature extraction

### Stage 3 Preparation
Stage 2 outputs serve as input for:
- **Temporal Sequence Models**: LSTM/Transformer on MS3F
- **Multi-modal Fusion**: Combine with Stage 1 text features
- **Hierarchical Learning**: Build upon motion patterns

## 🤝 Integration with Downstream Tasks

### Classification Pipeline
```python
# Complete pipeline from video to classification
video_frames → Stage 1 (Holistic) → Stage 2 (MS3F) → Classifier → Predictions
```

### Feature Dimensions Flow
```
Raw Video: (B, T, 3, 112, 112)
↓ Stage 1
Holistic: (B, T, 1024)  
↓ Stage 2  
MS3F: (B, 8, 1024)
↓ Classifier
Logits: (B, num_classes)
```

## 📄 Citation & References

If you use this MS3F extractor, please cite:

```bibtex
@article{ms3f_stage2,
  title={Motion Selected Sparse Spatial Features for Sign Language Understanding},
  author={Your Name},
  year={2025},
  note={Stage 2 of Multi-Modal Sign Language Learning System}
}
```

## 📞 Support

For Stage 2 specific questions:
- Check Stage 1 completion and model availability
- Verify variable-length sequence handling
- Monitor motion selection quality through visualization

---

**Note**: Stage 2 builds directly on Stage 1 outputs. Ensure Stage 1 training is completed successfully before proceeding with MS3F extraction.