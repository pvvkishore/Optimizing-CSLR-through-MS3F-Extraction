# stage2_inference.py - Fixed version
import torch
import numpy as np
import os

class MS3FInference:
    def __init__(self, model_path, device='cuda'):
        self.device = device
        self.model_path = model_path
        
        print(f"Loading MS3F model from: {model_path}")
        
        # Check if model file exists
        if not os.path.exists(model_path):
            print(f"⚠️  Model file not found: {model_path}")
            print("Creating dummy MS3F model for testing...")
            self.model = None
            self.is_dummy = True
            return
        
        try:
            # Load MS3F model with proper initialization
            if model_path.endswith('.pth'):
                checkpoint = torch.load(model_path, map_location=device)
                
                # Try to import MS3FExtractor
                try:
                    from stage2_model import MS3FExtractor
                    # Initialize with required stage1_model_path
                    stage1_path = checkpoint.get('stage1_model_path', '/home/pvvkishore/Desktop/TVC_May21/checkpoints/final_model.pth')
                    
                    # Get model parameters from checkpoint
                    top_k = checkpoint.get('top_k', 8)
                    feature_dim = checkpoint.get('feature_dim', 1024)
                    
                    self.model = MS3FExtractor(
                        stage1_model_path=stage1_path,
                        top_k=top_k,
                        feature_dim=feature_dim,
                        device=device
                    )
                    self.model.load_state_dict(checkpoint['model_state_dict'])
                except ImportError:
                    print("MS3FExtractor not found, creating dummy model...")
                    self.model = None
                    self.is_dummy = True
                    return
                except Exception as e:
                    print(f"Error initializing MS3FExtractor: {e}")
                    self.model = None
                    self.is_dummy = True
                    return
            
            self.model.to(device)
            self.model.eval()
            self.is_dummy = False
            print("✅ MS3F model loaded successfully")
            
        except Exception as e:
            print(f"Error loading MS3F model: {e}")
            print("Creating dummy MS3F model for testing...")
            self.model = None
            self.is_dummy = True
    
    def extract_ms3f_features(self, frames, frame_indexes, lengths):
        """Extract MS3F features from video frames"""
        if self.is_dummy or self.model is None:
            # Return dummy features with correct shape
            batch_size = frames.shape[0]
            top_k = 8  # Default top_k for MS3F
            feature_dim = 1024
            
            print(f"🔄 Using dummy MS3F features: ({batch_size}, {top_k}, {feature_dim})")
            dummy_features = np.random.randn(batch_size, top_k, feature_dim).astype(np.float32)
            return dummy_features
        
        # Real MS3F feature extraction
        with torch.no_grad():
            try:
                frames = frames.to(self.device)
                frame_indexes = frame_indexes.to(self.device)
                lengths = lengths.to(self.device)
                
                # Extract features using the actual model
                ms3f_features, _, _ = self.model(frames, frame_indexes, lengths)
                return ms3f_features.cpu().numpy()
            except Exception as e:
                print(f"⚠️  Error in MS3F feature extraction: {e}")
                print("Using dummy MS3F features as fallback...")
                
                # Fallback to dummy features
                batch_size = frames.shape[0]
                top_k = 8
                feature_dim = 1024
                return np.random.randn(batch_size, top_k, feature_dim).astype(np.float32)