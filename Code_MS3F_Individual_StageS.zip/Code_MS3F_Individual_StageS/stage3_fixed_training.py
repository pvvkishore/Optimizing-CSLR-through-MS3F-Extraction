# stage3_train_fixed.py - Headless training with class filtering

# Fix display issues FIRST
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['MPLBACKEND'] = 'Agg'

import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
from collections import Counter
import sys

# Import your existing stage3 components
sys.path.append('.')
from stage3_model import *

def filter_dataset_by_class_frequency(dataset, min_samples_per_class=3):
    """
    Filter dataset to only include classes with minimum number of samples
    This will dramatically improve training performance
    """
    print(f"🔍 Filtering dataset - requiring minimum {min_samples_per_class} samples per class")
    
    # Count samples per class
    class_counts = Counter([sample['gloss_text'] for sample in dataset.samples])
    
    print(f"📊 Original: {len(class_counts)} unique classes")
    
    # Keep only classes with enough samples
    valid_classes = {cls for cls, count in class_counts.items() if count >= min_samples_per_class}
    
    print(f"📊 After filtering: {len(valid_classes)} classes with {min_samples_per_class}+ samples")
    
    # Filter samples
    filtered_samples = [
        sample for sample in dataset.samples 
        if sample['gloss_text'] in valid_classes
    ]
    
    print(f"📊 Samples: {len(dataset.samples)} → {len(filtered_samples)}")
    
    # Update dataset
    dataset.samples = filtered_samples
    
    # Re-encode labels for filtered classes
    gloss_texts = [sample['gloss_text'] for sample in filtered_samples]
    dataset.labels = dataset.label_encoder.fit_transform(gloss_texts)
    dataset.num_classes = len(valid_classes)
    
    return dataset

def train_stage3_filtered():
    """Train Stage 3 with filtered classes for better performance"""
    
    print("🚀 Starting Stage 3 Training (Class-Filtered)")
    print("="*60)
    
    # Configuration
    config = {
        'root_train_folder': '/home/pvvkishore/Desktop/TVC_May21/train',
        'annotations_folder': '/home/pvvkishore/Desktop/TVC_May21',
        'stage1_model_path': '/home/pvvkishore/Desktop/TVC_May21/checkpoints/final_model.pth',
        'stage2_model_path': '/home/pvvkishore/Desktop/TVC_May21/stage2_checkpoints/final_ms3f_extractor.pth',
        'batch_size': 4,
        'num_epochs': 100,  # More epochs since we'll have better data
        'hidden_dim': 256,
        'num_layers': 2,
        'dropout': 0.3,
        'use_text_features': False,  # Disable for now
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'save_dir': '/home/pvvkishore/Desktop/TVC_May21/stage3_checkpoints_filtered',
        'train_split': 0.8,
        'min_samples_per_class': 5  # Only keep classes with 5+ samples
    }
    
    # Create save directory
    os.makedirs(config['save_dir'], exist_ok=True)
    
    try:
        # Load dataset
        print("\n📂 Loading Stage 3 dataset...")
        full_loader, full_dataset = get_stage3_data_loader(
            root_train_folder=config['root_train_folder'],
            annotations_folder=config['annotations_folder'],
            batch_size=config['batch_size'],
            shuffle=False,
            num_workers=0
        )
        
        print(f"Original dataset: {len(full_dataset)} samples, {full_dataset.num_classes} classes")
        
        # Filter dataset to only keep classes with enough samples
        full_dataset = filter_dataset_by_class_frequency(
            full_dataset, 
            min_samples_per_class=config['min_samples_per_class']
        )
        
        if len(full_dataset.samples) < 50:
            print("❌ Too few samples after filtering. Try reducing min_samples_per_class")
            return
        
        # Save filtered label encoder
        label_encoder_path = os.path.join(config['save_dir'], 'label_encoder.pkl')
        full_dataset.save_label_encoder(label_encoder_path)
        
        print(f"✅ Filtered dataset: {len(full_dataset)} samples, {full_dataset.num_classes} classes")
        
        # Create train/validation split
        from torch.utils.data import random_split
        train_size = int(config['train_split'] * len(full_dataset))
        val_size = len(full_dataset) - train_size
        
        train_dataset, val_dataset = random_split(
            full_dataset, [train_size, val_size],
            generator=torch.Generator().manual_seed(42)
        )
        
        print(f"📊 Split: {len(train_dataset)} train, {len(val_dataset)} validation")
        
        # Create data loaders
        train_loader = DataLoader(
            train_dataset, batch_size=config['batch_size'], shuffle=True,
            num_workers=0, pin_memory=False, collate_fn=stage3_collate_fn
        )
        
        val_loader = DataLoader(
            val_dataset, batch_size=config['batch_size'], shuffle=False,
            num_workers=0, pin_memory=False, collate_fn=stage3_collate_fn
        )
        
        # Initialize model
        print("\n🤖 Initializing Stage 3 Model...")
        stage3_model = Stage3Model(
            stage1_model_path=config['stage1_model_path'],
            stage2_model_path=config['stage2_model_path'],
            num_classes=full_dataset.num_classes,
            hidden_dim=config['hidden_dim'],
            num_layers=config['num_layers'],
            dropout=config['dropout'],
            use_text_features=config['use_text_features'],
            device=config['device']
        )
        
        # Initialize trainer
        trainer = Stage3Trainer(
            model=stage3_model,
            train_loader=train_loader,
            val_loader=val_loader,
            device=config['device']
        )
        
        # Start training
        print(f"\n🚂 Starting training for {config['num_epochs']} epochs...")
        trainer.train(num_epochs=config['num_epochs'], save_dir=config['save_dir'])
        
        print("🎉 Training completed successfully!")
        
        # Show final statistics
        print("\n📈 Training Summary:")
        if trainer.val_accuracies:
            best_val_acc = max(trainer.val_accuracies)
            print(f"Best Validation Accuracy: {best_val_acc:.4f}")
            print(f"Final Validation Accuracy: {trainer.val_accuracies[-1]:.4f}")
        
        print(f"Model saved to: {config['save_dir']}")
        
    except Exception as e:
        print(f"\n❌ Training failed: {e}")
        import traceback
        traceback.print_exc()

def analyze_dataset_classes():
    """Analyze your dataset to understand the class distribution"""
    
    print("🔍 Analyzing Dataset Classes")
    print("="*40)
    
    # Load annotations
    annotations_folder = '/home/pvvkishore/Desktop/TVC_May21'
    csv_files = [f for f in os.listdir(annotations_folder) if f.endswith('.csv')]
    
    if not csv_files:
        print("❌ No CSV file found")
        return
    
    csv_path = os.path.join(annotations_folder, csv_files[0])
    df = pd.read_csv(csv_path)
    
    # Skip first row and use first two columns
    df = df.iloc[1:, :2]
    df.columns = ['folder_name', 'gloss_text']
    
    # Clean gloss texts
    df['gloss_text'] = df['gloss_text'].astype(str).str.strip().str.lower()
    
    # Count classes
    class_counts = df['gloss_text'].value_counts()
    
    print(f"📊 Total samples: {len(df)}")
    print(f"📊 Unique classes: {len(class_counts)}")
    print(f"📊 Average samples per class: {len(df) / len(class_counts):.2f}")
    
    print("\n🔢 Class frequency distribution:")
    freq_dist = class_counts.value_counts().sort_index()
    for samples_per_class, num_classes in freq_dist.head(10).items():
        print(f"  {samples_per_class} samples: {num_classes} classes")
    
    print(f"\n📈 Classes with 5+ samples: {len(class_counts[class_counts >= 5])}")
    print(f"📈 Classes with 10+ samples: {len(class_counts[class_counts >= 10])}")
    print(f"📈 Classes with 20+ samples: {len(class_counts[class_counts >= 20])}")
    
    print("\n💡 Recommendations:")
    classes_5plus = len(class_counts[class_counts >= 5])
    classes_10plus = len(class_counts[class_counts >= 10])
    
    if classes_5plus > 50:
        print(f"✅ Use min_samples_per_class=5 → {classes_5plus} classes")
    if classes_10plus > 20:
        print(f"✅ Use min_samples_per_class=10 → {classes_10plus} classes")

if __name__ == "__main__":
    print("🎬 Stage 3: Improved Training")
    print("="*50)
    
    # First analyze the dataset
    analyze_dataset_classes()
    
    print("\n" + "="*50)
    
    # Then train with filtered classes
    train_stage3_filtered()
