# Stage 4: CTC Temporal Alignment for Sign Language Transcription

The final stage of our multi-modal sign language understanding system! Stage 4 implements Connectionist Temporal Classification (CTC) to enable temporal alignment and continuous transcription of sign language videos into text sequences.

## 🎯 Overview

Stage 4 completes the sign language understanding pipeline by adding **temporal sequence alignment** capabilities:

1. **Leverages Stage 3 Features**: Uses temporal representations from the trained Bi-LSTM classifier
2. **Implements CTC Loss**: Enables alignment-free sequence-to-sequence learning
3. **Character-Level Modeling**: Creates character-based vocabulary for flexible text generation
4. **Beam Search Decoding**: Provides both greedy and beam search decoding options
5. **End-to-End Transcription**: Converts raw video directly to text transcription

This creates a complete system capable of transcribing continuous sign language videos into readable text.

## 🏗️ Complete System Architecture

### Full Pipeline Flow

```
Raw Video Input
       ↓
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   Stage 1   │    │   Stage 2   │    │   Stage 3   │    │   Stage 4   │
│ Multi-Modal │ → │    MS3F     │ → │Bi-LSTM Class│ → │CTC Alignment│
│ Alignment   │    │  Features   │    │    +        │    │    +        │
│(Text+Visual)│    │(Motion-Sel) │    │  Attention  │    │  Decoding   │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
       ↓                   ↓                   ↓                   ↓
Text Features      Spatial Features    Gloss Predictions   Text Transcription
  (1024-dim)         (8×1024-dim)        (Discrete)          (Continuous)
```

### Stage 4 Specific Architecture

```
Stage 3 Temporal Features (B×T×1024)
              ↓
    ┌─────────────────┐
    │ Feature         │
    │ Projection      │ → (B×T×512)
    │                 │
    └─────────────────┘
              ↓
    ┌─────────────────┐
    │ Bidirectional   │
    │ CTC LSTM        │ → (B×T×1024)
    │ (2 layers)      │
    └─────────────────┘
              ↓
    ┌─────────────────┐
    │ Output          │
    │ Projection      │ → (B×T×vocab_size)
    │                 │
    └─────────────────┘
              ↓
    ┌─────────────────┐
    │ Log Softmax     │
    │ + CTC Loss      │ → Log Probabilities
    │                 │
    └─────────────────┘
              ↓
    ┌─────────────────┐
    │ CTC Decoding    │
    │ (Greedy/Beam)   │ → Text Transcription
    │                 │
    └─────────────────┘
```

## 📁 Project Structure

```
stage4-ctc-alignment/
├── stage4_data_loader.py          # CTC dataset with character-level targets
├── stage4_model.py               # CTC alignment module + complete model
├── stage4_training.py            # CTC training with CTC loss
├── stage4_inference.py           # CTC decoding and transcription
├── stage4_evaluation.py          # CTC-specific evaluation metrics
├── stage4_main.py               # Main training script
├── utils/
│   ├── pipeline.py              # Complete end-to-end pipeline
│   ├── demo.py                  # Gradio demo interface
│   └── visualization.py         # CTC alignment visualization
├── stage4_checkpoints/          # Trained CTC models
│   ├── best_stage4_ctc.pth
│   ├── ctc_vocabulary.pkl
│   └── evaluation/
└── README.md                    # This file
```

## 🚀 Quick Start

### 1. Prerequisites

Ensure all previous stages are completed:
- Stage 1: `stage1_checkpoints/best_model.pth`
- Stage 2: `stage2_checkpoints/best_ms3f_extractor.pth`  
- Stage 3: `stage3_checkpoints/best_stage3_classifier.pth` + `label_encoder.pkl`

```bash
# Install CTC-specific dependencies
pip install editdistance  # For edit distance evaluation
pip install torchaudio    # For beam search decoding (optional)
```

### 2. Configuration

Update paths in `stage4_main.py`:

```python
config = {
    'root_train_folder': 'data/train',
    'annotations_folder': 'data/annotations',
    'stage3_model_path': 'stage3_checkpoints/best_stage3_classifier.pth',
    'label_encoder_path': 'stage3_checkpoints/label_encoder.pkl',
    'batch_size': 8,                    # Smaller due to CTC memory requirements
    'num_epochs': 50,                   # CTC converges faster
    'hidden_dim': 512,
    'num_layers': 2,
    'dropout': 0.3,
    'max_seq_length': 100,             # Maximum character sequence length
    'train_split': 0.8,
    'device': 'cuda'
}
```

### 3. Training

```bash
# Start Stage 4 CTC training
python stage4_main.py
```

Training Output:
```
Using device: cuda
Loading Stage 4 CTC dataset...
CTC Vocabulary size: 42
Sample characters: ['<blank>', ' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
Dataset loaded with 1250 samples
Train samples: 1000, Val samples: 250

Initializing Stage 4 CTC Model...
Training 524288 parameters in CTC module

Epoch 1/50: 100%|██████████| 125/125 [05:32<00:00]
Train Loss: 12.3456
Val Loss: 11.8765

Epoch 15/50: 100%|██████████| 125/125 [05:28<00:00]
Train Loss: 3.4567
Val Loss: 3.8901
Saved best CTC model with validation loss: 3.8901

Edit Distance (CER): 0.1234
Word Accuracy: 0.8456
Sequence Accuracy: 0.7234
Average Confidence: 0.8765
```

## 📊 Model Architecture Details

### CTC Alignment Module

```python
CTCAlignmentModule:
├── Feature Projection: 1024 → 512
├── Bidirectional LSTM: 
│   ├── Input Size: 512
│   ├── Hidden Size: 512 (1024 total)
│   ├── Layers: 2
│   └── Dropout: 0.3
├── Output Projection: 1024 → vocab_size
└── Log Softmax: For CTC probabilities
```

### Character Vocabulary

- **Blank Token**: `<blank>` (index 0) for CTC alignment
- **Characters**: