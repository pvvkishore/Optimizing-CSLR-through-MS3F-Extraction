# TO_RUN_INSTRUCTIONS - DC_ISL CSLR Pipeline

This document provides concise execution instructions for the DC_ISL sign language recognition pipeline, assuming Stage 1 (Visual-Text Alignment Model) is already completed.

## Prerequisite
- Stage 1 model already trained and saved at "./saved_models/final_model.pth"
- Dataset cleaned and accessible

## Step 1: Extract Features and Prepare for CSLR

```bash
python feature_extraction_updated_for_cslr.py \
  --model_path "./saved_models/final_model.pth" \
  --csv_path "/path/to/cleaned_annotations.csv" \
  --frames_root_dir "/path/to/cleaned_train" \
  --output_dir "./results" \
  --prepare_gloss_vocab \
  --gloss_vocab_file "./gloss_vocab.txt"
```

This step:
- Extracts visual and text features using the trained Stage 1 model
- Calculates alignment scores between visual-text pairs
- Creates a vocabulary file for CSLR training
- Outputs results to the "./results" directory

## Step 2: Train the CSLR Model

```bash
python train_cslr_full.py \
  --pretrained_model "./saved_models/final_model.pth" \
  --csv_path "/path/to/cleaned_annotations.csv" \
  --frames_root_dir "/path/to/cleaned_train" \
  --gloss_vocab "./gloss_vocab.txt" \
  --batch_size 4 \
  --epochs 5 \
  --learning_rate 1e-3 \
  --phase 1 \
  --freeze_visual \
  --freeze_text \
  --unfreeze_attention \
  --save_path "./saved_models/cslr"
```

This step:
- Initializes the CSLR model using the pretrained Stage 1 model
- Freezes the visual and text backbones for efficient training
- Unfreezes attention layers for better cross-modal learning
- Trains with a combination of CTC and contrastive loss
- Saves model checkpoints to "./saved_models/cslr"

## Step 3: Evaluate the CSLR Model

```bash
python evaluate_cslr_dcisl.py \
  --model_path "./saved_models/cslr/final_cslr_model.pth" \
  --csv_path "/path/to/test_annotations.csv" \
  --frames_root_dir "/path/to/test" \
  --save_dir "./evaluation_results"
```

This step:
- Loads the trained CSLR model
- Runs inference on test data
- Calculates Word Error Rate (WER) and other metrics
- Analyzes error patterns
- Saves evaluation results to "./evaluation_results"

## Step 4: Visualize Model and Results

```bash
python model_visualizer_complete.py \
  --model_path "./saved_models/cslr/final_cslr_model.pth" \
  --model_type "cslr" \
  --csv_path "/path/to/test_annotations.csv" \
  --frames_root_dir "/path/to/test" \
  --output_dir "./visualizations" \
  --num_samples 20
```

This step:
- Creates visualizations of model architecture
- Generates feature space visualizations
- Shows attention maps
- Visualizes recognition results
- Creates sample recognition videos
- Outputs all visualizations to "./visualizations"

## Optional: Analyze Alignment Results

```bash
python analyze_results_updated.py \
  --results_file "./results/alignment_scores.txt" \
  --output_dir "./results/analysis"
```

This step:
- Creates detailed visualizations of alignment scores
- Shows distribution of alignment quality
- Identifies best and worst aligned samples

## Alternative: Automated Execution

To run the entire pipeline automatically (skipping Stage 1):

1. Edit the pipeline script to skip Stage 1:
```bash
# Open the script
nano run_dcisl_pipeline.sh

# Comment out the Stage 1 section (lines related to run_training_memory_efficient.py)
# Save and exit
```

2. Make executable and run:
```bash
chmod +x run_dcisl_pipeline.sh
./run_dcisl_pipeline.sh
```

## Notes

- Replace "/path/to/..." with your actual dataset paths
- Adjust batch_size based on available GPU memory
- For production use, increase epochs to 10-15 for Stage 2
- Use --validate_files flag with any command if file existence validation is needed
- For fine-tuning, try Phase 2 training with --phase 2 --freeze_visual=False

## Troubleshooting

If you encounter errors:
- Check logs in the "logs" directory
- Ensure the Stage 1 model was trained successfully
- Verify that the gloss vocabulary file was created correctly
- For CUDA out of memory errors, reduce batch size